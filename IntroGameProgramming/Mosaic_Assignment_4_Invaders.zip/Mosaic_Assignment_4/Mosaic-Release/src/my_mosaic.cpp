#include <vector>
#include <string>

const int width = 256;
const int height = 256;
const int invadersAmountX= 11;
const int invadersAmountY = 5;

enum direct { MOVE_LEFT, MOVE_RIGHT };

struct movingObject{
    real32 posX;
    real32 posY;
    direct direction; 
    int hitBoxSizeX;
    int hitBoxSizeY;
    bool dead;
};
struct bullet
{
    real32 posX;
    real32 posY;
};

/*
Character variables
*/
std::vector<bullet> bullets;
std::vector<bullet> reversebullets;

real32 charXPos = width/2;
real32 charYPos = height-20;
int health = 3;
int score = 0;
bool win = false;
bool lose = false;
bool started = false;

real32 move = 0;

movingObject** setInvaders(){
    movingObject** invadersTemp = new movingObject*[invadersAmountX];
    for(int x = 0;x < invadersAmountX; x++){
        invadersTemp[x] = new movingObject[invadersAmountY];
        for(int y = 0;y < invadersAmountY; y++){
            movingObject plane;
            plane.posX = 15 * x + 10;
            plane.posY = 15 * y + 10;
            plane.direction = MOVE_RIGHT;
            plane.hitBoxSizeX = 10;
            plane.hitBoxSizeY = 10;
            plane.dead = false;
            invadersTemp[x][y] = plane;
        }
    }
    return invadersTemp;
}

movingObject** invaders = setInvaders();

void drawCharacter(){
    for(int x2 = 0;x2 < 10; x2++){
        for(int y2 = 0;y2 < 10; y2++){
            SetTileColor(charXPos + x2, charYPos + y2, 1.0f, 1.0f, 1.0f);
        }
    }
}
void drawInvader(int &x, int &y){
    for(int x2 = 0;x2 < invaders[x][y].hitBoxSizeX; x2++){
        for(int y2 = 0;y2 < invaders[x][y].hitBoxSizeY; y2++){
            SetTileColor(invaders[x][y].posX + x2, invaders[x][y].posY + y2, 0.0f, 1.0f, 0.0f);
        }
    }
}

void reverseDirection(){
    for(int y = 0;y < invadersAmountY; y++){
        for(int x = 0;x < invadersAmountX; x++){
            invaders[x][y].direction = (invaders[x][y].direction == 0) ? MOVE_RIGHT : MOVE_LEFT;
        }
    }
}

void moveDown(){
    for(int y = 0;y < invadersAmountY; y++){
        for(int x = 0;x < invadersAmountX; x++){
            invaders[x][y].posY += 1;
        }
    }
}

void MyMosaicInit() {
    SetMosaicGridSize(width, height);
}

void reverseFire(real32 &x, real32 &y){
    if(RandiRange(0,5000) <= 1){
        reversebullets.push_back({x+5, y+10});
    }
}
void fire(){
    bullets.push_back({charXPos+5,charYPos-10});
}

void MyMosaicUpdate() {
    ClearTiles(0, 0, 0);
    
    move = 30 * DeltaTime;
    if(!started){
        DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "Invaders: left and right arrows to move, up arrow to shoot");
    }
    if(InputPressed(Keyboard, Input_R)){
        charXPos = width/2;
        charYPos = height-20;
        health = 3;
        score = 0;
        win = false;
        lose = false;
        started = false;

        move = 0;

        invaders = setInvaders();
        bullets.clear();
        reversebullets.clear();
    }
    if(!win && !lose){
        if(InputPressed(Keyboard, Input_LeftArrow) && charXPos > 10){
            charXPos -= 5;
        }
        if(InputPressed(Keyboard, Input_RightArrow) && charXPos < width - 20){
            charXPos += 5;
        }
        if(InputPressed(Keyboard, Input_UpArrow)){
            started=true;
            fire();
        }
        for(int i = 0; i < bullets.size(); i++){
            bullets.at(i).posY -= 4 * move;
            SetTileColor(bullets.at(i).posX,bullets.at(i).posY, 1.0f, 1.0f,1.0f);
        }
        for(int y = 0;y < invadersAmountY; y++){
            for(int x = 0;x < invadersAmountX; x++){
                // invaders movement
                if(invaders[x][y].posX < 10){
                    if (invaders[x][y].direction != MOVE_RIGHT){reverseDirection();}
                    moveDown();
                }
                if(invaders[x][y].posX > width - 20){
                    if (invaders[x][y].direction != MOVE_LEFT){reverseDirection();}
                    moveDown();
                }
                invaders[x][y].posX += (invaders[x][y].direction == MOVE_RIGHT) ? move : -move;

                if(!invaders[x][y].dead){
                    drawInvader(x,y);
                    reverseFire(invaders[x][y].posX,invaders[x][y].posY);
                }
                // check if shot at
                for(int i = bullets.size()-1; i >= 0; i--){
                    if(!invaders[x][y].dead && (bullets.at(i).posX >= invaders[x][y].posX && bullets.at(i).posX < invaders[x][y].posX +  invaders[x][y].hitBoxSizeX) && (bullets.at(i).posY >= invaders[x][y].posY && bullets.at(i).posY < invaders[x][y].posY +  invaders[x][y].hitBoxSizeY)){
                        invaders[x][y].dead = true;
                        bullets.erase(bullets.begin() + i);
                        score++;
                    }else if(bullets.at(i).posY < 0){
                        bullets.erase(bullets.begin() + i);
                    }
                }
                // check if lose
                if(invaders[x][y].posY > height - 40){
                    lose = true;
                }
                
            }
        }
        for(int i = reversebullets.size()-1; i >= 0; i--){
            reversebullets.at(i).posY += 4 * move;
            SetTileColor(reversebullets.at(i).posX,reversebullets.at(i).posY, 1.0f, 1.0f,1.0f);
            if((reversebullets.at(i).posX >= charXPos && reversebullets.at(i).posX < charXPos + 10) && (reversebullets.at(i).posY >= charYPos && reversebullets.at(i).posY < charYPos + 10)){
                health--;
                reversebullets.erase(reversebullets.begin() + i);
            }
        }
        if(started){
            DrawTextTop(RGB(1.0f, 1.0f, 0.0f), "score: %d, health: %d", score, health);
        }
    }
    if(score >= 55){
        win = true;
    }
    if(health <= 0){
        lose = true;
    }
    if(lose){
        DrawTextTop(RGB(1.0f, 0.0f, 0.0f), "Game Over, Press R to Reset");
    }
    if(win){
        DrawTextTop(RGB(0.0f, 1.0f, 0.0f), "You win, Press R to Reset");
    }
    
    drawCharacter();
    
}

