#include<vector>
#include<math.h>


const int HEIGHT    = 250;
const int WIDTH     = 250;

enum gameEnum{TIC, GUESS, MAZE, BATTLESHIP};

gameEnum currentGame = TIC;
bool gameStarted = false;

int32 xMouse;
int32 yMouse;

int32 randomX;
int32 randomY;
int32 randomNum;

int32 tempNum;


//TicTacToe variables

enum ticEnums{ticX, ticO, ticNone};

struct tictactoeVars
{
    std::vector<std::vector<ticEnums>> ticBoard;
    int gamesPlayed;
    int tilesPressed;
    int gamesWon;
    bool playerTurn;
    bool hasWon;
    bool timeStart;
    real32 timeElapsed;
};

// Guessing card game variables

enum guessingCards{ card0, card1, card2, card3, card4, card5, card6, card7, card8, card9, NONE};

struct guessingVars
{
    std::vector<std::vector<guessingCards>> guessingBoard;
    std::vector<std::vector<bool>> checkedBoard;
    std::vector<std::vector<bool>> tempBoard;
    int firstCard;
    int secondCard;
    bool timeStart;
    real32 timeElapsed;
    bool hasWon;
};

// Mouse Maze Game

enum mazeEnum {PATH_TILE, VOID_TILE, DOOR_TILE, START_TILE};

struct mazeVars
{
    std::vector<std::vector<mazeEnum>> mazeBoard;
    bool hasStarted;
    bool hasLost;
    bool timeStart;
    real32 timeElapsed;
    bool hasWon;
};

// Battleship Variables

enum battleShipEnum {NOT_HIT, SHIP_HIT, NOT_PRESSED, SHIP};

struct battleShipVars
{
    std::vector<std::vector<battleShipEnum>> enemyBoard;
    std::vector<std::vector<battleShipEnum>> playerBoard;
    bool playerTurn;
    bool hasWon;
    bool hasLost;
};

// Game Save
tictactoeVars tacGame;
guessingVars guessGame;
mazeVars mazeGame;
battleShipVars battleshipGame;

// tictactoe functions

void resetBoardTic(){
    for (int x = 0; x < 3; x++)
    {
        for (int y = 0; y < 3; y++)
        {
            tacGame.ticBoard.at(y).at(x) = ticNone;
        }
    }
}

void checkTic(){
    for(int x = 0; x < 3; x++){
        //{ticX, ticO, ticNone}
        if ((tacGame.ticBoard.at(0).at(x) == ticX && tacGame.ticBoard.at(1).at(x) == ticX && tacGame.ticBoard.at(2).at(x) == ticX)){
            tacGame.hasWon = true;
            tacGame.timeStart = true;
        }else if (tacGame.ticBoard.at(0).at(x) == ticO && tacGame.ticBoard.at(1).at(x) == ticO && tacGame.ticBoard.at(2).at(x) == ticO){
            resetBoardTic();
        }
    }
    for(int y = 0; y < 3; y++){
        //{ticX, ticO, ticNone}
        if ((tacGame.ticBoard.at(y).at(0) == ticX && tacGame.ticBoard.at(y).at(1) == ticX && tacGame.ticBoard.at(y).at(2) == ticX)){
            tacGame.hasWon = true;
            tacGame.timeStart = true;
            resetBoardTic();
        }else if (tacGame.ticBoard.at(y).at(0) == ticO && tacGame.ticBoard.at(y).at(1) == ticO && tacGame.ticBoard.at(y).at(2) == ticO){
            resetBoardTic();
        }
    }
    if ((tacGame.ticBoard.at(0).at(0) == ticX && tacGame.ticBoard.at(1).at(1) == ticX && tacGame.ticBoard.at(2).at(2) == ticX)){
        tacGame.hasWon = true;
        tacGame.timeStart = true;
        resetBoardTic();
    }else if (tacGame.ticBoard.at(0).at(0) == ticO && tacGame.ticBoard.at(1).at(1) == ticO && tacGame.ticBoard.at(2).at(2) == ticO){
        resetBoardTic();
    }
    if ((tacGame.ticBoard.at(2).at(0) == ticX && tacGame.ticBoard.at(1).at(1) == ticX && tacGame.ticBoard.at(0).at(2) == ticX)){
        tacGame.hasWon = true;
        tacGame.timeStart = true;
        resetBoardTic();
    }else if (tacGame.ticBoard.at(2).at(0) == ticO && tacGame.ticBoard.at(1).at(1) == ticO && tacGame.ticBoard.at(0).at(2) == ticO){
        resetBoardTic();
    }
    if(tacGame.tilesPressed>=9){
        tacGame.hasWon = true;
        tacGame.timeStart = true;
        resetBoardTic();
    }
}

void ticTacToe(){

    /*
    Print(tacGame.gamesPlayed);
    Print(tacGame.tilesPressed);
    Print(tacGame.gamesWon);
    Print(tacGame.playerTurn);
    Print(tacGame.hasWon);
    Print(tacGame.timeStart);
    Print(tacGame.timeElapsed);
    */
    Print("---");
    Print("The value of gamesPlayed is %0.4f", tacGame.gamesPlayed);
    Print("The value of tilesPressed is %0.4f", tacGame.tilesPressed);
    Print("The value of gamesWon is %0.4f", tacGame.gamesWon);
    Print("The value of playerTurn is %0.4f", (tacGame.playerTurn)?1.0:0.0);
    Print("The value of hasWon is %0.4f", (tacGame.hasWon)?1.0:0.0);
    Print("The value of timeStart is %0.4f", (tacGame.timeStart)?1.0:0.0);
    Print("The value of timeElapsed is %0.4f", tacGame.timeElapsed);
    Print("---");
    
    //graphics
    Print("Part1 Done");
    for(int y = 0; y < HEIGHT; y++){
        for(int x = 80; x < 85; x++){
            SetTileColor(x, y, 1.0f, 1.0f, 1.0f);
        }
        for(int x = 165; x < 170; x++){
            SetTileColor(x, y, 1.0f, 1.0f, 1.0f);
        }
    }
    for(int x = 0; x < WIDTH; x++){
        for(int y = 80; y < 85; y++){
            SetTileColor(x, y, 1.0f, 1.0f, 1.0f);
        }
        for(int y = 165; y < 170; y++){
            SetTileColor(x, y, 1.0f, 1.0f, 1.0f);
        }
    }

    Print("Part2 Done");
    for (int boardX = 0; boardX < 3; boardX++)
    {
        for (int boardY = 0; boardY < 3; boardY++)
        {
            if(tacGame.ticBoard.at(boardY).at(boardX) == ticX){
                for(int i = 0; i < 80; i++){
                    SetTileColor(i+(boardX*85), i+(boardY*85), 1.0f, 1.0f, 1.0f);
                }
            }else if(tacGame.ticBoard.at(boardY).at(boardX) == ticO){
                for(int i = 5; i < 75; i++){
                    SetTileColor(i+(boardX*85), 5+(boardY*85), 1.0f, 1.0f, 1.0f);
                }
                for(int i = 5; i < 75; i++){
                    SetTileColor(i+(boardX*85), 75+(boardY*85), 1.0f, 1.0f, 1.0f);
                }
                for(int i = 5; i < 75; i++){
                    SetTileColor(5+(boardX*85), i+(boardY*85), 1.0f, 1.0f, 1.0f);
                }
                for(int i = 5; i < 75; i++){
                    SetTileColor(75+(boardX*85), i+(boardY*85), 1.0f, 1.0f, 1.0f);
                }
            }
        }
    }
    
    //logic
    Print("Part3 Done");
    if (!tacGame.hasWon) {
        if (InputPressed(Mouse, Input_MouseLeft)) {
            xMouse = GetMousePositionX();
            yMouse = GetMousePositionY();
            if (!((xMouse >= 80 && xMouse < 85) || (xMouse >= 165 && xMouse < 170) || (yMouse >= 80 && yMouse < 85) || (yMouse >= 165 && yMouse < 170))) {
                if (tacGame.ticBoard.at(yMouse / 85).at(xMouse / 85) == ticNone) {
                    tacGame.ticBoard.at(yMouse / 85).at(xMouse / 85) = ticX;
                    tacGame.tilesPressed++;
                    checkTic();
                    tacGame.playerTurn = false;
                }
            }
        }

        Print("Part4a Done");
        randomX = RandiRange(0, 2);
        randomY = RandiRange(0, 2);
        Print("Part4b Done");
        while (!tacGame.playerTurn) {
            Print("Part4c Done");
            if (tacGame.ticBoard.at(randomY).at(randomX) == ticNone) {
                tacGame.ticBoard.at(randomY).at(randomX) = ticO;
                tacGame.tilesPressed++;
                checkTic();
                tacGame.playerTurn = true;
                Print("Part4d Done");
            }
            else {
                SeedRand(RandiRange(0, 151591134));
                randomX = RandiRange(0, 11) / 4;
                randomY = RandiRange(0, 11) / 4;
                Print("Part4e Done");
            }
            Print("Part4f Done");
        }

        Print("Part5 Done");
    }
    
    Print("Part6 Done");
    if(tacGame.timeStart){
        tacGame.timeElapsed += DeltaTime;
    }

    Print("Part7 Done");
    //switch game function
    if(tacGame.hasWon && tacGame.timeElapsed >= 5.0f){
        currentGame = GUESS; gameStarted = false;
    }else if(tacGame.hasWon){
        DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "YOU WON!!!! Changing the game soon");
    }else {
        DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "Tictactoe: Tie = Win");
    }
}

// Guessing card functions

void setGuessingBoard(){
    randomNum = RandiRange(0, 3);
    if (randomNum == 0) {
        guessGame.guessingBoard = {//{card1, card2, card3, card4, card5, card6, card7, card8, card9, card0, NONE};
            {card1,card4,card3,card0,card2},
            {card0,card9,card5,card1,card9},
            {card8,card2,card7,card6,card5},
            {card8,card7,card3,card6,card4}
        };
    }else if (randomNum == 1) {
        guessGame.guessingBoard = {//{card1, card2, card3, card4, card5, card6, card7, card8, card9, card0, NONE};
            {card8,card9,card7,card1,card9},
            {card7,card8,card0,card1,card4},
            {card6,card4,card0,card3,card2},
            {card5,card6,card2,card5,card3}
        };
    }else if (randomNum == 2) {
        guessGame.guessingBoard = {//{card1, card2, card3, card4, card5, card6, card7, card8, card9, card0, NONE};
            {card5,card4,card2,card1,card3},
            {card1,card5,card0,card9,card8},
            {card0,card9,card3,card2,card7},
            {card8,card6,card4,card7,card6}
        };
    }else if (randomNum == 3) {
        guessGame.guessingBoard = {//{card1, card2, card3, card4, card5, card6, card7, card8, card9, card0, NONE};
            {card5,card8,card7,card2,card1},
            {card9,card5,card4,card3,card6},
            {card4,card7,card3,card0,card0},
            {card6,card1,card9,card8,card2}
        };
    }
}

void drawCard(int32 xPos, int32 yPos, guessingCards card, bool shown) {
    switch (card) {
        case card0: tempNum = 0; break;
        case card1: tempNum = 1; break;
        case card2: tempNum = 2; break;
        case card3: tempNum = 3; break;
        case card4: tempNum = 4; break;
        case card5: tempNum = 5; break;
        case card6: tempNum = 6; break;
        case card7: tempNum = 7; break;
        case card8: tempNum = 8; break;
        case card9: tempNum = 9; break;
        default: break;
    }

    if (!shown) {
        for (int y = 0; y < 40; y++) {
            for (int x = 0; x < 30; x++) {
                SetTileColor(x+xPos, y+yPos, 0.75f, 0.75f, 0.75f);
            }
        }
    }else {
        for (int y = 0; y < 40; y++) {
            for (int x = 0; x < 30; x++) {
                SetTileColor(x + xPos, y + yPos, 1.0f, 1.0f, 1.0f);
            }
        }
        for (int y = 1; y <= 7; y += 3) {
            for (int x = 1; x <= 7; x += 3) {
                if (tempNum > 0) {
                    SetTileColor(xPos + 11 + x, yPos + 16 + y, 0.0f, 0.43f, 1.0f);
                    SetTileColor(xPos + 12 + x, yPos + 16 + y, 0.0f, 0.43f, 1.0f);
                    SetTileColor(xPos + 11 + x, yPos + 17 + y, 0.0f, 0.43f, 1.0f);
                    SetTileColor(xPos + 12 + x, yPos + 17 + y, 0.0f, 0.43f, 1.0f);
                    tempNum--;
                }
            }
        }
    }
    
}

int32 numCount;
int32 cardsChecked;

void guessingCard(){


    // debug
    // 
    // 
    
    Print("---");
    Print("The value of firstCard is %0.4f", (guessGame.firstCard == card0) ? 0.0f: (guessGame.firstCard == card1) ? 1.0f : (guessGame.firstCard == card2) ? 2.0f : (guessGame.firstCard == card3) ? 3.0f : (guessGame.firstCard == card4) ? 4.0f : (guessGame.firstCard == card5) ? 5.0f : (guessGame.firstCard == card6) ? 6.0f : (guessGame.firstCard == card7) ? 7.0f : (guessGame.firstCard == card8) ? 8.0f : (guessGame.firstCard == card9) ? 9.0f : 10.0f);
    Print("The value of secondCard is %0.4f", (guessGame.secondCard == card0) ? 0.0f: (guessGame.secondCard == card1) ? 1.0f : (guessGame.secondCard == card2) ? 2.0f : (guessGame.secondCard == card3) ? 3.0f : (guessGame.secondCard == card4) ? 4.0f : (guessGame.secondCard == card5) ? 5.0f : (guessGame.secondCard == card6) ? 6.0f : (guessGame.secondCard == card7) ? 7.0f : (guessGame.secondCard == card8) ? 8.0f : (guessGame.secondCard == card9) ? 9.0f : 10.0f);
    Print("The value of timeStart is %0.4f", (guessGame.timeStart) ? 1.0 : 0.0);
    Print("The value of timeElapsed is %0.4f", guessGame.timeElapsed);
    Print("The value of hasWon is %0.4f", (guessGame.hasWon) ? 1.0 : 0.0);
    Print("---");

    /*std::vector<std::vector<guessingCards>> guessingBoard;
    std::vector<std::vector<bool>> checkedBoard;
    std::vector<std::vector<bool>> tempBoard;
    int firstCard;
    int firstCard;
    int secondCard;
    bool timeStart;
    real32 timeElapsed;
    bool hasWon;*/

    // graphics

    // cards 40 height by 30 width
    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 5; x++) {
            if (guessGame.checkedBoard.at(y).at(x) || guessGame.tempBoard.at(y).at(x)) {
                drawCard(40 + (x * 40), 5 + (y * 50), guessGame.guessingBoard.at(y).at(x), true);
            }
            else {
                drawCard(40 + (x * 40), 5 + (y * 50), guessGame.guessingBoard.at(y).at(x), false);
            }
        }
    }

    // logic
    for (int y = 0; y < 4; y++) {
        for (int x = 0; x < 5; x++) {
            if (guessGame.checkedBoard.at(y).at(x)) {
                cardsChecked++;
            }
        }
    }

    if (cardsChecked < 20) {
        //count temp
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 5; x++) {
                if (guessGame.tempBoard.at(y).at(x)) {
                    numCount++;
                }
            }
        }

        if (numCount < 2) {
            if (InputPressed(Mouse, Input_MouseLeft)) {
                xMouse = GetMousePositionX();
                yMouse = GetMousePositionY();
                xMouse = ((xMouse - 40) / 40);
                yMouse = ((yMouse - 5) / 50);
                if ((xMouse >= 0 && xMouse < 5) && (yMouse >= 0 && yMouse < 4)) {
                    if (guessGame.checkedBoard.at(yMouse).at(xMouse) == false) {
                        guessGame.tempBoard.at(yMouse).at(xMouse) = true;
                    }
                }
            }
        }else {
            for (int y = 0; y < 4; y++) {
                for (int x = 0; x < 5; x++) {
                    if (guessGame.tempBoard.at(y).at(x) && guessGame.firstCard == NONE) {
                        guessGame.firstCard = guessGame.guessingBoard.at(y).at(x);
                    }
                    else if (guessGame.tempBoard.at(y).at(x) && guessGame.secondCard == NONE) {
                        guessGame.secondCard = guessGame.guessingBoard.at(y).at(x);
                    }
                }
            }
            guessGame.timeStart = true;
        }

        if (guessGame.timeStart && guessGame.timeElapsed >= 3.0f) {
            if (guessGame.firstCard == guessGame.secondCard) {
                for (int y = 0; y < 4; y++) {
                    for (int x = 0; x < 5; x++) {
                        guessGame.checkedBoard.at(y).at(x) = guessGame.checkedBoard.at(y).at(x) || guessGame.tempBoard.at(y).at(x);
                        guessGame.tempBoard.at(y).at(x) = false;
                    }
                }
            }
            else {
                for (int y = 0; y < 4; y++) {
                    for (int x = 0; x < 5; x++) {
                        guessGame.tempBoard.at(y).at(x) = false;
                    }
                }
            }
            guessGame.firstCard = NONE;
            guessGame.secondCard = NONE;
            guessGame.timeStart = false;
            guessGame.timeElapsed = 0.0f;
        }

        numCount = 0;
    }
    else {
        guessGame.hasWon = true;
        guessGame.timeStart = true;
    }

    cardsChecked = 0;
    

    if (guessGame.timeStart) {
        guessGame.timeElapsed += DeltaTime;
    }

    //switch game function
    if (guessGame.hasWon && guessGame.timeElapsed >= 3.0f) {
        currentGame = MAZE; gameStarted = false;
    }
    else if (guessGame.hasWon) {
        DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "YOU WON!!!! Changing the game soon");
    }
    else {
        DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "Memory Cards: click to flip");
    }
}

// Mouse Maze functions

void drawTileMaze(int32 xPos, int32 yPos, mazeEnum tileEn) {
    for (int y = 0; y < 10; y++) {
        for (int x = 0; x < 10; x++) {
            switch (tileEn)
            {
            case PATH_TILE:
                SetTileColor((xPos * 10) + x, (yPos * 10) + y, 1.0f, 0.9f, 0.8f);
                break;
            case VOID_TILE:
                SetTileColor((xPos * 10) + x, (yPos * 10) + y, 0.0f, 0.0f, 0.0f);
                break;
            case DOOR_TILE:
                SetTileColor((xPos * 10) + x, (yPos * 10) + y, 0.5f, 0.25f, 0.0f);
                break;
            case START_TILE:
                SetTileColor((xPos * 10) + x, (yPos * 10) + y, 1.0f, 1.0f, 0.5f);
                break;
            default:
                SetTileColor((xPos * 10) + x, (yPos * 10) + y, 1.0f, 0.0f, 0.0f);
                break;
            }
        }
    }
}

void mouseMaze(){
    //graphics
    for (int y = 0; y < 25; y++) {
        for (int x = 0; x < 25; x++) {
            drawTileMaze(x, y, mazeGame.mazeBoard.at(y).at(x));
        }
    }

    //logic

    xMouse = GetMousePositionX();
    yMouse = GetMousePositionY();

    if (!(mazeGame.hasLost)) {
        if ((xMouse > 0 && xMouse < 250) && (yMouse > 0 && yMouse < 250)) {
            if (mazeGame.mazeBoard.at(yMouse / 10).at(xMouse / 10) == VOID_TILE) {
                mazeGame.hasLost = true;
            }else if (mazeGame.mazeBoard.at(yMouse / 10).at(xMouse / 10) == DOOR_TILE) {
                mazeGame.hasWon = true;
                mazeGame.timeStart = true;
            }
        }else {
            mazeGame.hasLost = true;
        }
    }else {
        if ((xMouse > 0 && xMouse < 250) && (yMouse > 0 && yMouse < 250)) {
            if (mazeGame.mazeBoard.at(yMouse / 10).at(xMouse / 10) == START_TILE) {
                mazeGame.hasLost = false;
            }
        }
    }
    

    if (mazeGame.timeStart) {
        mazeGame.timeElapsed += DeltaTime;
    }

    //switch game function
    if (mazeGame.hasWon && mazeGame.timeElapsed >= 3.0f) {
        currentGame = BATTLESHIP; gameStarted = false;
    }else if (mazeGame.hasWon) {
        DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "YOU WON!!!! Changing the game soon");
    }else {
        if (!(mazeGame.hasLost)) {
            DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "Mouse Maze!");
        }
        else {
            DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "Please put you mouse over the yellow square to play!");
        }
    }
}

// Battleship functions

void drawTileBattleShip(int32 xPos, int32 yPos, battleShipEnum tileEnu, bool isPlayer) {
    //{NOT_HIT, SHIP_HIT, NOT_PRESSED, SHIP};
    for (int x = 0; x < 10; x++) {
        if (!isPlayer) {
            switch (tileEnu)
            {
            case NOT_HIT:
                SetTileColor(x + xPos, yPos, 0.9f, 0.9f, 0.9f);
                break;
            case SHIP_HIT:
                SetTileColor(x + xPos, yPos, 1.0f, 0.4f, 0.4f);
                break;
            case NOT_PRESSED:
            case SHIP:
                SetTileColor(x + xPos, yPos, 1.0f, 0.6f, 1.0f);
                break;
            default:
                SetTileColor(x + xPos, yPos, 1.0f, 0.0f, 0.0f);
                break;
            }
        }else {
            switch (tileEnu)
            {
            case NOT_HIT:
                SetTileColor(x + xPos, yPos, 0.9f, 0.9f, 0.9f);
                break;
            case SHIP_HIT:
                SetTileColor(x + xPos, yPos, 1.0f, 0.4f, 0.4f);
                break;
            case NOT_PRESSED:
                SetTileColor(x + xPos, yPos, 0.6f, 0.6f, 1.0f);
                break;
            case SHIP:
                SetTileColor(x + xPos, yPos, 0.5f, 0.5f, 1.5f);
                break;
            default:
                SetTileColor(x + xPos, yPos, 1.0f, 0.0f, 0.0f);
                break;
            }
        }
    }
    for (int x = 0; x < 10; x++) {
        if (!isPlayer) {
            switch (tileEnu)
            {
            case NOT_HIT:
                SetTileColor(x + xPos, yPos + 9, 0.9f, 0.9f, 0.9f);
                break;
            case SHIP_HIT:
                SetTileColor(x + xPos, yPos + 9, 1.0f, 0.4f, 0.4f);
                break;
            case NOT_PRESSED:
            case SHIP:
                SetTileColor(x + xPos, yPos + 9, 1.0f, 0.6f, 1.0f);
                break;
            default:
                SetTileColor(x + xPos, yPos + 9, 1.0f, 0.0f, 0.0f);
                break;
            }
        }
        else {
            switch (tileEnu)
            {
            case NOT_HIT:
                SetTileColor(x + xPos, yPos + 9, 0.9f, 0.9f, 0.9f);
                break;
            case SHIP_HIT:
                SetTileColor(x + xPos, yPos + 9, 1.0f, 0.4f, 0.4f);
                break;
            case NOT_PRESSED:
                SetTileColor(x + xPos, yPos + 9, 0.6f, 0.6f, 1.0f);
                break;
            case SHIP:
                SetTileColor(x + xPos, yPos + 9, 0.5f, 0.5f, 1.5f);
                break;
            default:
                SetTileColor(x + xPos, yPos + 9, 1.0f, 0.0f, 0.0f);
                break;
            }
        }

    }
    for (int y = 0; y < 10; y++) {
        if (!isPlayer) {
            switch (tileEnu)
            {
            case NOT_HIT:
                SetTileColor(xPos, y + yPos, 0.9f, 0.9f, 0.9f);
                break;
            case SHIP_HIT:
                SetTileColor(xPos, y + yPos, 1.0f, 0.4f, 0.4f);
                break;
            case NOT_PRESSED:
            case SHIP:
                SetTileColor(xPos, y + yPos, 1.0f, 0.6f, 1.0f);
                break;
            default:
                SetTileColor(xPos, y + yPos, 1.0f, 0.0f, 0.0f);
                break;
            }
        }
        else {
            switch (tileEnu)
            {
            case NOT_HIT:
                SetTileColor(xPos, y + yPos, 0.9f, 0.9f, 0.9f);
                break;
            case SHIP_HIT:
                SetTileColor(xPos, y + yPos, 1.0f, 0.4f, 0.4f);
                break;
            case NOT_PRESSED:
                SetTileColor(xPos, y + yPos, 0.6f, 0.6f, 1.0f);
                break;
            case SHIP:
                SetTileColor(xPos, y + yPos, 0.5f, 0.5f, 1.5f);
                break;
            default:
                SetTileColor(xPos, y + yPos, 1.0f, 0.0f, 0.0f);
                break;
            }
        }
    }
    for (int y = 0; y < 10; y++) {
        if (!isPlayer) {
            switch (tileEnu)
            {
            case NOT_HIT:
                SetTileColor(xPos + 9, y + yPos, 0.9f, 0.9f, 0.9f);
                break;
            case SHIP_HIT:
                SetTileColor(xPos + 9, y + yPos, 1.0f, 0.4f, 0.4f);
                break;
            case NOT_PRESSED:
            case SHIP:
                SetTileColor(xPos + 9, y + yPos, 1.0f, 0.6f, 1.0f);
                break;
            default:
                SetTileColor(xPos + 9, y + yPos, 1.0f, 0.0f, 0.0f);
                break;
            }
        }
        else {
            switch (tileEnu)
            {
            case NOT_HIT:
                SetTileColor(xPos + 9, y + yPos, 0.9f, 0.9f, 0.9f);
                break;
            case SHIP_HIT:
                SetTileColor(xPos + 9, y + yPos, 1.0f, 0.4f, 0.4f);
                break;
            case NOT_PRESSED:
                SetTileColor(xPos + 9, y + yPos, 0.6f, 0.6f, 1.0f);
                break;
            case SHIP:
                SetTileColor(xPos + 9, y + yPos, 0.5f, 0.5f, 1.5f);
                break;
            default:
                SetTileColor(xPos + 9, y + yPos, 1.0f, 0.0f, 0.0f);
                break;
            }
        }
    }
    for (int y = 1; y < 9; y++) {
        for (int x = 1; x < 9; x++) {
            if (!isPlayer) {
                switch (tileEnu)
                {
                case NOT_HIT:
                    SetTileColor(xPos + x, yPos + y, 1.0f, 1.0f, 1.0f);
                    break;
                case SHIP_HIT:
                    SetTileColor(xPos + x, yPos + y, 1.0f, 0.6f, 0.6f);
                    break;
                case NOT_PRESSED:
                case SHIP:
                    SetTileColor(xPos + x, yPos + y, 1.0f, 0.8f, 1.0f);
                    break;
                default:
                    SetTileColor(xPos + x, yPos + y, 1.0f, 0.0f, 0.0f);
                    break;
                }
            }
            else {
                switch (tileEnu)
                {
                case NOT_HIT:
                    SetTileColor(xPos + x, yPos + y, 1.0f, 1.0f, 1.0f);
                    break;
                case SHIP_HIT:
                    SetTileColor(xPos + x, yPos + y, 1.0f, 0.6f, 0.6f);
                    break;
                case NOT_PRESSED:
                    SetTileColor(xPos + x, yPos + y, 0.8f, 0.8f, 1.0f);
                    break;
                case SHIP:
                    SetTileColor(xPos + x, yPos + y, 0.5f, 0.5f, 0.5f);
                    break;
                default:
                    SetTileColor(xPos + x, yPos + y, 1.0f, 0.0f, 0.0f);
                    break;
                }
            }
        }
    }
}

int32 shipsEnemy;
void checkWinBattle() {
    shipsEnemy = 0;
    for (int y = 0; y < 10; y++) {
        for (int x = 0; x < 10; x++) {
            shipsEnemy += (battleshipGame.enemyBoard.at(y).at(x) == SHIP) ? 1 : 0;
        }
    }
}

int32 shipsFriendly;
void checkLossBattle() {
    shipsFriendly = 0;
    for (int y = 0; y < 10; y++) {
        for (int x = 0; x < 10; x++) {
            shipsFriendly += (battleshipGame.playerBoard.at(y).at(x) == SHIP) ? 1 : 0;
        }
    }
}

void battleship(){
    // graphics

    for (int y = 0; y < 10; y++) {
        for (int x = 0; x < 10; x++) {
            drawTileBattleShip((x * 10) + 75, (y * 10), battleshipGame.enemyBoard.at(y).at(x), false);
        }
    }

    for (int y = 0; y < 10; y++) {
        for (int x = 0; x < 10; x++) {
            drawTileBattleShip((x * 10) + 75, (y * 10) + 100, battleshipGame.playerBoard.at(y).at(x), true);
        }
    }

    // logic
    if (!(battleshipGame.hasWon || battleshipGame.hasLost)) {
        if (battleshipGame.playerTurn) {
            if (InputPressed(Mouse, Input_MouseLeft)) {
                xMouse = GetMousePositionX();
                yMouse = GetMousePositionY();
                xMouse = ((xMouse - 75) / 10);
                yMouse = (yMouse / 10);
                if ((xMouse >= 0 && xMouse < 10) && (yMouse >= 0 && yMouse < 10)) {
                    if (battleshipGame.enemyBoard.at(yMouse).at(xMouse) == NOT_PRESSED) {
                        battleshipGame.enemyBoard.at(yMouse).at(xMouse) = NOT_HIT;
                        battleshipGame.playerTurn = false;
                    }
                    else if (battleshipGame.enemyBoard.at(yMouse).at(xMouse) == SHIP) {
                        battleshipGame.enemyBoard.at(yMouse).at(xMouse) = SHIP_HIT;
                    }
                }
            }
        }
        else {
            while (!battleshipGame.playerTurn) {
                randomX = RandiRange(0, 9);
                randomY = RandiRange(0, 9);

                if (battleshipGame.playerBoard.at(randomY).at(randomX) == NOT_PRESSED) {
                    battleshipGame.playerBoard.at(randomY).at(randomX) = NOT_HIT;
                    battleshipGame.playerTurn = true;
                }
                else if (battleshipGame.playerBoard.at(randomY).at(randomX) == SHIP) {
                    battleshipGame.playerBoard.at(randomY).at(randomX) = SHIP_HIT;
                }

            }
        }
    }

    checkWinBattle();
    checkLossBattle();
    if (shipsEnemy == 0) {
        battleshipGame.hasWon = true;
    }
    else if (shipsFriendly == 0) {
        battleshipGame.hasLost = true;
    }


    if (battleshipGame.hasWon) { DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "YOU WIN!!!!"); }
    else if (battleshipGame.hasLost) { DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "Better luck next time!!!!"); }
    else { DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "Battleship"); }
}

// Declare Games

void declareGame(){
    if(currentGame==TIC){
        tacGame.ticBoard.resize(3, std::vector<ticEnums>(3));
        resetBoardTic();
        tacGame.gamesPlayed = 0;
        tacGame.gamesWon = 0;
        tacGame.tilesPressed = 0;
        tacGame.playerTurn = true;
        tacGame.hasWon = false; // debug
        tacGame.timeStart = false; // debug
        tacGame.timeElapsed = 0; // debug
    }else if(currentGame==GUESS){
        guessGame.guessingBoard.resize(4, std::vector<guessingCards>(5));
        setGuessingBoard();
        guessGame.checkedBoard.resize(4, std::vector<bool>(5));
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 5; x++) {
                guessGame.checkedBoard.at(y).at(x) = false;
            }
        }
        guessGame.tempBoard.resize(4, std::vector<bool>(5));
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 5; x++) {
                guessGame.tempBoard.at(y).at(x) = false;
            }
        }
        guessGame.firstCard = NONE;
        guessGame.secondCard = NONE;
        guessGame.hasWon = false; // debug
        guessGame.timeStart = false; // debug 
        guessGame.timeElapsed = 0.0f; // debug
    }else if(currentGame==MAZE){ // {PATH_TILE, VOID_TILE, DOOR_TILE, START_TILE};
        mazeGame.mazeBoard.resize(25, std::vector<mazeEnum>(25));
        mazeGame.mazeBoard = {
            {VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE },
            { VOID_TILE,START_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,DOOR_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,PATH_TILE,VOID_TILE },
            { VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE,VOID_TILE }
        };
        mazeGame.hasStarted = false;
        mazeGame.hasLost = false;//debug
        mazeGame.hasWon = false;//debug
        mazeGame.timeStart = false;//debug
        mazeGame.timeElapsed = 0.0f;
    }else if(currentGame==BATTLESHIP){
        battleshipGame.enemyBoard.resize(10, std::vector<battleShipEnum>(10));

        battleshipGame.enemyBoard = { //{NOT_HIT, SHIP_HIT, NOT_PRESSED, SHIP};
            {SHIP,SHIP,SHIP,NOT_PRESSED,NOT_PRESSED,SHIP,NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,SHIP,NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,SHIP,NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,SHIP,SHIP,SHIP,SHIP,SHIP},
            {NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED}
        };

        battleshipGame.playerBoard.resize(10, std::vector<battleShipEnum>(10));

        battleshipGame.playerBoard = { //{NOT_HIT, SHIP_HIT, NOT_PRESSED, SHIP};
            {NOT_PRESSED,NOT_PRESSED,SHIP,SHIP,SHIP,SHIP,SHIP,SHIP,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,SHIP,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {SHIP,SHIP,SHIP,NOT_PRESSED,NOT_PRESSED,SHIP,SHIP,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED},
            {NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED,NOT_PRESSED}
        };

        battleshipGame.hasWon = false;
        battleshipGame.hasLost = false;
        battleshipGame.playerTurn = true;
    }
    gameStarted = true;
}

// Main functions

void MyMosaicInit() {
    SetMosaicGridSize(HEIGHT, WIDTH);
}

void MyMosaicUpdate() {
    ClearTiles(0, 0, 0);
    if (!gameStarted){declareGame();}

    switch (currentGame)
    {
    case TIC:
        ticTacToe();
        break;
    case GUESS:
        guessingCard();
        break;
    case MAZE:
        mouseMaze();
        break;
    case BATTLESHIP:
        battleship();
        break;
    default:
        DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "A Critical Error has Occured: Make sure A Game is Selected");
        break;
    }
}