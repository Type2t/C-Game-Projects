
void MyMosaicInit() {
}

void MyMosaicUpdate() {

    // <procedure-name>(<arguments>);
    //           x, y, r, g, b
    SetTileColor(0, 0, 1, 0, 0);
}
