#include <string>
#include <fstream>
#include <iostream>
#include <math.h>
#include <vector>
const real32 screenWidth = 256;
const real32 screenHeight = 256;
int level = 0;

enum tileType {PATH, GRASS, WATER, LAVA, VOID_TILE, FIELD, WALL, DOOR, SPAWN, ERROR_TILE};



struct color{
    float red;
    float green;
    float blue;
};

/*
color** setTileColor(tileType tileT){
    std::ifstream tileFile;
    real32 tileWidth;
    real32 tileHeight;
    if(tileT == PATH){
        tileFile.open("texture_path.dat");
    } else if(tileT == GRASS){
        tileFile.open("texture_path.dat"); //please change
    } else if(tileT == WATER){
        tileFile.open("texture_path.dat"); //please change
    } else if(tileT == LAVA){
        tileFile.open("texture_path.dat"); //please change
    } else if(tileT == VOID_TILE){
        tileFile.open("texture_path.dat"); //please change
    } else if(tileT == FIELD){
        tileFile.open("texture_path.dat"); //please change
    } else if(tileT == WALL){
        tileFile.open("texture_path.dat"); //please change
    } else if(tileT == DOOR){
        tileFile.open("texture_path.dat"); //please change
    } else if(tileT == SPAWN){
        tileFile.open("texture_path.dat"); //please change
    } else {
        tileFile.open("texture_path.dat"); //please change
    }
    std::getline(tileFile, tileWidth);
    std::getline(tileFile, tileHeight);
    color** tempColor = new color*[tileHeight];
    for(real32 y = 0; y < tileHeight; y++){
        tempColor[y] = new color[tileWidth];
        for(real32 x = 0; x < tileWidth; x++){
            std::getline(tileFile, tempColor[x][y].red);
            std::getline(tileFile, tempColor[x][y].green);
            std::getline(tileFile, tempColor[x][y].blue);
        }
    }
    tileFile.close();
    return tempColor;
}
*/

/*
color pathColors;
color grassColors;
color waterColors;
color lavaColors;
color voidColors;
color fieldColors;
color wallColors;
color doorColors;
color spawnColors;
color errorColors;
*/

struct player{
    real32 xPos;
    real32 yPos;
    real32 speed;
    bool acquiredKey;
};
struct screenBounds{
    real32 xLeft;
    real32 xRight;
    real32 yUp;
    real32 yDown;
};

player play = {50,50,10,false};
screenBounds scr = {play.xPos-(screenWidth/2),play.xPos+(screenWidth/2),play.yPos-(screenHeight/2),play.yPos+(screenHeight/2)};


/*
void setTile(tile& a,std::string& str){
    if(str.find("TRUE") == std::string::npos){
        (str == "PATH") ? a.type = PATH : 
        (str == "GRASS") ? a.type = GRASS : 
        (str == "WATER") ? a.type = WATER : 
        (str == "LAVA") ? a.type = LAVA : 
        (str == "VOID_TILE") ? a.type = VOID_TILE : 
        (str == "FIELD") ? a.type = FIELD : 
        (str == "WALL") ? a.type = WALL : 
        (str == "DOOR") ? a.type = DOOR : 
        (str == "SPAWN") ? a.type = SPAWN : a.type = ERROR_TILE;
    }else{
        (str.substr(0,str.find(" ")) == "PATH") ? a.type = PATH : 
        (str.substr(0,str.find(" ")) == "GRASS") ? a.type = GRASS : 
        (str.substr(0,str.find(" ")) == "WATER") ? a.type = WATER : 
        (str.substr(0,str.find(" ")) == "LAVA") ? a.type = LAVA : 
        (str.substr(0,str.find(" ")) == "VOID_TILE") ? a.type = VOID_TILE : 
        (str.substr(0,str.find(" ")) == "FIELD") ? a.type = FIELD : 
        (str.substr(0,str.find(" ")) == "WALL") ? a.type = WALL : 
        (str.substr(0,str.find(" ")) == "DOOR") ? a.type = DOOR : 
        (str.substr(0,str.find(" ")) == "SPAWN") ? a.type = SPAWN : a.type = ERROR_TILE;
        a.hasKey=true;
    }
}

tile** setLevel(const real32 level){
    std::ifstream levelFile;
    real32 levelWidth;
    real32 levelHeight;
    std::string tempString;
    switch (level)
    {
    case 1:
        levelFile.open("level1.dat");
        break;
    default:
        levelFile.open("level1.dat");
    }
    std::getline(levelFile, levelWidth);
    std::getline(levelFile, levelHeight);
    tile** tempTiles = new tile*[levelHeight];
    for(real32 y = 0; y < levelHeight; y++){
        tempTiles[y] = new tile[levelWidth];
        for(real32 x = 0; x < levelWidth; x++){
            std::getline(levelFile, tempString);
            
            setTile(tempTiles[x][y], tempString);
        }
    }
    levelFile.close();
    return tempTiles;
}
*/

struct tile{
    tileType type;
    bool hasKey;
};

std::vector<std::vector<tile>> levelTiles = {{{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{DOOR, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, true},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{SPAWN, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}}};

void drawTile(int& xPos, int& yPos,int& x1, int& x2, int& y1, int& y2,tileType& tileT){
    for (int xTemp = x1; xTemp <= x2; xTemp++){
        for (int yTemp = y1; yTemp <= y2; yTemp++){
            switch (tileT)
            { // {PATH, GRASS, WATER, LAVA, VOID_TILE, FIELD, WALL, DOOR, SPAWN, ERROR_TILE};
            case PATH:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),1.0f,0.9f,0.8f);
                break;
            case GRASS:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.0f,0.75f,0.0f);
                break;
            case WATER:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.0f,0.0f,0.75f);
                break;
            case LAVA:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),1.0f,0.5f,0.0f);
                break;
            case VOID_TILE:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.0f,0.0f,0.0f);
                break;
            case FIELD:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.5f,1.0f,0.0f);
                break;
            case WALL:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.75f,0.75f,0.75f);
                break;
            case DOOR:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.5f,0.25f,0.0f);
                break;
            case SPAWN:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),1.0f,1.0f,0.5f);
                break;
            default:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),1.0f,0.0f,0.0f);
                break;
            }
        }
    }
    

}

int tempXPos, tempYPos, tempX1, tempX2, tempY1, tempY2, tempTileX, tempTileY;
tileType tempTileType;

void changeLevel() {
    if (level == 0) {
        level++;
        for (int tempY = 0; tempY < levelTiles.size(); tempY++) {
            for (int tempX = 0; tempX < levelTiles.at(tempY).size(); tempX++) {
                if (levelTiles.at(tempY).at(tempX).type == SPAWN) {
                    play.xPos = (tempX * 10) + 5;
                    play.yPos = (tempY * 10) + 5;
                }
            }
        }
    }else if (level == 1) {
        level++;
        levelTiles.resize(15, std::vector<tile>(15));
        levelTiles = {
            {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}},
            {{WALL, false},{SPAWN, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, true},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{DOOR, false},{WALL, false}},
            {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}}
        };
        for (int tempY = 0; tempY < levelTiles.size(); tempY++) {
            for (int tempX = 0; tempX < levelTiles.at(tempY).size(); tempX++) {
                if (levelTiles.at(tempY).at(tempX).type == SPAWN) {
                    play.xPos = (tempX * 10) + 5;
                    play.yPos = (tempY * 10) + 5;
                }
            }
        }
    }else if (level == 2) {
        level++;
        levelTiles.resize(15, std::vector<tile>(15));
        levelTiles = {
            {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}},
            {{WALL, false},{SPAWN, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, true},{WALL, false}},
            {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{DOOR, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}}
        };
        for (int tempY = 0; tempY < levelTiles.size(); tempY++) {
            for (int tempX = 0; tempX < levelTiles.at(tempY).size(); tempX++) {
                if (levelTiles.at(tempY).at(tempX).type == SPAWN) {
                    play.xPos = (tempX * 10) + 5;
                    play.yPos = (tempY * 10) + 5;
                }
            }
        }
        
    }
    else if (level >= 3) {
    
    } 
}

void MyMosaicInit() {
    SetMosaicGridSize(screenWidth, screenHeight);
}
int yPrint;
int xPrint;
real32 move;

int tempPlayerXPos;
int tempPlayerYPos;
int tempLeftVoidWidth;
int tempUpVoidHeight;
int endWidth;
int endHeight;

int tempMaxX;
int tempMaxY;
void MyMosaicUpdate() {
    Print("AAAAAAAA1");
    ClearTiles(0, 0, 0);

    move = 30 * DeltaTime;
    if (level == 0) {
        changeLevel();
    }
    //please fix
    Print("AAAAAAAA2");
    tempLeftVoidWidth = (scr.xLeft < 0) ? fabs(scr.xLeft) : 0;
    tempUpVoidHeight = (scr.yUp < 0) ? fabs(scr.yUp) : 0;
    endWidth = (scr.xLeft > 0) ? levelTiles.size() * 10 - scr.xLeft : fabs(scr.xLeft) + levelTiles.size() * 10;
    endHeight = (scr.yUp > 0) ? levelTiles.size() * 10 - scr.yUp : fabs(scr.yUp) + levelTiles.size() * 10;
    Print("AAAAAAAA3");

    tempMaxX=(static_cast<int>(scr.xRight) > scr.xLeft + levelTiles.size() * 10) ? endWidth : screenWidth;
    Print("BBBBBBBBB");
    tempMaxY = (static_cast<int>(scr.yDown) > scr.yUp + levelTiles.size() * 10) ? endHeight : screenHeight;
    Print("AAAAAAAA4");
    for (yPrint = tempUpVoidHeight; yPrint < tempMaxY; yPrint += 10) {
        Print("AAAAAAAA");
        for(xPrint = tempLeftVoidWidth; xPrint < tempMaxX; xPrint += 10) {
            if(xPrint<=0){ 
                tempX1 = static_cast<int>(scr.xLeft) % 10;
                tempX2 = 9;
            }else if(xPrint+10>=screenWidth-1){ //something wrong
                tempX1 = 0;
                tempX2 = screenWidth - (xPrint);
            }else{
                tempX1=0;
                tempX2=9;
            }
            /*if (tempLeftVoidWidth == 0) {
                tempXPos = xPrint-(play.xPos+scr.xLeft);
            }else{
                tempXPos = xPrint;
            }
            */
            tempXPos = xPrint;
            tempTileX = (xPrint + scr.xLeft) / 10;
            if(yPrint<=0){
                tempY1 = static_cast<int>(scr.yUp) % 10;
                tempY2 = 9;
            }else if(yPrint+10>=screenHeight-1){ //something wrongw
                tempY1 = 0;
                tempY2 = screenHeight - (yPrint);
            }else{
                tempY1=0;
                tempY2=9;
            }
            /*if (tempLeftVoidWidth == 0) {
                tempYPos = yPrint - (play.yPos + scr.yUp);
            }
            else {
                tempYPos = yPrint;
            }
            */
            tempYPos = yPrint;
            tempTileY = (yPrint + scr.yUp) / 10;

            Print("%d : %d", tempTileY, tempTileX);
            tempTileType = levelTiles.at(tempTileY).at(tempTileX).type;
     
            drawTile(tempXPos, tempYPos, tempX1, tempX2, tempY1, tempY2, tempTileType);
            if (levelTiles.at(tempTileY).at(tempTileX).hasKey) {
                for (int yTemp2 = tempYPos + 3; yTemp2 < tempYPos + 7; yTemp2++) {
                    for (int xTemp2 = tempXPos + 3; xTemp2 < tempXPos + 7; xTemp2++) {
                        SetTileColor(xTemp2, yTemp2, 1.0f, 1.0f, 0.0f);
                    }
                }
            }
            if (xPrint <= 0) {
                xPrint -= tempX1;
            }
        }
        if(yPrint <= 0) {
            yPrint -= tempY1;
        }
    }
    Print("Part 1 Complete");
    if (InputHeld(Keyboard, Input_W)) {// {PATH, GRASS, WATER, LAVA, VOID_TILE, FIELD, WALL, DOOR, SPAWN, ERROR_TILE};
        //levelTiles.at((play.yPos - 2)/10).at(play.xPos / 10).type != WALL
        if (levelTiles.at((play.yPos - 2) / 10).at(play.xPos / 10).type != WALL && play.yPos >= 3) {
            play.yPos -= move = 30 * DeltaTime;
        }
    }
    Print("Part 2 Complete");
    if (InputHeld(Keyboard, Input_A)) {
        //levelTiles.at(play.yPos / 10).at((play.xPos - 2) / 10).type != WALL
        if (levelTiles.at(play.yPos / 10).at((play.xPos - 2) / 10).type != WALL && play.xPos >= 3) {
            play.xPos -= move = 30 * DeltaTime;
        }
    }
    Print("Part 3 Complete");
    if (InputHeld(Keyboard, Input_S)) {
        //levelTiles.at((play.yPos + 2) / 10).at(play.xPos / 10).type != WALL 
        if (levelTiles.at((play.yPos + 2) / 10).at(play.xPos / 10).type != WALL && play.yPos <= levelTiles.size()*10-2){
            play.yPos += move = 30 * DeltaTime;
        }
    }
    Print("Part 4 Complete");
    if (InputHeld(Keyboard, Input_D)) {
        //levelTiles.at(play.yPos / 10).at((play.xPos + 2) / 10).type != WALL
        if (levelTiles.at(play.yPos / 10).at((play.xPos + 2) / 10).type != WALL && play.xPos<= levelTiles.size() * 10-2){
            play.xPos += move = 30 * DeltaTime;
        }
    }
    Print("Part 5 Complete");
    for (int xtemp = screenWidth/2 - 2; xtemp < screenWidth/2 + 2; xtemp++) {
        for (int ytemp = screenHeight/2 - 2; ytemp < screenHeight/2 + 2; ytemp++) {
            SetTileColor(xtemp, ytemp, 1.0f, 1.0f, 1.0f);
        }
    }
    Print("Part 6 Complete");
    if (levelTiles.at(play.yPos / 10).at(play.xPos / 10).hasKey) {
        play.acquiredKey = true;
        levelTiles.at(play.yPos / 10).at(play.xPos / 10).hasKey = false;
    }
    Print("Part 7 Complete");

    if (levelTiles.at(play.yPos / 10).at(play.xPos / 10).type == DOOR && play.acquiredKey) {
        changeLevel();
    }
    tempPlayerXPos = (int)play.xPos;
    tempPlayerYPos = (int)play.yPos;
    scr = { tempPlayerXPos - (screenWidth / 2),tempPlayerXPos + (screenWidth / 2),tempPlayerYPos - (screenHeight / 2),tempPlayerYPos + (screenHeight / 2) };
    Print("Last Part Complete");
}

