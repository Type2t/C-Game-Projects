//global variables
float colour = 0.0f;

int xPos = 10;
int yPos = 10;

void MyMosaicInit() {
    SetMosaicGridSize(32, 32);
}

void MyMosaicUpdate() {
    ClearTiles(0, 0, 0);

    // top left corner
    SetTileColor(0, 0, 1.0f, 0, 0);
    SetTileColor(1, 0, 0, 1.0f, 0);
    SetTileColor(2, 0, 0, 0, 1.0f);

    //top right
    SetTileColor(31, 0, 1.0f, 1.0f, 0);
    //bottom right
    SetTileColor(31, 31, 0, 1.0f, 1.0f);
    //bottom left
    SetTileColor(0, 31, 1.0f, 0, 1.0f);

    //mouse input
    if (InputPressed(Keyboard, Input_Space)) {
        if (colour < 1.0f) {
            colour += 0.1f;
        }
    }
    if (InputPressed(Keyboard, Input_UpArrow)) {
        if (yPos > 0) {
            yPos--;
        }
    }
    if (InputPressed(Keyboard, Input_DownArrow)) {
        if (yPos < 31) {
            yPos++;
        }
    }
    if (InputPressed(Keyboard, Input_LeftArrow)) {
        if (xPos > 0) {
            xPos--;
        }
    }
    if (InputPressed(Keyboard, Input_RightArrow)) {
        if (xPos < 31) {
            xPos++;
        }
    }
    SetTileColor(xPos, yPos, 0.5f, 0.5f, 0.5f);

    SetTileColor(3, 0, colour, 0, 0);
}

