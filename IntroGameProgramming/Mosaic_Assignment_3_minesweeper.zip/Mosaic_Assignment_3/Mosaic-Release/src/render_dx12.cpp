


void LoadShader(const char *vertSrc, const char *fragSrc, Shader *shader) {
    
}

void CompileShader(Shader *shader, int32 count, const char **uniforms) {
    
}

void InitMesh(Mesh *mesh) {
    
}

void InitFontTable(FontTable *font) {

}

void InitGlyphBuffers(int32 count) {
    
}

void AllocateRectBuffer(int32 capacity, RectBuffer *buffer) {
    
}


void DrawGlyphs(GlyphBuffer *buffers) {

}

void RenderRectBuffer(RectBuffer *buffer) {

}


void DrawRect(vec2 pos, vec2 scale, real32 angle, vec4 color) {
}

void DrawRect(vec2 pos, vec2 scale, vec4 color) {
}

void DrawRectScreen(vec2 pos, vec2 scale, vec4 color) {

}
