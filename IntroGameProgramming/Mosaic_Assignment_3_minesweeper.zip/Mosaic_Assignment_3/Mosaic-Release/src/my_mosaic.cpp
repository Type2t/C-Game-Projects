const int tiles = 15;
const int tileSize = 10;

int correctNum = 0;

bool started = false;
bool lost = false;
bool win = false;


int** setBombs() {
    int** boardTemp = new int*[tiles];
    for(int x = 0; x < tiles; x++){
        boardTemp[x] = new int[tiles];
        for(int y = 0; y < tiles; y++){
            boardTemp[x][y] = (RandiRange(0,15) >= 2) ? 0 : -1;
        }
    }
    for(int x1 = 0; x1 < tiles; x1++){
        for(int y1 = 0; y1 < tiles; y1++){
            for(int x2 = x1-1; x2 <= x1+1; x2++){
                for(int y2 = y1-1; y2 <= y1+1; y2++){
                    if(!((x2 < 0 || x2 > tiles - 1) || (y2 < 0 || y2 > tiles - 1)) && boardTemp[x2][y2] == -1 && boardTemp[x1][y1] != -1 ){
                        boardTemp[x1][y1]++;
                    }
                }
            }
        }
    }
    
    return boardTemp;
}

int** setBoard() {
    int** boardTemp = new int*[tiles];
    for(int x = 0; x < tiles; x++){
        boardTemp[x] = new int[tiles];
        for(int y = 0; y < tiles; y++){
            boardTemp[x][y]=0;
        }
    }
    
    return boardTemp;
}

void basicBlock(int& xBlock, int& yBlock){
    SetTileColor(xBlock*tileSize, yBlock*tileSize, 0.6f, 0.6f, 0.6f);
    for(int i1 = 1; i1 <= 8; i1++){
        SetTileColor(xBlock*tileSize + i1, yBlock*tileSize, 0.9f, 0.9f, 0.9f);
    }
    SetTileColor((xBlock*tileSize)+9, (yBlock*tileSize), 0.6f, 0.6f, 0.6f);

    SetTileColor(xBlock*tileSize, (yBlock*tileSize) + 1, 0.75f, 0.75f, 0.75f);
    for(int i1 = 1; i1 <= 8; i1++){
        SetTileColor(xBlock*tileSize + i1, (yBlock*tileSize) + 1, 0.6f, 0.6f, 0.6f);
    }
    SetTileColor((xBlock*tileSize)+9, (yBlock*tileSize) + 1, 0.9f, 0.9f, 0.9f);

    for(int i2 = 2; i2 <= 7; i2++){
        SetTileColor(xBlock*tileSize, yBlock*tileSize + i2, 0.75f, 0.75f, 0.75f);
        SetTileColor((xBlock*tileSize)+1, yBlock*tileSize + i2, 0.6f, 0.6f, 0.6f);
        for(int i1 = 2; i1 <= 7; i1++){
            SetTileColor(xBlock*tileSize + i1, yBlock*tileSize + i2, 0.9f, 0.9f, 0.9f);
        }
        SetTileColor((xBlock*tileSize)+8, yBlock*tileSize + i2, 0.6f, 0.6f, 0.6f);
        SetTileColor((xBlock*tileSize)+9, (yBlock*tileSize) + i2, 0.9f, 0.9f, 0.9f);
    }

    SetTileColor(xBlock*tileSize, (yBlock*tileSize) + 8, 0.75f, 0.75f, 0.75f);
    for(int i1 = 1; i1 <= 8; i1++){
        SetTileColor(xBlock*tileSize + i1, (yBlock*tileSize) + 8, 0.6f, 0.6f, 0.6f);
    }
    SetTileColor((xBlock*tileSize)+9, (yBlock*tileSize) + 8, 0.9f, 0.9f, 0.9f);

    SetTileColor(xBlock*tileSize, yBlock*tileSize+ 9, 0.6f, 0.6f, 0.6f);
    for(int i1 = 1; i1 <= 8; i1++){
        SetTileColor(xBlock*tileSize + i1, yBlock*tileSize + 9, 0.75f, 0.75f, 0.75f);
    }
    SetTileColor((xBlock*tileSize)+9, (yBlock*tileSize) + 9, 0.6f, 0.6f, 0.6f);
}

int** board= setBoard(); /* 0 = not clicked || 1 = clicked || 2 = flagged */
int** bombs= setBombs(); /* -1 = bomb || 0 = no bomb || nth = nth bomb around tile ||*/

void gameState(){
    correctNum = 0;
    for(int x = 0; x < tiles; x++){
        for(int y = 0; y < tiles; y++){
            if(bombs[x][y] == -1 && board[x][y] == 1){
                lost = true;
            }
            if((bombs[x][y] >= 0 && board[x][y] == 1) || (bombs[x][y] == -1 && board[x][y] == 2)){
                correctNum++;
            }
        }
    }
    if(correctNum == tiles * tiles){
        win = true;
    }
}

void drawBlock(int xBlock, int yBlock){
    if(board[xBlock][yBlock] == 0){
        basicBlock(xBlock,yBlock);
    } else if (board[xBlock][yBlock] == 1 && bombs[xBlock][yBlock] >= 0){
        int tempNum = bombs[xBlock][yBlock];
        for(int y = 1; y <= 7; y += 3){
            for(int x = 1; x <= 7; x += 3){
                if(tempNum > 0){
                    SetTileColor((xBlock*tileSize)+x, (yBlock*tileSize)+y, 0.0f, 0.43f, 1.0f);
                    SetTileColor((xBlock*tileSize)+x+1, (yBlock*tileSize)+y, 0.0f, 0.43f, 1.0f);
                    SetTileColor((xBlock*tileSize)+x, (yBlock*tileSize)+y+1, 0.0f, 0.43f, 1.0f);
                    SetTileColor((xBlock*tileSize)+x+1, (yBlock*tileSize)+y+1, 0.0f, 0.43f, 1.0f);
                    tempNum--;
                }
            }
        }
        
    } else if (board[xBlock][yBlock] == 2){
        basicBlock(xBlock,yBlock);
        for(int y = 0; y < 6; y++){
            SetTileColor(xBlock*tileSize + 3, yBlock*tileSize + 2 + y, 0.0f, 0.0f, 0.0f);
        }
        for(int y = 0; y < 5; y++){
            SetTileColor(xBlock*tileSize + 4, yBlock*tileSize + 2 + y, 1.0f, 0.0f, 0.0f);
        }
        for(int y = 1; y < 4; y++){
            SetTileColor(xBlock*tileSize + 5, yBlock*tileSize + 2 + y, 1.0f, 0.0f, 0.0f);
        }
        SetTileColor(xBlock*tileSize + 6, yBlock*tileSize + 4, 1.0f, 0.0f, 0.0f);
    } else if (board[xBlock][yBlock] == 1 && bombs[xBlock][yBlock] == -1){
        for(int x = 0; x <= 3; x++){
            for(int y = 0; y <= 3; y++){
                SetTileColor(xBlock*tileSize + 3 + x, yBlock*tileSize + 3 + y, 0.0f, 0.0f, 0.0f);
            }
        }
    }
}

void MyMosaicInit() {
    SetMosaicGridSize(tiles * tileSize, tiles * tileSize);
}

void MyMosaicUpdate() {
    ClearTiles(1.0f, 1.0f, 1.0f);
    
    if(!started){
        DrawTextTop(RGB(1.0f, 1.0f, 1.0f), "Minesweeper: left click to press tile, right click to flag tile");
    }
    
    for(int x = 0; x < tiles ; x++){
        for(int y = 0; y < tiles; y++){
            drawBlock(x,y);
        }
    }

    if(!lost && !win){
        if(InputPressed(Mouse, Input_MouseLeft)){
            started=true;
            int32 xMouseTile = GetMousePositionX() / tileSize;
            int32 yMouseTile = GetMousePositionY() / tileSize;
            if(board[xMouseTile][yMouseTile] != 2){
                board[xMouseTile][yMouseTile] = 1;
            }
            gameState();
        }
        if(InputPressed(Mouse, Input_MouseRight)){
            started=true;
            int32 xMouseTile = GetMousePositionX() / tileSize;
            int32 yMouseTile = GetMousePositionY() / tileSize;
            if(board[xMouseTile][yMouseTile] == 2){
                board[xMouseTile][yMouseTile] = 0;
            }
            else if (board[xMouseTile][yMouseTile] == 1) {}
            else {
            board[xMouseTile][yMouseTile] = 2;
            }
            gameState();
        }
    }
    
    if(lost){
        DrawTextTop(RGB(1.0f, 0.0f, 0.0f), "Game Over, Press R to Reset");
    }
    if(win){
        DrawTextTop(RGB(0.0f, 1.0f, 0.0f), "You win, Press R to Reset");
    }

    if(InputPressed(Keyboard, Input_R)){
        board= setBoard();
        bombs= setBombs();
        lost = false;
        win = false;
        correctNum = 0;
    }

    
    
    //SetTileColor(0, 0, 0.8f, 0.2f, 0.4f);
}

