#include <string>
#include <fstream>
#include <iostream>
#include <math.h>
#include <vector>
const real32 screenWidth = 256;
const real32 screenHeight = 256;
int level = 0;

enum tileType {PATH, GRASS, WATER, LAVA, VOID_TILE, FIELD, WALL, DOOR, SPAWN, ERROR_TILE};

enum moveDirection {ATB, BTA, NONE};

struct color{
    float red;
    float green;
    float blue;
};


struct player{
    real32 xPos;
    real32 yPos;
    real32 speed;
    bool acquiredKey;
};

struct point{
    real32 xPos;
    real32 yPos;
};

struct enemy{
    point currentPoint;
    moveDirection xMove = ATB;
    moveDirection yMove = NONE;
    point a;
    point b;
};

struct screenBounds{
    real32 xLeft;
    real32 xRight;
    real32 yUp;
    real32 yDown;
};

player play = {50,50,10,false};
screenBounds scr = {play.xPos-(screenWidth/2),play.xPos+(screenWidth/2),play.yPos-(screenHeight/2),play.yPos+(screenHeight/2)};

struct tile{
    tileType type;
    bool hasKey;
};

std::vector<std::vector<tile>> levelTiles = {{{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{DOOR, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, true},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{FIELD, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{FIELD, false},{SPAWN, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
    {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}}};

std::vector<enemy> enemyList;

void drawTile(int& xPos, int& yPos,int& x1, int& x2, int& y1, int& y2,tileType& tileT){
    for (int xTemp = x1; xTemp <= x2; xTemp++){
        for (int yTemp = y1; yTemp <= y2; yTemp++){
            switch (tileT)
            { // {PATH, GRASS, WATER, LAVA, VOID_TILE, FIELD, WALL, DOOR, SPAWN, ERROR_TILE};
            case PATH:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),1.0f,0.9f,0.8f);
                break;
            case GRASS:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.0f,0.75f,0.0f);
                break;
            case WATER:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.0f,0.0f,0.75f);
                break;
            case LAVA:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),1.0f,0.5f,0.0f);
                break;
            case VOID_TILE:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.0f,0.0f,0.0f);
                break;
            case FIELD:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.5f,1.0f,0.0f);
                break;
            case WALL:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.75f,0.75f,0.75f);
                break;
            case DOOR:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),0.5f,0.25f,0.0f);
                break;
            case SPAWN:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),1.0f,1.0f,0.5f);
                break;
            default:
                SetTileColor(xPos+(xTemp-x1),yPos+(yTemp-y1),1.0f,0.0f,0.0f);
                break;
            }
        }
    }
    

}

int tempXPos, tempYPos, tempX1, tempX2, tempY1, tempY2, tempTileX, tempTileY;
tileType tempTileType;

void changeLevel() {
    if (level == 0) {
        level++;
        for (int tempY = 0; tempY < levelTiles.size(); tempY++) {
            for (int tempX = 0; tempX < levelTiles.at(tempY).size(); tempX++) {
                if (levelTiles.at(tempY).at(tempX).type == SPAWN) {
                    play.xPos = (tempX * 10) + 5;
                    play.yPos = (tempY * 10) + 5;
                }
            }
        }
        enemyList.resize(1);
        enemyList.at(0) = {{10,50},ATB, NONE, {10,50}, {90,50}};
        play.acquiredKey = false;
    }else if (level == 1) {
        level++;
        levelTiles.resize(15, std::vector<tile>(15));
        levelTiles = {
            {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}},
            {{WALL, false},{SPAWN, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, true},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{DOOR, false},{WALL, false}},
            {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}}
        };
        for (int tempY = 0; tempY < levelTiles.size(); tempY++) {
            for (int tempX = 0; tempX < levelTiles.at(tempY).size(); tempX++) {
                if (levelTiles.at(tempY).at(tempX).type == SPAWN) {
                    play.xPos = (tempX * 10) + 5;
                    play.yPos = (tempY * 10) + 5;
                }
            }
        }
        enemyList.resize(5);
        for(real32 i = 0; i < enemyList.size();i++){
            enemyList.at(i) = {{10,50+(i*10)},ATB, NONE, {10,50+(i*10)}, {140,50+(i*10)}};
        }
        play.acquiredKey = false;
    }else if (level == 2) {
        level++;
        levelTiles.resize(25, std::vector<tile>(25));
        levelTiles = {
            {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}},
            {{WALL, false},{SPAWN, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, true},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{DOOR, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{GRASS, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{GRASS, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{PATH, false},{WALL, false}},
            {{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false},{WALL, false}}
        };
        for (int tempY = 0; tempY < levelTiles.size(); tempY++) {
            for (int tempX = 0; tempX < levelTiles.at(tempY).size(); tempX++) {
                if (levelTiles.at(tempY).at(tempX).type == SPAWN) {
                    play.xPos = (tempX * 10) + 5;
                    play.yPos = (tempY * 10) + 5;
                }
            }
        }
        enemyList.resize(18);
        for(real32 i = 0; i < 8;i++){
            enemyList.at(2*i) = {{10,50+(i*20)},ATB, NONE, {10,50+(i*20)}, {240,50+(i*20)}};
        }
        for(real32 i = 0; i < 8;i++){
            enemyList.at((2*i)+1) = {{60+(i*20),10},NONE, ATB, {60+(i*20),10}, {60+(i*20),240}};
        }
        enemyList.at(16) = {{10,240},BTA, ATB, {240,10}, {10,240}};
        enemyList.at(17) = {{240,240},BTA, BTA, {10,10}, {240,240}};
        play.acquiredKey = false;
    }
    else if (level >= 3) {
        level++;
        play.acquiredKey = false;
    } 
}

void moveEnemies(real32 movement){
    for(int i = 0; i < enemyList.size(); i++){
        if(enemyList.at(i).xMove==ATB && enemyList.at(i).currentPoint.xPos< enemyList.at(i).b.xPos){
            enemyList.at(i).currentPoint.xPos += movement;
        }else if(enemyList.at(i).xMove==BTA && enemyList.at(i).currentPoint.xPos>enemyList.at(i).a.xPos){
            enemyList.at(i).currentPoint.xPos -= movement;
        }else{
            enemyList.at(i).xMove = (enemyList.at(i).xMove==ATB) ? BTA : (enemyList.at(i).xMove==BTA) ? ATB : NONE;
        }
    }
    for(int i = 0; i < enemyList.size(); i++){
        if(enemyList.at(i).yMove==ATB && enemyList.at(i).currentPoint.yPos< enemyList.at(i).b.yPos){
            enemyList.at(i).currentPoint.yPos += movement;
        }else if(enemyList.at(i).yMove==BTA && enemyList.at(i).currentPoint.yPos>enemyList.at(i).a.yPos){
            enemyList.at(i).currentPoint.yPos -= movement;
        }else{
            enemyList.at(i).yMove = (enemyList.at(i).yMove==ATB) ? BTA : (enemyList.at(i).yMove==BTA) ? ATB : NONE;
        }
    }

    for(int i = 0; i < enemyList.size(); i++){
        if(enemyList.at(i).currentPoint.yPos>play.yPos-2 && enemyList.at(i).currentPoint.yPos < play.yPos+3 && enemyList.at(i).currentPoint.xPos>play.xPos-2 && enemyList.at(i).currentPoint.xPos < play.xPos+3){
            for (int tempY = 0; tempY < levelTiles.size(); tempY++) {
                for (int tempX = 0; tempX < levelTiles.at(tempY).size(); tempX++) {
                    if (levelTiles.at(tempY).at(tempX).type == SPAWN) {
                        play.xPos = (tempX * 10) + 5;
                        play.yPos = (tempY * 10) + 5;
                    }
                }
            }
        }
    }
}

void MyMosaicInit() {
    SetMosaicGridSize(screenWidth, screenHeight);
}
int yPrint;
int xPrint;
real32 move;

int tempPlayerXPos;
int tempPlayerYPos;
int tempLeftVoidWidth;
int tempUpVoidHeight;
int endWidth;
int endHeight;

int tempMaxX;
int tempMaxY;

tileType tileUp;
tileType tileLeft;
tileType tileDown;
tileType tileRight;

void MyMosaicUpdate() {
    ClearTiles(0, 0, 0);

    move = 30 * DeltaTime;
    if (level == 0) {
        changeLevel();
    }
    //please fix
    tempLeftVoidWidth = (scr.xLeft < 0) ? fabs(scr.xLeft) : 0;
    tempUpVoidHeight = (scr.yUp < 0) ? fabs(scr.yUp) : 0;
    endWidth = (scr.xLeft > 0) ? levelTiles.size() * 10 - scr.xLeft : fabs(scr.xLeft) + levelTiles.size() * 10;
    endHeight = (scr.yUp > 0) ? levelTiles.size() * 10 - scr.yUp : fabs(scr.yUp) + levelTiles.size() * 10;

    tempMaxX=(static_cast<int>(scr.xRight) > scr.xLeft + levelTiles.size() * 10) ? endWidth : screenWidth;
    tempMaxY = (static_cast<int>(scr.yDown) > scr.yUp + levelTiles.size() * 10) ? endHeight : screenHeight;
    for (yPrint = tempUpVoidHeight; yPrint < tempMaxY; yPrint += 10) {
        for(xPrint = tempLeftVoidWidth; xPrint < tempMaxX; xPrint += 10) {
            if(xPrint<=0){ 
                tempX1 = static_cast<int>(scr.xLeft) % 10;
                tempX2 = 9;
            }else if(xPrint+10>=screenWidth-1){
                tempX1 = 0;
                tempX2 = screenWidth - (xPrint);
            }else{
                tempX1=0;
                tempX2=9;
            }
            tempXPos = xPrint;
            tempTileX = (xPrint + scr.xLeft) / 10;
            if(yPrint<=0){
                tempY1 = static_cast<int>(scr.yUp) % 10;
                tempY2 = 9;
            }else if(yPrint+10>=screenHeight-1){
                tempY1 = 0;
                tempY2 = screenHeight - (yPrint);
            }else{
                tempY1=0;
                tempY2=9;
            }
            tempYPos = yPrint;
            tempTileY = (yPrint + scr.yUp) / 10;

            Print("%d : %d", tempTileY, tempTileX);
            tempTileType = levelTiles.at(tempTileY).at(tempTileX).type;
     
            drawTile(tempXPos, tempYPos, tempX1, tempX2, tempY1, tempY2, tempTileType);
            if (levelTiles.at(tempTileY).at(tempTileX).hasKey) {
                for (int yTemp2 = tempYPos + 3; yTemp2 < tempYPos + 7; yTemp2++) {
                    for (int xTemp2 = tempXPos + 3; xTemp2 < tempXPos + 7; xTemp2++) {
                        SetTileColor(xTemp2, yTemp2, 1.0f, 1.0f, 0.0f);
                    }
                }
            }

            if (xPrint <= 0) {
                xPrint -= tempX1;
            }
        }
        if(yPrint <= 0) {
            yPrint -= tempY1;
        }
    }

    for(enemy Ene: enemyList){
        if(static_cast<int>((-1*scr.xLeft)+Ene.currentPoint.xPos) >= 2 && static_cast<int>((-1*scr.xLeft)+Ene.currentPoint.xPos) <= tempMaxX && static_cast<int>((-1*scr.yUp)+Ene.currentPoint.yPos) >= 2 && static_cast<int>((-1*scr.yUp)+Ene.currentPoint.yPos <= tempMaxY)){
            for (int yTemp2 = static_cast<int>((-1*scr.yUp)+Ene.currentPoint.yPos) - 2; yTemp2 < static_cast<int>((-1*scr.yUp)+Ene.currentPoint.yPos) + 2; yTemp2++) {
                for (int xTemp2 = static_cast<int>((-1*scr.xLeft)+Ene.currentPoint.xPos) - 2; xTemp2 < static_cast<int>((-1*scr.xLeft)+Ene.currentPoint.xPos) + 2; xTemp2++) {
                    SetTileColor(xTemp2, yTemp2, 1.0f, 0.0f, 0.0f);
                }
            }
        }
    }

    // logic
    moveEnemies(move);

    tileUp = levelTiles.at((play.yPos - 3) / 10).at(play.xPos / 10).type;
    tileLeft = levelTiles.at(play.yPos / 10).at((play.xPos - 3) / 10).type;
    tileDown = levelTiles.at((play.yPos + 2) / 10).at(play.xPos / 10).type;
    tileRight = levelTiles.at(play.yPos / 10).at((play.xPos + 2) / 10).type;
    if (InputHeld(Keyboard, Input_W)) {// {PATH, GRASS, WATER, LAVA, VOID_TILE, FIELD, WALL, DOOR, SPAWN, ERROR_TILE};
        if (tileUp != WALL && tileUp != VOID_TILE && play.yPos >= 3) {
            play.yPos -= move = 30 * DeltaTime;
        }
    }
    if (InputHeld(Keyboard, Input_A)) {
        if (tileLeft != WALL && tileLeft != VOID_TILE && play.xPos >= 3) {
            play.xPos -= move = 30 * DeltaTime;
        }
    }
    if (InputHeld(Keyboard, Input_S)) {
        if (tileDown != WALL && tileDown != VOID_TILE && play.yPos <= levelTiles.size()*10-2){
            play.yPos += move = 30 * DeltaTime;
        }
    }
    if (InputHeld(Keyboard, Input_D)) {
        if (tileRight != WALL && tileRight != VOID_TILE && play.xPos<= levelTiles.size() * 10-2){
            play.xPos += move = 30 * DeltaTime;
        }
    }
    for (int xtemp = screenWidth/2 - 2; xtemp < screenWidth/2 + 2; xtemp++) {
        for (int ytemp = screenHeight/2 - 2; ytemp < screenHeight/2 + 2; ytemp++) {
            SetTileColor(xtemp, ytemp, 1.0f, 1.0f, 1.0f);
        }
    }
    if (levelTiles.at(play.yPos / 10).at(play.xPos / 10).hasKey) {
        play.acquiredKey = true;
        levelTiles.at(play.yPos / 10).at(play.xPos / 10).hasKey = false;
    }

    if (levelTiles.at(play.yPos / 10).at(play.xPos / 10).type == DOOR && play.acquiredKey) {
        changeLevel();
    }
    tempPlayerXPos = (int)play.xPos;
    tempPlayerYPos = (int)play.yPos;
    scr = { tempPlayerXPos - (screenWidth / 2),tempPlayerXPos + (screenWidth / 2),tempPlayerYPos - (screenHeight / 2),tempPlayerYPos + (screenHeight / 2) };

    if(level > 3){
        DrawTextTop(RGB(0.0f, 1.0f, 0.0f), "YOU WIN!!!!!");
    }
}

