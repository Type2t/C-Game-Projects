Adventure Puzzle Game
---
Main Objectives
1. Exploration
2. multi-level maps
3. Use structs and enums to declare places.
Code breakdown
1. use structs when establishing a 2d array of tiles.
2. set enums to check the state of the tile such as-
    -  Path Tile
    -  Wall Tile
    -  Grass Tile
    -  Key Tile
    -  water Tile
    -  Enemy Tile
    -  Lava Tile
    -  Void TIle
    -  and Bridge TIle
3. Make the map move with the player and have the map bigger than the Preset 256x256 size of the window.
4. Make pop up text appear when you need to do input
5. have a text box with possible character design
6. make character
7. make an end goal of escaping
8. win!
