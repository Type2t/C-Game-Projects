unsigned int WIDTH = 160;
unsigned int HEIGHT = 90;

float32 red = 0.0f;
bool red_increasing = true;
float32 green = 0.5f;
bool green_increasing = true;
float32 blue = 1.0f;
bool blue_increasing = false;

real32 xPos = 2.0f;
real32 yPos = 2.0f;
bool x_increasing = true;
bool y_increasing = true;

void MyMosaicInit() {
    SetMosaicGridSize(WIDTH, HEIGHT);
}

void MyMosaicUpdate() {
    ClearTiles(0, 0, 0);

    red_increasing = (!(red >= 0.0f && red <= 1.0f)) ? !red_increasing : red_increasing;
    green_increasing = (!(green >= 0.0f && green <= 1.0f)) ? !green_increasing : green_increasing;
    blue_increasing = (!(blue >= 0.0f && blue <= 1.0f)) ? !blue_increasing : blue_increasing;
    if (red < 0.0f){red = 0.0f;} if (red > 1.0){red = 1.0;}
    if (green < 0.0f){green = 0.0f;} if (green > 1.0){green = 1.0;}
    if (blue < 0.0f){blue = 0.0f;} if (blue > 1.0){blue = 1.0;}
    red += (red_increasing) ? (DeltaTime) : -1 * (DeltaTime);
    green += (green_increasing) ? (DeltaTime) : -1 * (DeltaTime);
    blue += (blue_increasing) ? (DeltaTime) : -1 * (DeltaTime);

    x_increasing = (!(xPos >= 2 && xPos <= WIDTH - 3)) ? !x_increasing : x_increasing;
    y_increasing = (!(yPos >= 2 && yPos <= HEIGHT - 3)) ? !y_increasing : y_increasing;
    if (xPos < 2.0f){xPos = 2.0f;} if (xPos > WIDTH - 3){xPos = WIDTH - 3;}
    if (yPos < 2.0f){yPos = 2.0f;} if (yPos > HEIGHT - 3){yPos = HEIGHT - 3;}
    xPos += (x_increasing) ? (60 * DeltaTime) : -1 * (60 * DeltaTime);
    yPos += (y_increasing) ? (60 * DeltaTime) : -1 * (60 * DeltaTime);
    
    Print("---");
    Print("The value of xPos is %0.4f", xPos);
    Print("The value of yPos is %0.4f", yPos);
    Print("The value of red is %0.4f", red);
    Print("The value of green is %0.4f", green);
    Print("The value of blue is %0.4f", blue);
    Print("---");

    for(float32 x = xPos - 2; x <= xPos + 2; x++){
        for(float32 y = yPos - 2; y <= yPos + 2; y++){
            SetTileColor(x, y, red, green, blue);
        }
    }



}

