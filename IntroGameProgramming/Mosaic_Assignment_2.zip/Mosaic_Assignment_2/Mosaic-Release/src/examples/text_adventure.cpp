
struct TextGame {
    
};

TextAdventure textGame = {};

MyGameUpdate() {
    
}
