#include<vector>

const int WIDTH =   100;
const int HEIGHT =  100;
int modeIndex = 0;
int i;
int x;
int y;



struct tileElements{
    real32 xPos;
    real32 yPos;
    float32 red;
    float32 green;
    float32 blue;
};

//tileElements* modeList[];
std::vector<tileElements> modeList;

void Mode1(){
    modeList.clear();
    modeList.resize(10);

    for(i = 0; i < modeList.size(); i++){
        modeList.at(i).xPos = RandiRange(0,WIDTH);
        modeList.at(i).yPos = RandiRange(0,HEIGHT);
        modeList.at(i).red = RandfRange(0.0f,1.0f);
        modeList.at(i).green = RandfRange(0.0f,1.0f);
        modeList.at(i).blue = RandfRange(0.0f,1.0f);
    }
}

void Mode2() {
    modeList.clear();
    modeList.resize(10);

    for (i = 0; i < modeList.size(); i++) {
        modeList.at(i).xPos = i;
        modeList.at(i).yPos = 0;
        modeList.at(i).red = RandfRange(0.0f, 1.0f);
        modeList.at(i).green = 0.0f;
        modeList.at(i).blue = 0.0f;
    }
}
void Mode3() {
    modeList.clear();
    modeList.resize(10);

    for (i = 0; i < modeList.size(); i++) {
        modeList.at(i).xPos = i;
        modeList.at(i).yPos = i;
        modeList.at(i).red = (0.5f*((i*1.0)/modeList.size()))+0.5f;
        modeList.at(i).green = 0.0f;
        modeList.at(i).blue = 0.0f;
    }
}

void Mode4() {
    modeList.clear();
    modeList.resize(25);

    for (y = 0; y < 5; y++) {
        for (x = 0; x < 5; x++) {
            modeList.at(y * 5 + x).xPos = x;
            modeList.at(y * 5 + x).yPos = y;
            modeList.at(y * 5 + x).red = RandfRange(0.0f, 1.0f);
            modeList.at(y * 5 + x).green = RandfRange(0.0f, 1.0f);
            modeList.at(y * 5 + x).blue = RandfRange(0.0f, 1.0f);
        }
    }
}

void Mode5(int xPosition, int yPosition) {
    modeList.clear();
    modeList.resize(25);

    for (y = yPosition; y < yPosition + 5; y++) {
        for (x = xPosition; x < xPosition + 5; x++) {
            modeList.at((y - yPosition) * 5 + (x - xPosition)).xPos = x;
            modeList.at((y - yPosition) * 5 + (x - xPosition)).yPos = y;
            modeList.at((y - yPosition) * 5 + (x - xPosition)).red = RandfRange(0.0f, 1.0f);
            modeList.at((y - yPosition) * 5 + (x - xPosition)).green = RandfRange(0.0f, 1.0f);
            modeList.at((y - yPosition) * 5 + (x - xPosition)).blue = RandfRange(0.0f, 1.0f);
        }
    }
}

void Mode6() {
    modeList.clear();
    modeList.resize(WIDTH* HEIGHT);
    float tempColorVal;

    for (y = 0; y < HEIGHT; y++) {
        for (x = 0; x < WIDTH; x++) {
            tempColorVal = RandfRange(0.0f, 1.0f);
            modeList.at(y * WIDTH + x).xPos = x;
            modeList.at(y * WIDTH + x).yPos = y;
            modeList.at(y * WIDTH + x).red = tempColorVal;
            modeList.at(y * WIDTH + x).green = tempColorVal;
            modeList.at(y * WIDTH + x).blue = tempColorVal;
        }
    }
}

void Mode7() {
    modeList.clear();
    modeList.resize(WIDTH * HEIGHT);

    for (y = 0; y < HEIGHT; y++) {
        for (x = 0; x < WIDTH; x++) {
            modeList.at(y * WIDTH + x).xPos = x;
            modeList.at(y * WIDTH + x).yPos = y;
            modeList.at(y * WIDTH + x).red = RandfRange(0.0f, 1.0f);
            modeList.at(y * WIDTH + x).green = RandfRange(0.0f, 1.0f);
            modeList.at(y * WIDTH + x).blue = RandfRange(0.0f, 1.0f);
        }
    }
}

void Mode8(float minRed, float maxRed, float minGreen, float maxGreen, float minBlue, float maxBlue) {
    modeList.clear();
    modeList.resize(WIDTH * HEIGHT);

    for (y = 0; y < HEIGHT; y++) {
        for (x = 0; x < WIDTH; x++) {
            modeList.at(y * WIDTH + x).xPos = x;
            modeList.at(y * WIDTH + x).yPos = y;
            modeList.at(y * WIDTH + x).red = RandfRange(minRed, maxRed);
            modeList.at(y * WIDTH + x).green = RandfRange(minGreen, maxGreen);
            modeList.at(y * WIDTH + x).blue = RandfRange(minBlue, maxBlue);
        }
    }
}

void MyMosaicInit() {
    SetMosaicGridSize(WIDTH, HEIGHT);
}

void MyMosaicUpdate() {
    if (InputPressed(Keyboard, Input_Space)) {
        if (modeIndex == 1) {
            Mode1();
        }else if (modeIndex == 2){
            Mode2();
        }else if (modeIndex == 3) {
            Mode3();
        }else if (modeIndex == 4) {
            Mode4();
        }else if (modeIndex == 5) {
            Mode5(20,20);
        }else if (modeIndex == 6) {
            Mode6();
        }else if (modeIndex == 7) {
            Mode7();
        }else if (modeIndex == 8) {
            Mode8(0.4f, 0.6f, 0.4f, 0.6f, 0.4f, 0.6f);
        }
        if (modeIndex >= 1 && modeIndex <= 7) {
            modeIndex++;
        }else {
            modeIndex = 1;
        }
    }
    // Loop over the elements in your array and call SetTileColor
    for (int i = 0; i < modeList.size(); i++) {
        SetTileColor(modeList.at(i).xPos, modeList.at(i).yPos, modeList.at(i).red, modeList.at(i).green, modeList.at(i).blue);
    }
}

