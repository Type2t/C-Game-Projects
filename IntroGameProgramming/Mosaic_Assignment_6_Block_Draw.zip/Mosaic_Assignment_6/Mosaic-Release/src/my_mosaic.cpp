#include <vector>

const int       WIDTH     = 100;
const int       HEIGHT    = 100;

unsigned int    MODE      = 0;

struct color {
    float32 r;
    float32 g;
    float32 b;
};

struct colorChannelBool{
    bool r;
    bool g;
    bool b;
};

void DrawColoredLine(int32 xPos, int32 yPos, int32 len, color rgb){
    for(int i = 0; i < len; i++){
        SetTileColor(xPos+i, yPos, rgb.r, rgb.g, rgb.b);
    }
}

void DrawCheckeredLine(int32 xPos, int32 yPos, int32 len, color rgb1, color rgb2){
    for(int i = 0; i < len; i++){
        if((xPos+i) % 2 == (xPos%2)){
            SetTileColor(xPos+i, yPos, rgb1.r, rgb1.g, rgb1.b);
        }else{
            SetTileColor(xPos+i, yPos, rgb2.r, rgb2.g, rgb2.b);
        }
    }
}

void Draw3SegmentLine(int32 xPos, int32 yPos, int32 len, color rgb1, color rgb2, color rgb3){
    std::vector<color> tempColors = {rgb1,rgb2,rgb3};
    int tempIndex = 0;
    for(int i = 0; i < len; i += len/3){
        DrawColoredLine(xPos+i, yPos, len/3, tempColors.at(tempIndex));
        tempIndex++;
    }
}

void DrawBox(int32 xPos, int32 yPos, int32 xLen, int32 yLen, color rgb){
    for(int x = 0; x < xLen; x++){
        for(int y = 0; y < yLen; y++){
            SetTileColor(xPos+x, yPos+y, rgb.r, rgb.g, rgb.b); 
        }
    }
}

void DrawStrippedBox(int32 xPos, int32 yPos, int32 xLen, int32 yLen, color rgb1, color rgb2){
    for(int y = 0; y < yLen; y++){
        if(y%2==0){
            DrawBox(xPos, yPos+y, xLen, 1, rgb1);
        }else{
            DrawBox(xPos, yPos+y, xLen, 1, rgb2);
        }
    }
}

void DrawCheckeredBox(int32 xPos, int32 yPos, int32 xLen, int32 yLen, color rgb1, color rgb2){
    for(int x = 0; x < xLen; x++){
        for(int y = 0; y < yLen; y++){
            if((x+y)%2==0){
                SetTileColor(xPos+x, yPos+y, rgb1.r, rgb1.g, rgb1.b); 

            }else{
                SetTileColor(xPos+x, yPos+y, rgb2.r, rgb2.g, rgb2.b); 
            }
        }
    }
}

float calcColor(float num, float length){
    return -(num/length)+1;
}

void DrawLeftRightFadeBox(int32 xPos, int32 yPos, int32 xLen, int32 yLen, color rgb, colorChannelBool channel, bool reverse){
    if(!reverse){
        for(float x = 0; x <= xLen-1; x++){
            if(channel.r){
                DrawBox(xPos+x, yPos, 1, yLen, {x/(xLen-1),rgb.g,rgb.b});
            }else if(channel.g){
                DrawBox(xPos+x, yPos, 1, yLen, {rgb.r,x/(xLen-1),rgb.b});
            }else if(channel.b){
                DrawBox(xPos+x, yPos, 1, yLen, {rgb.r,rgb.g,x/(xLen-1)});
            }
        }
    }else{
        for(float x = 0; x <= xLen-1 ; x++){
            if(channel.r){
                DrawBox(xPos+x, yPos, 1, yLen, {calcColor(x,xLen),rgb.g,rgb.b});
            }else if(channel.g){
                DrawBox(xPos+x, yPos, 1, yLen, {rgb.r,calcColor(x,xLen),rgb.b});
            }else if(channel.b){
                DrawBox(xPos+x, yPos, 1, yLen, {rgb.r,rgb.g,calcColor(x,xLen)});
            }
        }
    }
    
}

void DrawTopBottomFadeBox(int32 xPos, int32 yPos, int32 xLen, int32 yLen, color rgb, colorChannelBool channel){
    for(float y = 0; y <= yLen-1; y++){
            if(channel.r){
                DrawBox(xPos, yPos+y, xLen, 1, {y/(yLen-1),rgb.g,rgb.b});
            }else if(channel.g){
                DrawBox(xPos, yPos+y, xLen, 1, {rgb.r,y/(yLen-1),rgb.b});
            }else if(channel.b){
                DrawBox(xPos, yPos+y, xLen, 1, {rgb.r,rgb.g,y/(yLen-1)});
            }
        }
}

void DrawLeftToRightMiddleFadeBox(int32 xPos, int32 yPos, int32 xLen, int32 yLen, color rgb, colorChannelBool channel){
    DrawLeftRightFadeBox(xPos, yPos, (xLen/2), yLen, rgb, channel, false);
    DrawLeftRightFadeBox(xPos+(xLen/2), yPos, (xLen/2), yLen, rgb, channel, true);
}

void MyMosaicInit() {
    SetMosaicGridSize(WIDTH, HEIGHT);
}

//SetTileColor(x, y, r, g, b);

void MyMosaicUpdate() {
    ClearTiles(0, 0, 0);
    if (InputPressed(Keyboard, Input_Space)) {
        MODE++;
    }
   switch (MODE)
   {
    case 0:
        DrawColoredLine(0, 20, 30, {1.0f, 0.0f, 0.0f}); // right
        break;
    case 1:
        DrawCheckeredLine(0, 20, 30, {1.0f, 0.0f, 0.0f}, {0.0f, 0.0f, 0.0f}); //right
        break;
    case 2:
        DrawCheckeredLine(0, 20, 30, {1.0f, 0.0f, 1.0f}, {1.0f, 0.0f, 0.0f}); //right
        break;
    case 3:
        Draw3SegmentLine(0, 20, 30, {1.0f, 0.0f, 0.0f}, {1.0f, 1.0f, 0.0f}, {0.0f, 1.0f, 0.0f}); //right
        break;
    case 4:
        DrawBox(0, 20, 30, 30, {1.0f, 1.0f, 1.0f}); //right
        break;
    case 5:
        DrawStrippedBox(0, 20, 30, 30, {0.0f,0.0f,1.0f},{1.0f,0.5f,0.0f}); // right
        break;
    case 6:
        DrawCheckeredBox(0, 20, 30, 30, {0.0f,0.0f,1.0f},{1.0f,0.5f,0.0f}); // right
        break;
    case 7:
        DrawLeftRightFadeBox(0, 20, 30, 30, {0.0f,0.0f,1.0f}, {true, false, false}, false); // right
        break;
    case 8:
        DrawTopBottomFadeBox(0, 20, 30, 30, {0.0f,0.0f,1.0f}, {true, false, false}); // right
        break;
    case 9:
        DrawLeftToRightMiddleFadeBox(0, 20, 30, 30, {0.0f,0.0f,1.0f}, {true, false, false}); // wrong
        break;
    default: MODE = 0; break;
   }
}

