
void MyMosaicInit() {
    SetMosaicGridSize(9, 9);
}

void MyMosaicUpdate() {
    real32 red = 0.5f;
    SetTileColor(4, 4, red, 0, 0);
    SetTileColor(3, 5, red, 0, 0);
    SetTileColor(5, 5, red, 0, 0);

    //SetTileColor(5, 4, red, 0, 0);

    //SetTileColor(Time, 4, red, 0, 0);
    
    // variables based on time
    // sinf
    // 
}
