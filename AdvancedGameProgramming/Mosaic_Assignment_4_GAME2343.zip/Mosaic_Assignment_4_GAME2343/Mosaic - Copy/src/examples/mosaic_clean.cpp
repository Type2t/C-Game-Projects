
void MyMosaicInit() {
    SetMosaicGridSize(16, 16);
}

void MyMosaicUpdate() {
    
}
