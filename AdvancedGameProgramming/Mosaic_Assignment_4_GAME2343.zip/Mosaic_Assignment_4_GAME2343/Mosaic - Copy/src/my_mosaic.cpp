// change Size, Buffer, and 
const int BORDER_SIZE = 10;
const int PICTURE_SIZE = 50; // Min 25 - Max 113 pixels

const int MAX_BUFFER = PICTURE_SIZE*PICTURE_SIZE;
const int IMAGE_COUNT = 4;

const int WIDTH = BORDER_SIZE*3 + PICTURE_SIZE*2;
const int HEIGHT = BORDER_SIZE*3 + PICTURE_SIZE*2;

vec4* colorBuffer1;
vec4* colorBuffer2;
vec4* colorBuffer3;
vec4* colorBuffer4;
int32* sizeBuffers;

void allocateBuffers(){
    colorBuffer1 = (vec4*)malloc(sizeof(vec4)*MAX_BUFFER);
    colorBuffer2 = (vec4*)malloc(sizeof(vec4)*MAX_BUFFER);
    colorBuffer3 = (vec4*)malloc(sizeof(vec4)*MAX_BUFFER);
    colorBuffer4 = (vec4*)malloc(sizeof(vec4)*MAX_BUFFER);
    sizeBuffers = (int32*)malloc(sizeof(int32)*IMAGE_COUNT);
}

void randomizeRandomizeBuffer(vec4* selectedBuffer, vec4 range1, vec4 range2){
    for(int currentBuffer = 0; currentBuffer < MAX_BUFFER; currentBuffer++){
        selectedBuffer[currentBuffer].r = RandfRange(range1.r,range2.r); 
        selectedBuffer[currentBuffer].g = RandfRange(range1.g,range2.g); 
        selectedBuffer[currentBuffer].b = RandfRange(range1.b,range2.b); 
        selectedBuffer[currentBuffer].a = RandfRange(range1.a,range2.a); 
    }
}

void randomizeBuffers(){
    randomizeRandomizeBuffer(colorBuffer1, {0.72f,0.72f,0.72f,1.0f},{1.0f,1.0f,1.0f,1.0f}); // Pastel Colors
    randomizeRandomizeBuffer(colorBuffer2, {1.0f,1.0f,1.0f,0.0f},{1.0f,1.0f,1.0f,1.0f}); // Monochrome Colors
    randomizeRandomizeBuffer(colorBuffer3, {0.0f,0.0f,0.0f,0.0f},{1.0f,1.0f,1.0f,0.4f}); // Dark Colors
    randomizeRandomizeBuffer(colorBuffer4, {0.0f,0.0f,0.0f,0.0f},{1.0f,1.0f,1.0f,1.0f}); // All Colors
    for(int currentBuffer = 0; currentBuffer < IMAGE_COUNT; currentBuffer++){
        sizeBuffers[currentBuffer] = RandiRange(PICTURE_SIZE-25,PICTURE_SIZE); 
    }
}

void drawBlockBuffer(int CORNER_NEAR_CENTER_X, int CORNER_NEAR_CENTER_Y, bool POSI_X, bool POSI_Y, vec4* selectedColBuf, int BLOCKNUM){
    for(int BlockX = 0; BlockX < sizeBuffers[BLOCKNUM]; BlockX++){
        for(int BlockY = 0; BlockY < sizeBuffers[BLOCKNUM]; BlockY++){
            SetTileColor(CORNER_NEAR_CENTER_X + BlockX * ((POSI_X)?1:-1), CORNER_NEAR_CENTER_Y + BlockY * ((POSI_Y)?1:-1), selectedColBuf[BlockY*sizeBuffers[BLOCKNUM] + BlockX]);
        }
    }
}

void drawBuffers(){
    drawBlockBuffer(BORDER_SIZE+PICTURE_SIZE-1,BORDER_SIZE+PICTURE_SIZE-1,false,false,colorBuffer1,0);
    drawBlockBuffer(2*BORDER_SIZE+PICTURE_SIZE,BORDER_SIZE+PICTURE_SIZE-1,true,false,colorBuffer2,1);
    drawBlockBuffer(BORDER_SIZE+PICTURE_SIZE-1,2*BORDER_SIZE+PICTURE_SIZE,false,true,colorBuffer3,2);
    drawBlockBuffer(2*BORDER_SIZE+PICTURE_SIZE,2*BORDER_SIZE+PICTURE_SIZE,true,true,colorBuffer4,3);
}

void MyMosaicInit() {
    SetMosaicGridSize(WIDTH, HEIGHT);

    allocateBuffers();
    randomizeBuffers();
}

void MyMosaicUpdate() {
    ClearTiles(0.2f,0.2f,0.2f);
    if(InputPressed(Keyboard, Input_Space)){
        randomizeBuffers();
    }
    drawBuffers();
}
