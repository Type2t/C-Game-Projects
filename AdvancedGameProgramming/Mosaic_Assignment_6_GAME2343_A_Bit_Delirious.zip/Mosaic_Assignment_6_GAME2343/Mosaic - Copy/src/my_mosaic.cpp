#include <fstream>
#include <vector>
#include <math.h>

SoundClip songFile;
SoundHandle songHan;

const int32 WIDTH = 250;
const int32 HEIGHT = 250;

enum obsticleType {RAMP_CAR, CAR, BUS, BARRIER, NO_OBSTICLE};
enum kwb_click {
    UP_CLICK,
    RIGHT_CLICK,
    DOWN_CLICK,
    LEFT_CLICK
};
enum world_block_type {NO_BLOCK, WALL, LAVA, GOO, WATER, START, END, VOID_BLOCK};
enum button_destination {START_BUTTON, MAIN_BUTTON, RESTART_BUTTON};

struct simple_block{
    vec2 gamePos1;
    vec2 gamePos2;
};

struct arrow_click{
    kwb_click key;
    real32 time;
};

struct moving_block{
    real32 obsticleWidth;
    real32 timeTilMid;

    int32 line;

    obsticleType obs;
    bool clicked;
};

struct world_block{
    simple_block tile;

    world_block_type tile_type;
};

struct point
{
    vec2 pos;
    vec4 color;
};

struct button{
    vec2 center;
    vec2 pos1;
    vec2 pos2;

    char* text;
};

struct current_player{
    vec2 pos;
    vec2 worldPos;

    int32 currentLine= 1;
    int32 currentLayer = 0;

    bool activeMovement;
};

struct baseGame{
    int32 currentLevel = 0;
    int32 score = 0;

    real32 time = 0.0f;

    vec2 currentSize = {250, 250};

    char* name;
    char* songPath;


    int32 soundInd;

    current_player player;

    DynamicArray<moving_block> game1Buffer;

    DynamicArray<world_block> game2Buffer;
    DynamicArray<point> pointsBuff;

    DynamicArray<moving_block> game3Buffer;
    DynamicArray<arrow_click> game3Clicks;

    bool gameStarted = false;
    bool gameLost = false;
    bool gameWon = false;
    bool completed = false;
};

MemoryArena worldspaceArena = {};
void* currentGameData;
baseGame* currentGame;

void* currentButtonData;
button* currentButtons;

void winLevel(){
    Game->audioPlayer = {};
    songFile = {};
    songHan = {};
    currentGame -> gameWon = true;
    AudioPlayerInit(&Game->audioPlayer, &Game->permanentArena);
}

void loseLevel(){
    Game->audioPlayer = {};
    songFile = {};
    songHan = {};
    currentGame -> gameLost = true;
    AudioPlayerInit(&Game->audioPlayer, &Game->permanentArena);
}


inline void StartUpMemoryArenas(int size){
    AllocateMemoryArena(&worldspaceArena, Megabytes(size));

    currentGameData = PushSize(&worldspaceArena, sizeof(baseGame));
    currentGame = (baseGame *)currentGameData;
    *currentGame = {};
}

inline void DrawHollowBlock(vec2 point1, vec2 point2, vec4 color){
    for(int x = point1.x; x < point2.x; x++){
        SetTileColor(x, point1.y, color);
        SetTileColor(x, point2.y-1, color);
    }
    for(int y = point1.y+1; y < point2.y-1; y++){
        SetTileColor(point1.x, y, color);
        SetTileColor(point2.x-1, y, color);
    }
}

inline void DrawFullBlock(vec2 point1, vec2 point2, vec4 color1){
    for(int x = point1.x; x <= point2.x; x++){
        for(int y = point1.y; y <= point2.y; y++){
            SetTileColor(x, y, color1);
        }
    }
}

inline void DrawFullBlock(vec2 point1, vec2 point2, vec4 color1, vec4 color2){
    for(int x = point1.x; x <= point2.x; x++){
        for(int y = point1.y; y <= point2.y; y++){
            SetTileColor(x, y, {RandfRange(color1.r,color2.r),RandfRange(color1.g,color2.g),RandfRange(color1.b,color2.b),RandfRange(color1.a,color2.a)});
        }
    }
}

button* SetDefaultButton(void* curButDat, button* curBut){
    curButDat = PushSize(&worldspaceArena, sizeof(button));
    curBut = (button*)curButDat;

    curBut -> center = {currentGame -> currentSize.x/2.0f, currentGame -> currentSize.y/2.0f};
    curBut -> pos1 = {
        curBut -> center.x - 40
        ,
        curBut -> center.y - 15
    };
    curBut -> pos2 = {
        curBut -> center.x + 39
        ,
        curBut -> center.y + 14
    };
    
    curBut -> text = "Start";

    return curBut;
}

inline void LoadExternalFileData(){
    std::vector<std::string> tempMapList;
    std::string tempLine;
    world_block tempworldblock;
    moving_block tempblock;
    int lineCount;
    int tempEnum;
    int tempBool;
    if(currentGame -> currentLevel == 1){
        std::ifstream file("data/surf_data.dat");
        if(file.is_open()){
            file >> lineCount;
            currentGame -> game1Buffer = MakeDynamicArray<moving_block>(&worldspaceArena, lineCount);
            for(int i = 0; i < lineCount; i++){
                file >> tempblock.obsticleWidth;
                file >> tempblock.timeTilMid;
                file >> tempblock.line;
                file >> tempEnum;

                tempblock.obs = static_cast<obsticleType>(tempEnum);

                PushBack(&currentGame -> game1Buffer, tempblock);
            }
        }

        file.close();
        LoadSoundClip("data/sfx/subway-surfers.wav", &songFile);
    }else if(currentGame -> currentLevel == 2){
        std::ifstream file("data/lidae_level.dat");
        if(file.is_open()){
            file >> lineCount;
            currentGame -> game2Buffer = MakeDynamicArray<world_block>(&worldspaceArena, lineCount);
            currentGame -> pointsBuff = MakeDynamicArray<point>(&worldspaceArena, lineCount);
            for(int i = 0; i < lineCount; i++){
                // TODO: read lidar map
                for(int i2 = 0; i2 < lineCount; i2++){
                    tempworldblock.tile.gamePos1.x = 10*i2;
                    tempworldblock.tile.gamePos1.y = 10*i;
                    tempworldblock.tile.gamePos2.x = 10*i2+9;
                    tempworldblock.tile.gamePos2.y = 10*i+9;
                    file >> tempEnum;
                    tempworldblock.tile_type = static_cast<world_block_type>(tempEnum);
                    PushBack(&currentGame -> game2Buffer, tempworldblock);
                }
            }
        }
        file.close();
        LoadSoundClip("data/sfx/Colorful-Flowers.wav", &songFile);
    }else if(currentGame -> currentLevel == 3){
        std::ifstream file("data/song_map_data.dat");
        if(file.is_open()){
            file >> lineCount;
            currentGame -> game3Buffer = MakeDynamicArray<moving_block>(&worldspaceArena, lineCount);
            for(int i = 0; i < lineCount; i++){
                file >> tempblock.timeTilMid;
                file >> tempblock.line;
                tempblock.clicked = false;

                PushBack(&currentGame -> game3Buffer, tempblock);
            }
        }

        file.close();
        LoadSoundClip("data/sfx/IdentityCover.wav", &songFile);
    }else if(currentGame -> currentLevel == 4){
        LoadSoundClip("data/sfx/stage_win.wav", &songFile);
    }
}

inline void SetNextLevel(int currLvl){
    ClearMemoryArena(&worldspaceArena);
    StartUpMemoryArenas(50);
    currentGame -> currentLevel = currLvl + 1;
    currentGame -> score = 0;

    currentGame -> time = 0.0f;

    if(currentGame -> currentLevel == 1){
        currentGame -> currentSize = {173, 250};
    }else{
        currentGame -> currentSize = {250, 250};
    }
    if(currentGame -> currentLevel == 1){
        currentGame -> player.pos = {0,0};
        currentGame -> player.worldPos = {0,0};
        currentGame -> player.currentLine = 1;
        currentGame -> player.currentLayer = 0;
        currentGame -> player.activeMovement = false;
    }else if(currentGame -> currentLevel == 2){
        // set game 2 pos
        currentGame -> player.pos = {currentGame -> currentSize.x/2,currentGame -> currentSize.y/2};
        currentGame -> player.worldPos = {4.0f,15.0f};
        currentGame -> player.currentLine = 0;
        currentGame -> player.currentLayer = 0;
        currentGame -> player.activeMovement = true;
    }else if(currentGame -> currentLevel == 3){
        currentGame -> player.pos = {currentGame -> currentSize.x/2,currentGame -> currentSize.y/2};
        currentGame -> player.currentLine = 0;
        currentGame -> player.currentLayer = 0;
        currentGame -> player.activeMovement = false;
    }
    currentGame -> gameStarted = true;
    currentGame -> gameLost = false;
    currentGame -> gameWon = false;
    currentGame -> completed = false;

    LoadExternalFileData();

    SetMosaicGridSize(currentGame -> currentSize.x, currentGame -> currentSize.y);
}

inline void ShowStartingScreen(){
    // graphics
    DrawHollowBlock({0,0}, currentGame -> currentSize, {1.0f,1.0f,1.0f,1.0f});
    DrawHollowBlock(currentButtons -> pos1, currentButtons -> pos2, {1.0f,1.0f,1.0f,1.0f});
    DrawTextTile({currentGame -> currentSize.x/2,currentGame -> currentSize.y/4}, 8.0f, {1.0f,1.0f,1.0f}, true, currentGame -> name);
    DrawTextTile({currentButtons -> center.x,currentButtons -> center.y+4}, 8.0f, {1.0f,1.0f,1.0f}, true, currentButtons -> text);
    // mechanics
    if (InputPressed(Mouse, Input_MouseLeft)){
        if(GetMousePositionX() >= currentButtons -> pos1.x &&
        GetMousePositionX() <= currentButtons -> pos2.x &&
        GetMousePositionY() >= currentButtons -> pos1.y &&
        GetMousePositionY() <= currentButtons -> pos2.y ){
            currentGame -> gameStarted = true;
            SetNextLevel(currentGame -> currentLevel);
        }
    }
}

inline void DrawVehicles(){
    for(int i = 0; i < currentGame -> game1Buffer.count; i++){
        if(currentGame -> game1Buffer[i].timeTilMid + (3*currentGame -> currentSize.y/4) / 40 < currentGame->time
        && currentGame -> game1Buffer[i].timeTilMid - currentGame -> currentSize.y / 40 > currentGame->time + 1){
            continue;
        }

        DrawFullBlock({
            5+(currentGame -> game1Buffer[i].line*5)+
            ((currentGame -> currentSize.x-20)/3)*(currentGame -> game1Buffer[i].line)+
            ((currentGame -> currentSize.x-20)/6)-
            15
            ,
            (currentGame->time - 2) * 40
            - currentGame->game1Buffer[i].timeTilMid * 40
            - currentGame->game1Buffer[i].obsticleWidth
            + (3*currentGame -> currentSize.y/4) -2
        },{
            5+(currentGame -> game1Buffer[i].line*5)+
            ((currentGame -> currentSize.x-20)/3)*(currentGame -> game1Buffer[i].line)+
            ((currentGame -> currentSize.x-20)/6)+
            15
            ,
            (currentGame->time - 2) * 40
            - currentGame->game1Buffer[i].timeTilMid * 40
            + (3*currentGame -> currentSize.y/4) -2
        },
        {1.0f, 1.0f,1.0f,1.0f}
        );
    }
}

bool PlayerHit(){
    for(int i = 0; i < currentGame -> game1Buffer.count; i++){
        if(currentGame->time - 2> currentGame->game1Buffer[i].timeTilMid
        && currentGame->time - 2< currentGame->game1Buffer[i].timeTilMid + (currentGame->game1Buffer[i].obsticleWidth / 40)
        && currentGame -> player.currentLine == currentGame -> game1Buffer[i].line){
            return true;
        }
    }
    return false;
}

void PlayGame1(){
    // sound
    if(songHan.generation == 0){
        songHan = PlaySound(&Game->audioPlayer, songFile, 0.25f, true);
    }
    Sound *sound = GetSound(&Game->audioPlayer, songHan);
    // graphics
    DrawHollowBlock({0,0}, currentGame -> currentSize, {1.0f,1.0f,1.0f,1.0f});
    DrawHollowBlock(
        {5,0},
        {5+(currentGame -> currentSize.x - 20)/3, currentGame -> currentSize.y},
        {1.0f,1.0f,1.0f,1.0f});
    DrawHollowBlock(
        {10+(currentGame -> currentSize.x - 20)/3 , 0},
        {10+2*(currentGame -> currentSize.x - 20)/3, currentGame -> currentSize.y},
        {1.0f,1.0f,1.0f,1.0f});
    DrawHollowBlock(
        {15+2*(currentGame -> currentSize.x - 20)/3,0},
        {15+3*(currentGame -> currentSize.x - 20)/3, currentGame -> currentSize.y},
        {1.0f,1.0f,1.0f,1.0f});
    
    DrawFullBlock({
        5+(currentGame -> player.currentLine*5)+
        ((currentGame -> currentSize.x-20)/3)*(currentGame -> player.currentLine)+
        ((currentGame -> currentSize.x-20)/6)-
        2
        ,
        (3*currentGame -> currentSize.y/4)-2
    },{
        5+(currentGame -> player.currentLine*5)+
        ((currentGame -> currentSize.x-20)/3)*(currentGame -> player.currentLine)+
        ((currentGame -> currentSize.x-20)/6)+
        2
        ,
        (3*currentGame -> currentSize.y/4)+2
    },{1.0f,1.0f,1.0f,1.0f},{1.0f,1.0f,1.0f,1.0f});

    DrawVehicles();
    
    // mechanics

    if(InputPressed(Keyboard, Input_LeftArrow)){
        if(currentGame -> player.currentLine > 0){
            currentGame -> player.currentLine--;
        }
    }
    if(InputPressed(Keyboard, Input_RightArrow)){
        if(currentGame -> player.currentLine < 2){
            currentGame -> player.currentLine++;
        }
    }

    // Physics
    currentGame -> time += DeltaTime;

    if(PlayerHit()){
        loseLevel();
    }
    if(currentGame -> time > 63.0f || InputPressed(Keyboard, Input_K)){
        winLevel();
    }
}

world_block_type CheckUnder(){
    if(currentGame -> player.worldPos.x < 0 || currentGame -> player.worldPos.x >= 410 || currentGame -> player.worldPos.y < 0 || currentGame -> player.worldPos.y >= 410)
        return VOID_BLOCK;
    return currentGame -> game2Buffer[(int)(floor(currentGame -> player.worldPos.y / 10.0f)*41 + floor(currentGame->player.worldPos.x / 10.0f))].tile_type;
}
world_block_type CheckUnderPos(vec2 pointPos){
    if(pointPos.x < 0 || pointPos.x >= 410 || pointPos.y < 0 || pointPos.y >= 410)
        return VOID_BLOCK;
    return currentGame -> game2Buffer[(int)(floor(pointPos.y / 10.0f)*41 + floor(pointPos.x / 10.0f))].tile_type;
}

void movePlayer(int direct){
    // enum world_block_type {NO_BLOCK, WALL, LAVA, GOO, WATER, START, END};
    world_block_type tempTypeBlock;
    switch (direct)
    {
    case 1:
        tempTypeBlock = CheckUnderPos({
            currentGame -> player.worldPos.x
            ,
            currentGame -> player.worldPos.y
            - 2
            - DeltaTime*20.0f
        });
        currentGame -> player.worldPos.y -= ((tempTypeBlock != WALL && tempTypeBlock != VOID_BLOCK) && tempTypeBlock != GOO)?DeltaTime*20.0f:0;
        currentGame -> player.worldPos.y -= ((tempTypeBlock != WALL && tempTypeBlock != VOID_BLOCK) && tempTypeBlock == GOO)?DeltaTime*10.0f:0;
        break;
    case 2:
        tempTypeBlock = CheckUnderPos({
            currentGame -> player.worldPos.x
            + 2
            + DeltaTime*20.0f
            ,
            currentGame -> player.worldPos.y
        });
        currentGame -> player.worldPos.x += ((tempTypeBlock != WALL && tempTypeBlock != VOID_BLOCK) && tempTypeBlock != GOO)?DeltaTime*20.0f:0;
        currentGame -> player.worldPos.x += ((tempTypeBlock != WALL && tempTypeBlock != VOID_BLOCK) && tempTypeBlock == GOO)?DeltaTime*10.0f:0;
        break;
    case 3:
        tempTypeBlock = CheckUnderPos({
            currentGame -> player.worldPos.x
            ,
            currentGame -> player.worldPos.y
            + 2
            + DeltaTime*20.0f
        });
        currentGame -> player.worldPos.y += ((tempTypeBlock != WALL && tempTypeBlock != VOID_BLOCK) && tempTypeBlock != GOO)?DeltaTime*20.0f:0;
        currentGame -> player.worldPos.y += ((tempTypeBlock != WALL && tempTypeBlock != VOID_BLOCK) && tempTypeBlock == GOO)?DeltaTime*10.0f:0;
        break;
    case 4:
        tempTypeBlock = CheckUnderPos({
            currentGame -> player.worldPos.x
            - 2
            - DeltaTime*20.0f
            ,
            currentGame -> player.worldPos.y
            
        });
        currentGame -> player.worldPos.x -= ((tempTypeBlock != WALL && tempTypeBlock != VOID_BLOCK) && tempTypeBlock != GOO)?DeltaTime*20.0f:0;
        currentGame -> player.worldPos.x -= ((tempTypeBlock != WALL && tempTypeBlock != VOID_BLOCK) && tempTypeBlock == GOO)?DeltaTime*10.0f:0;
        break;
    default:
        Print("Error: Incorrect Movement Detected");
        break;
    }

}

point CalculateClosestToRay(Ray2D tempRay){
    // RaycastAABB(vec2 aabbMin, vec2 aabbMax, vec2 origin, vec2 direction, real32 *tMin, bool testInside = false, real32 epsilon = FLT_EPSILON)
    real32 *timeClosest = (real32 *)malloc(sizeof(real32));
    *timeClosest = 200.0f;
    real32 *tempClosest = (real32 *)malloc(sizeof(real32));
    for(int i = 0; i < currentGame -> game2Buffer.count; i++){
        if(currentGame -> game2Buffer[i].tile_type != WALL){
            continue;
        }
        if(RaycastAABB(currentGame -> game2Buffer[i].tile.gamePos1, currentGame -> game2Buffer[i].tile.gamePos2, tempRay.origin, tempRay.direction, tempClosest)){
            if(*timeClosest > *tempClosest){
                *timeClosest = *tempClosest;
            }
        }
    }
    return
    {
        tempRay.origin + tempRay.direction * *timeClosest
        ,
        {1.0f,1.0f,1.0f,1.0f}
    };
}

void LidarScan(){
    PushBack(&currentGame -> pointsBuff, CalculateClosestToRay({currentGame -> player.worldPos,{0.0f,1.0f}}));
    PushBack(&currentGame -> pointsBuff, CalculateClosestToRay({currentGame -> player.worldPos,{1.0f,0.0f}}));
    PushBack(&currentGame -> pointsBuff, CalculateClosestToRay({currentGame -> player.worldPos,{0.0f,-1.0f}}));
    PushBack(&currentGame -> pointsBuff, CalculateClosestToRay({currentGame -> player.worldPos,{-1.0f,0.0f}}));
    PushBack(&currentGame -> pointsBuff, CalculateClosestToRay({currentGame -> player.worldPos,{sqrt(2.0f)/2.0f,sqrt(2.0f)/2.0f}}));
    PushBack(&currentGame -> pointsBuff, CalculateClosestToRay({currentGame -> player.worldPos,{sqrt(2.0f)/2.0f,-sqrt(2.0f)/2.0f}}));
    PushBack(&currentGame -> pointsBuff, CalculateClosestToRay({currentGame -> player.worldPos,{-sqrt(2.0f)/2.0f,sqrt(2.0f)/2.0f}}));
    PushBack(&currentGame -> pointsBuff, CalculateClosestToRay({currentGame -> player.worldPos,{-sqrt(2.0f)/2.0f,-sqrt(2.0f)/2.0f}}));
}

void DrawLidarPoints(){
    // change it for lidar

    for(int i = 0; i < currentGame -> pointsBuff.count; i++){
        SetTileColor(
            currentGame -> pointsBuff[i].pos.x - currentGame -> player.worldPos.x + currentGame -> currentSize.x/2
            , currentGame -> pointsBuff[i].pos.y - currentGame -> player.worldPos.y + currentGame -> currentSize.y/2
            , currentGame -> pointsBuff[i].color
        );
    }
}


void PlayGame2(){
    // sound
    if(songHan.generation == 0){
        songHan = PlaySound(&Game->audioPlayer, songFile, 0.25f, true);
    }
    Sound *sound = GetSound(&Game->audioPlayer, songHan);
    // graphics
    DrawFullBlock({
        {
            currentGame -> player.pos.x - 2
            ,
            currentGame -> player.pos.y  - 2
        }
    },{
        {
            currentGame -> player.pos.x + 2
            ,
            currentGame -> player.pos.y + 2
        }
    },{1.0f,1.0f,1.0f,1.0f},{1.0f,1.0f,1.0f,1.0f});

    DrawLidarPoints();
    // mechanics
    // enum world_block_type {NO_BLOCK, WALL, LAVA, GOO, WATER, START, END};
    if(InputHeld(Keyboard, Input_UpArrow)){
        switch(CheckUnder()){
            case LAVA:
                loseLevel();
                break;
            case END:
                winLevel();
                break;
            default:
                movePlayer(1);
        }
    }
    if(InputHeld(Keyboard, Input_RightArrow)){
        switch(CheckUnder()){
            case LAVA:
                loseLevel();
                break;
            case END:
                winLevel();
                break;
            default:
                movePlayer(2);
        }
    }
    if(InputHeld(Keyboard, Input_DownArrow)){
        switch(CheckUnder()){
            case LAVA:
                loseLevel();
                break;
            case END:
                winLevel();
                break;
            default:
                movePlayer(3);
        }
    }
    if(InputHeld(Keyboard, Input_LeftArrow)){
        switch(CheckUnder()){
            case LAVA:
                loseLevel();
                break;
            case END:
                winLevel();
                break;
            default:
                movePlayer(4);
        }
    }
    if(InputPressed(Keyboard,Input_R)){
        LidarScan();
    }


    // Physics
    currentGame -> time += DeltaTime;

    if(InputPressed(Keyboard, Input_K)){
        winLevel();
    }
}

void DrawBeats(){
    for(int i = 0; i < currentGame -> game3Buffer.count; i++){
        if(currentGame -> time >= currentGame -> game3Buffer[i].timeTilMid || currentGame -> time + 2 < currentGame -> game3Buffer[i].timeTilMid || currentGame -> game3Buffer[i].clicked){
            continue;
        }   
        DrawFullBlock({
            ((currentGame -> game3Buffer[i].line == 2)?20 - currentGame->time * 160 + currentGame->game3Buffer[i].timeTilMid * 160:0)
            + ((currentGame -> game3Buffer[i].line == 4)?-20 + currentGame->time * 160 - currentGame->game3Buffer[i].timeTilMid * 160:0)
            + currentGame -> player.pos.x
            -10
            ,
            ((currentGame -> game3Buffer[i].line == 1)?-20 + currentGame->time * 160 - currentGame->game3Buffer[i].timeTilMid * 160:0)
            + ((currentGame -> game3Buffer[i].line == 3)?20 -currentGame->time * 160 + currentGame->game3Buffer[i].timeTilMid * 160:0)
            + currentGame -> player.pos.y
            -10

        }
        ,
        {
            ((currentGame -> game3Buffer[i].line == 2)?20 - currentGame->time * 160 + currentGame->game3Buffer[i].timeTilMid * 160:0)
            + ((currentGame -> game3Buffer[i].line == 4)?-20 + currentGame->time * 160 - currentGame->game3Buffer[i].timeTilMid * 160:0)
            + currentGame -> player.pos.x
            +9
            ,
            ((currentGame -> game3Buffer[i].line == 1)?-20 + currentGame->time * 160 - currentGame->game3Buffer[i].timeTilMid * 160:0)
            + ((currentGame -> game3Buffer[i].line == 3)?20 -currentGame->time * 160 + currentGame->game3Buffer[i].timeTilMid * 160:0)
            + currentGame -> player.pos.y
            +9
        },{1.0f,1.0f,1.0f,1.0f});
    }
}

void CheckLane(int laneNum){
    for(int i = 0; i< currentGame -> game3Buffer.count; i++){
        if(currentGame -> game3Buffer[i].line != laneNum){
            continue;
        }
        if(currentGame -> time > currentGame -> game3Buffer[i].timeTilMid - 0.1f && currentGame -> time < currentGame -> game3Buffer[i].timeTilMid + 0.1f){
            currentGame -> score += 300;
            currentGame -> game3Buffer[i].clicked = true;
            break;
        }
        if(currentGame -> time > currentGame -> game3Buffer[i].timeTilMid - 0.2f && currentGame -> time < currentGame -> game3Buffer[i].timeTilMid + 0.2f){
            currentGame -> score += 100;
            currentGame -> game3Buffer[i].clicked = true;
            break;
        }
        if(currentGame -> time > currentGame -> game3Buffer[i].timeTilMid - 0.3f && currentGame -> time < currentGame -> game3Buffer[i].timeTilMid + 0.5f){
            currentGame -> score += 50;
            currentGame -> game3Buffer[i].clicked = true;
            break;
        }
        if(currentGame -> time > currentGame -> game3Buffer[i].timeTilMid - 0.4f && currentGame -> time < currentGame -> game3Buffer[i].timeTilMid + 0.7f){
            currentGame -> score -= 50;
            currentGame -> game3Buffer[i].clicked = true;
            break;
        }
    }
}

void PlayGame3(){
    // song
    if(songHan.generation == 0){
        songHan = PlaySound(&Game->audioPlayer, songFile, 0.25f, false);
    }
    Sound *sound = GetSound(&Game->audioPlayer, songHan);
    // graphics
    DrawFullBlock({
        {
            currentGame -> player.pos.x - 2
            ,
            currentGame -> player.pos.y  - 2
        }
    },{
        {
            currentGame -> player.pos.x + 1
            ,
            currentGame -> player.pos.y + 1
        }
    },{1.0f,1.0f,1.0f,1.0f},{1.0f,1.0f,1.0f,1.0f});
    // left block
    DrawHollowBlock({
        {
            currentGame -> player.pos.x -30
            ,
            currentGame -> player.pos.y -10
        }
    },{
        {
            currentGame -> player.pos.x -10
            ,
            currentGame -> player.pos.y +10
        }
    },{1.0f,1.0f,1.0f,1.0f});
    // right Block
    DrawHollowBlock({
        {
            currentGame -> player.pos.x +10
            ,
            currentGame -> player.pos.y -10
        }
    },{
        {
            currentGame -> player.pos.x +30
            ,
            currentGame -> player.pos.y +10
        }
    },{1.0f,1.0f,1.0f,1.0f});
    // up block
    DrawHollowBlock({
        {
            currentGame -> player.pos.x -10
            ,
            currentGame -> player.pos.y -30
        }
    },{
        {
            currentGame -> player.pos.x +10
            ,
            currentGame -> player.pos.y -10
        }
    },{1.0f,1.0f,1.0f,1.0f});
    // down block
    DrawHollowBlock({
        {
            currentGame -> player.pos.x -10
            ,
            currentGame -> player.pos.y +10
        }
    },{
        {
            currentGame -> player.pos.x +10
            ,
            currentGame -> player.pos.y +30
        }
    },{1.0f,1.0f,1.0f,1.0f});

    DrawBeats();
    // mechanics
    /*
    Input_LeftArrow,
    Input_RightArrow,
    Input_DownArrow,
    Input_UpArrow,
    */
    if(InputPressed(Keyboard, Input_UpArrow)){
        CheckLane(1);
    }
    if(InputPressed(Keyboard, Input_RightArrow)){
        CheckLane(2);
    }
    if(InputPressed(Keyboard, Input_DownArrow)){
        CheckLane(3);
    }
    if(InputPressed(Keyboard, Input_LeftArrow)){
        CheckLane(4);
    }
    
    // physics
    currentGame -> time += DeltaTime;
    if(currentGame->time > 76 || InputPressed(Keyboard, Input_K)){
        winLevel();
    }
}

void RestartGame(){
    Game->audioPlayer = {};
    songFile = {};
    songHan = {};
    AudioPlayerInit(&Game->audioPlayer, &Game->permanentArena);

    ClearMemoryArena(&worldspaceArena);
    StartUpMemoryArenas(50); // Set up memory arenas and delare Game Variables
    currentGame -> currentLevel = 0;
    currentGame -> score = 0;
    currentGame -> time = 0.0f;
    currentGame -> currentSize = {255, 255};

    currentGame -> name = "A Bit Delirious?";

    currentGame -> gameStarted = false;
    currentGame -> gameLost = false;
    currentGame -> gameWon = false;
    currentGame -> completed = false;
}

void ShowGameOverScreen(){
    DrawHollowBlock({0,0}, currentGame -> currentSize, {1.0f,1.0f,1.0f,1.0f});
    DrawHollowBlock(currentButtons -> pos1, currentButtons -> pos2, {1.0f,1.0f,1.0f,1.0f});
    DrawTextTile({currentGame -> currentSize.x/2,currentGame -> currentSize.y/4}, 8.0f, {1.0f,1.0f,1.0f}, true, "Game Over");
    DrawTextTile({currentButtons -> center.x,currentButtons -> center.y+4}, 8.0f, {1.0f,1.0f,1.0f}, true, "Restart?");
    // mechanics
    if (InputPressed(Mouse, Input_MouseLeft)){
        if(GetMousePositionX() >= currentButtons -> pos1.x &&
        GetMousePositionX() <= currentButtons -> pos2.x &&
        GetMousePositionY() >= currentButtons -> pos1.y &&
        GetMousePositionY() <= currentButtons -> pos2.y ){
            RestartGame();
        }
    }
}

void ShowEndScreen(){
    if(songHan.generation == 0){
        songHan = PlaySound(&Game->audioPlayer, songFile, 0.25f, false);
    }
    Sound *sound = GetSound(&Game->audioPlayer, songHan);

    DrawHollowBlock({0,0}, currentGame -> currentSize, {1.0f,1.0f,1.0f,1.0f});
    DrawHollowBlock(currentButtons -> pos1, currentButtons -> pos2, {1.0f,1.0f,1.0f,1.0f});
    DrawTextTile({currentGame -> currentSize.x/2,currentGame -> currentSize.y/4}, 8.0f, {1.0f,1.0f,1.0f}, true, "You Win!!!");
    DrawTextTile({currentButtons -> center.x,currentButtons -> center.y+4}, 8.0f, {1.0f,1.0f,1.0f}, true, "Restart?");
    // mechanics
    if (InputPressed(Mouse, Input_MouseLeft)){
        if(GetMousePositionX() >= currentButtons -> pos1.x &&
        GetMousePositionX() <= currentButtons -> pos2.x &&
        GetMousePositionY() >= currentButtons -> pos1.y &&
        GetMousePositionY() <= currentButtons -> pos2.y ){
            RestartGame();
        }
    }
}

void MyMosaicInit() {
    RestartGame();

    currentButtons = SetDefaultButton(currentButtonData, currentButtons);

    SetMosaicGridSize(currentGame -> currentSize.x, currentGame -> currentSize.y);
}

void MyMosaicUpdate() {
    ClearTiles(0.0f,0.0f,0.0f);\
    //SetTileColor(0, 0, 0.8f, 0.3f, 0.3f);
    if(!currentGame -> gameStarted){
        ShowStartingScreen();
    }
    if(currentGame -> gameStarted && !currentGame -> gameLost  && !currentGame -> gameWon){
        switch (currentGame -> currentLevel){
        case 1:
            PlayGame1();
            break;
        case 2:
            PlayGame2();
            break;
        case 3:
            PlayGame3();
            break;
        default:
            currentGame -> completed = true;
            break;
        }
    }
    if(currentGame -> gameWon){
        SetNextLevel(currentGame -> currentLevel);
    }
    if(currentGame -> gameLost){
        ShowGameOverScreen();
    }
    if(currentGame -> completed){
        ShowEndScreen();
    }
    

    //DrawTextTile({(WIDTH/2),-HEIGHT/32}, 4.0f, {1.0f,1.0f,1.0f}, true, "FPS: %f", 1/DeltaTime);
    DrawTextTile({(WIDTH/2),-HEIGHT/32}, 4.0f, {1.0f,1.0f,1.0f}, true, "Score: %i", currentGame -> score);
    DrawTextTile({(WIDTH/4),-HEIGHT/32}, 4.0f, {1.0f,1.0f,1.0f}, true, "LEVEL: %i", currentGame -> currentLevel);
    DrawTextTile({(3*WIDTH/4),-HEIGHT/32}, 4.0f, {1.0f,1.0f,1.0f}, true, "TIME: %1.f", currentGame -> time);
    DrawTextTile({(WIDTH/2),33.5*HEIGHT/32}, 4.0f, {1.0f,1.0f,1.0f}, true, "x: %1.f y: %1.f", currentGame -> player.worldPos.x, currentGame -> player.worldPos.y);
}
