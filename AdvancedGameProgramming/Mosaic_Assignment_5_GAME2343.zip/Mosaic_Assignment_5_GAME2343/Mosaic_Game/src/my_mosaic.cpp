#define _USE_MATH_DEFINES
#include <math.h>

const int WIDTH = 250;
const int HEIGHT = 250;

struct Particle{
    bool isCreated = false;

    vec2 pos;
    vec2 objVel;
    vec2 extAccel;
    real32 currTime;
    real32 lifetime;

    vec4 color1;
    vec4 color2;
    vec4 color3;
    vec4 color4;

    vec4 currColor;
};

struct ParticleEmitter{
    vec2 pos;
    real32 currTime;

    int32 currParticles;
    int32 maxParticles;
    real32 spawnRate;
    int32 particlesPerSpawn;
    vec2 particleLifetime;
    vec2 particleExtAccel;

    real32 radius;
    vec2 spawnAreaAngle;

    vec4 color1;
    vec4 color2;
    vec4 color3;
    vec4 color4;

    Particle* particles;
};

struct ParticleBuff{
    int32 cap;
    int32 used;
    Particle *particles;
};

ParticleBuff ParticleBuffer = {};

ParticleEmitter FireEmitter = {};
ParticleEmitter SmokeEmitter = {};
ParticleEmitter ExplosionEmitter = {};
ParticleEmitter WaterEmitter = {};
ParticleEmitter SparkEmitter = {};

vec2 directionVec(real32 angleRadians){
    return {
        (float)cos(angleRadians),
        (float)sin(angleRadians) * -1.0f
    };
}

void SetParticleEmitters(){
    ParticleBuffer.cap = 4000;
    ParticleBuffer.used = 0;
    ParticleBuffer.particles = (Particle *)malloc(sizeof(Particle)*ParticleBuffer.cap);

    // Fire Emitter
    FireEmitter.pos = {
            directionVec(M_PI/2 - 2*M_PI/5).x * (WIDTH*0.3f) + (WIDTH >> 1)
        ,
            directionVec(M_PI/2 - 2*M_PI/5).y * (HEIGHT*0.3f) + (HEIGHT >> 1)
    };
    FireEmitter.currTime = 0.0f;

    FireEmitter.currParticles = 0;
    FireEmitter.maxParticles = 800;
    FireEmitter.spawnRate = 0.2f;
    FireEmitter.particlesPerSpawn = 80;
    FireEmitter.particleLifetime = {2.0f,3.0f};
    FireEmitter.particleExtAccel = {0.0f,-0.02f};

    FireEmitter.radius = 0.3f;
    FireEmitter.spawnAreaAngle = {0.0f, 2*M_PI};
    FireEmitter.color1 = {1.0f,1.0f,0.8f,1.0f};
    FireEmitter.color2 = {1.0f,1.0f,0.4f,1.0f};
    FireEmitter.color3 = {1.0f,0.5f,0.2f,1.0f};
    FireEmitter.color4 = {0.5f,0.0f,0.0f,1.0f};

    FireEmitter.particles = &ParticleBuffer.particles[ParticleBuffer.used];
    ParticleBuffer.used += FireEmitter.maxParticles;

    // Smoke Emitter
    SmokeEmitter.pos = {
            directionVec(M_PI/2 - 8*M_PI/5).x * (WIDTH*0.3f) + (WIDTH >> 1)
        ,
            directionVec(M_PI/2 - 8*M_PI/5).y * (HEIGHT*0.3f) + (HEIGHT >> 1)
    };
    SmokeEmitter.currTime = 0.0f;

    SmokeEmitter.currParticles = 0;
    SmokeEmitter.maxParticles = 800;
    SmokeEmitter.spawnRate = 0.2f;
    SmokeEmitter.particlesPerSpawn = 40;
    SmokeEmitter.particleLifetime = {2.0f,3.0f};
    SmokeEmitter.particleExtAccel = {0.0f,-0.02f};

    SmokeEmitter.radius = 0.3f;
    SmokeEmitter.spawnAreaAngle = {0.0f, 2*M_PI};
    SmokeEmitter.color1 = {0.87f,0.87f,0.87f,1.0f};
    SmokeEmitter.color2 = {0.62f,0.62f,0.62f,1.0f};
    SmokeEmitter.color3 = {0.37f,0.37f,0.37f,1.0f};
    SmokeEmitter.color4 = {0.12f,0.12f,0.12f,1.0f};

    SmokeEmitter.particles = &ParticleBuffer.particles[ParticleBuffer.used];
    ParticleBuffer.used += SmokeEmitter.maxParticles;

    // Explosion Emitter
    ExplosionEmitter.pos = {
            directionVec(M_PI/2).x * (WIDTH*0.3f) + (WIDTH >> 1)
        ,
            directionVec(M_PI/2).y * (HEIGHT*0.3f) + (HEIGHT >> 1)
    };
    ExplosionEmitter.currTime = 0.0f;

    ExplosionEmitter.currParticles = 0;
    ExplosionEmitter.maxParticles = 400;
    ExplosionEmitter.spawnRate = 0.2f;
    ExplosionEmitter.particlesPerSpawn = 80;
    ExplosionEmitter.particleLifetime = {0.5f,1.0f};
    ExplosionEmitter.particleExtAccel = {0.0f,0.0f};

    ExplosionEmitter.radius = 1.0f;
    ExplosionEmitter.spawnAreaAngle = {0.0f, 2*M_PI};
    ExplosionEmitter.color1 = {1.0f,1.0f,0.8f,1.0f};
    ExplosionEmitter.color2 = {1.0f,1.0f,0.4f,1.0f};
    ExplosionEmitter.color3 = {1.0f,0.5f,0.2f,1.0f};
    ExplosionEmitter.color4 = {0.37f,0.37f,0.37f,1.0f};

    ExplosionEmitter.particles = &ParticleBuffer.particles[ParticleBuffer.used];
    ParticleBuffer.used += ExplosionEmitter.maxParticles;

    // Water Emitter
    WaterEmitter.pos = {
            directionVec(M_PI/2 - 4*M_PI/5).x * (WIDTH*0.3f) + (WIDTH >> 1)
        ,
            directionVec(M_PI/2 - 4*M_PI/5).y * (HEIGHT*0.3f) + (HEIGHT >> 1)
    };
    WaterEmitter.currTime = 0.0f;

    WaterEmitter.currParticles = 0;
    WaterEmitter.maxParticles = 200;
    WaterEmitter.spawnRate = 1.0f;
    WaterEmitter.particlesPerSpawn = 20;
    WaterEmitter.particleLifetime = {1.0f,2.0f};
    WaterEmitter.particleExtAccel = {0.0f,0.16f};

    WaterEmitter.radius = 5.0f;
    WaterEmitter.spawnAreaAngle = {M_PI * (1.0/3.0), M_PI * (2.0/3.0)};
    WaterEmitter.color1 = {0.0f,0.0f,0.8f,1.0f};
    WaterEmitter.color2 = {0.0f,0.0f,0.6f,1.0f};
    WaterEmitter.color3 = {0.0f,0.0f,0.4f,1.0f};
    WaterEmitter.color4 = {0.0f,0.0f,0.2f,1.0f};

    WaterEmitter.particles = &ParticleBuffer.particles[ParticleBuffer.used];
    ParticleBuffer.used += WaterEmitter.maxParticles;

    // Spark Emitter
    SparkEmitter.pos = {
            directionVec(M_PI/2 - 6*M_PI/5).x * (WIDTH*0.3f) + (WIDTH >> 1)
        ,
            directionVec(M_PI/2 - 6*M_PI/5).y * (HEIGHT*0.3f) + (HEIGHT >> 1)
    };
    SparkEmitter.currTime = 0.0f;

    SparkEmitter.currParticles = 0;
    SparkEmitter.maxParticles = 400;
    SparkEmitter.spawnRate = 0.5f;
    SparkEmitter.particlesPerSpawn = 40;
    SparkEmitter.particleLifetime = {0.0f,1.0f};
    SparkEmitter.particleExtAccel = {0.0f,0.0f};

    SparkEmitter.radius = 1.0f;
    SparkEmitter.spawnAreaAngle = {0.0f, 2*M_PI};
    SparkEmitter.color1 = {1.0f,1.0f,0.8f,1.0f};
    SparkEmitter.color2 = {1.0f,1.0f,0.0f,1.0f};
    SparkEmitter.color3 = {0.5f,0.5f,0.0f,1.0f};
    SparkEmitter.color4 = {0.2f,0.2f,0.0f,1.0f};

    SparkEmitter.particles = &ParticleBuffer.particles[ParticleBuffer.used];
    ParticleBuffer.used += SparkEmitter.maxParticles;
}

void MakeParticles(ParticleEmitter &currEmitter){
    if(currEmitter.maxParticles - currEmitter.currParticles > currEmitter.particlesPerSpawn){
        int count = 0;
        for(int i = 0; i < currEmitter.maxParticles; i++){
            if(count >= currEmitter.particlesPerSpawn){
                break;
            }
            if(&currEmitter.particles[i] == nullptr || !currEmitter.particles[i].isCreated){
                /*
                -- particle
                vec2 pos;
                vec2 objVel;
                vec2 extAccel;
                real32 currTime;
                real32 lifetime;

                vec4 color1;
                vec4 color2;
                vec4 color3;
                vec4 color4;

                -- Emitter
                vec2 pos;

                int32 currParticles;
                int32 maxParticles;
                real32 spawnRate;
                int32 particlesPerSpawn;
                vec2 particleLifetime;
                vec2 particleExtAccel;

                real32 radius;
                vec2 spawnAreaAngle;

                vec4 color1;
                vec4 color2;
                vec4 color3;
                vec4 color4;

                Particle* particles;
                */
                real32 tempAngleRadians = RandfRange(currEmitter.spawnAreaAngle.x,currEmitter.spawnAreaAngle.y);
                real32 tempRandOut = RandfRange(0.0f, currEmitter.radius);

                currEmitter.particles[i].isCreated = true;
                currEmitter.particles[i].pos = {
                    currEmitter.pos.x + (tempRandOut * directionVec(tempAngleRadians).x)
                    ,
                    currEmitter.pos.y + (tempRandOut * directionVec(tempAngleRadians).y)
                };
                currEmitter.particles[i].objVel = {
                    tempRandOut * directionVec(tempAngleRadians).x 
                    ,
                    tempRandOut * directionVec(tempAngleRadians).y
                };
                currEmitter.particles[i].extAccel = currEmitter.particleExtAccel;
                currEmitter.particles[i].currTime = 0;
                currEmitter.particles[i].lifetime = RandfRange(currEmitter.particleLifetime.x, currEmitter.particleLifetime.y);
                currEmitter.particles[i].color1 = currEmitter.color1;
                currEmitter.particles[i].color2 = currEmitter.color2;
                currEmitter.particles[i].color3 = currEmitter.color3;
                currEmitter.particles[i].color4 = currEmitter.color4;
                currEmitter.particles[i].currColor = currEmitter.particles[i].color1;
                count++;
            }
        }
    }
}

void SummonParticles(){
    if(FireEmitter.currTime - FireEmitter.spawnRate > 0){
        MakeParticles(FireEmitter);
        FireEmitter.currTime -= FireEmitter.spawnRate;
    }
    if(SmokeEmitter.currTime - SmokeEmitter.spawnRate > 0){
        MakeParticles(SmokeEmitter);
        SmokeEmitter.currTime -= SmokeEmitter.spawnRate;
    }
    if(ExplosionEmitter.currTime - ExplosionEmitter.spawnRate > 0){
        MakeParticles(ExplosionEmitter);
        ExplosionEmitter.currTime -= ExplosionEmitter.spawnRate;
    }
    if(WaterEmitter.currTime - WaterEmitter.spawnRate > 0){
        MakeParticles(WaterEmitter);
        WaterEmitter.currTime -= WaterEmitter.spawnRate;
    }
    if(SparkEmitter.currTime - SparkEmitter.spawnRate > 0){
        MakeParticles(SparkEmitter);
        SparkEmitter.currTime -= SparkEmitter.spawnRate;
    }
    FireEmitter.currTime += DeltaTime;
    SmokeEmitter.currTime += DeltaTime;
    ExplosionEmitter.currTime += DeltaTime;
    WaterEmitter.currTime += DeltaTime;
    SparkEmitter.currTime += DeltaTime;
}

void ModifySingleParticle(Particle& currPart){
    /*
    vec2 pos;
    vec2 objVel;
    vec2 extAccel;
    real32 currTime;
    real32 lifetime;

    vec4 color1;
    vec4 color2;
    vec4 color3;
    vec4 color4;

    vec4 currColor;
    */
    currPart.pos = {
        currPart.pos.x + currPart.objVel.x,
        currPart.pos.y + currPart.objVel.y
    };
    currPart.objVel = {
        currPart.objVel.x + currPart.extAccel.x,
        currPart.objVel.y + currPart.extAccel.y
    };
    currPart.currTime += DeltaTime;
    currPart.currColor = {
        (currPart.currTime < currPart.lifetime/3.0f)? Lerp(currPart.color1.r, currPart.color2.r,currPart.currTime/(currPart.lifetime/3.0f)):
            (currPart.currTime < 2.0*currPart.lifetime/3.0f)? Lerp(currPart.color2.r, currPart.color3.r,(currPart.currTime-currPart.lifetime/3.0f)/(currPart.lifetime/3.0f)):
            Lerp(currPart.color3.r, currPart.color4.r,(currPart.currTime-2.0f*currPart.lifetime/3.0f)/(currPart.lifetime/3.0f))
        ,
        (currPart.currTime < currPart.lifetime/3.0f)? Lerp(currPart.color1.g, currPart.color2.g,currPart.currTime/(currPart.lifetime/3.0f)):
            (currPart.currTime < 2.0*currPart.lifetime/3.0f)? Lerp(currPart.color2.g, currPart.color3.g,(currPart.currTime-currPart.lifetime/3.0f)/(currPart.lifetime/3.0f)):
            Lerp(currPart.color3.g, currPart.color4.g,(currPart.currTime-2.0f*currPart.lifetime/3.0f)/(currPart.lifetime/3.0f))
        ,
        (currPart.currTime < currPart.lifetime/3.0f)? Lerp(currPart.color1.b, currPart.color2.b,currPart.currTime/(currPart.lifetime/3.0f)):
            (currPart.currTime < 2.0*currPart.lifetime/3.0f)? Lerp(currPart.color2.b, currPart.color3.b,(currPart.currTime-currPart.lifetime/3.0f)/(currPart.lifetime/3.0f)):
            Lerp(currPart.color3.b, currPart.color4.b,(currPart.currTime-2.0f*currPart.lifetime/3.0f)/(currPart.lifetime/3.0f))
        ,
        1.0f
    };
}

void UpdateParticles(){
    
    for(int i = 0; i < ParticleBuffer.used; i++){
        // Remove Particles
        if(ParticleBuffer.particles[i].lifetime < ParticleBuffer.particles[i].currTime){
            ParticleBuffer.particles[i] = {};
            continue;
        }
        // Update Particles
        ModifySingleParticle(ParticleBuffer.particles[i]);
    }
   
}

void DrawParticles(){
    for(int i = 0; i < ParticleBuffer.used; i++){
        SetTileColor(ParticleBuffer.particles[i].pos, ParticleBuffer.particles[i].currColor);
    }
}

void MyMosaicInit() {
    SetMosaicGridSize(WIDTH, HEIGHT);
    SetParticleEmitters();
}

void MyMosaicUpdate() {
    //SetTileColor(0, 0, 0.8f, 0.3f, 0.3f);
    SummonParticles();
    UpdateParticles();
    DrawParticles();
}
 