#define _USE_MATH_DEFINES

#include <vector>
#include <string>
#include <math.h>

// @variables


const int WIDTH = 240;
const int HEIGHT = 160;

enum inputDev{keybd, point};
enum powerUp{MORE_BALLS, MORE_POINTS, NONE};

struct brick{
    vec2 topXY;
    vec2 bottomXY;

    vec4 color;
    
    bool destroyed;
    real32 timeSinceDestruction;
    powerUp brickPower;
};

struct ball{
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;

    vec4 color;

    vec2 direction;
    real32 speed;
};

struct falseBall{
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;

    vec4 color;

    real32 timeSinceChange;
};

struct paddle{
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;
    
    vec4 color;

    vec2 direction;
    real32 speed;
    inputDev moveDevice;
};

struct button{
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;

    std::string textOfButton;
};

struct gameValues{
    real32 time = 0;
    bool gameStarted = false;
    bool gameEnded = false;
    int32 blocksLeft;
    int32 level = 1;
    int32 currentScore = 0;
    int32 highScore = 0;
    int32 currentMouseX;
    int32 currentMouseY;

} gameProperties;

std::vector<std::vector<brick>> gameBricks;
std::vector<ball> activeBalls;
std::vector<falseBall> previousBalls;
paddle gamePaddle;

button gamePlayButton;

// Set Initial level of Bricks


int32 randomWidth;
int32 currentRowSize;
powerUp randomPower;
int32 tempRand;

void randomPowerUp(powerUp& rPow){
    //enum powerUp{MORE_BALLS, MORE_POINTS, NONE};
    tempRand = rand()%100+1;
    if(tempRand <= 80){
        rPow = NONE;
    }else if(tempRand <= 95){
        rPow = MORE_POINTS;
    }else{
        rPow = MORE_BALLS;
    }
}

inline void setGameBricks(int BrickPerLine){
    /*
    vec2 topXY;
    vec2 bottomXY;

    vec4 color;
    
    bool destroyed;
    real32 timeSinceDestruction;
    powerUp brickPower;
    */
    gameBricks.clear();
    gameBricks.resize(5,std::vector<brick>(BrickPerLine));

for(int row = 0; row < 5; row++){
        currentRowSize = 1;
        for(int column = 0; column < BrickPerLine-1; column++){
            randomWidth = ((WIDTH-2)/(BrickPerLine))+(rand()%5 - 2);
            randomPowerUp(randomPower);
            gameBricks.at(row).at(column) = {
                {(real32)currentRowSize,(real32)((row*10)+20)},
                {(real32)(currentRowSize+randomWidth-1),(real32)((row*10)+29)},
                {1.0f,1.0f,1.0f,1.0f},
                false,
                0.0f,
                randomPower
            };
            currentRowSize += randomWidth;
        }
        randomPowerUp(randomPower);
        gameBricks.at(row).at(BrickPerLine-1) = {
            {(real32)(currentRowSize),(real32)((row*10)+20)},
            {(real32)(WIDTH-2),(real32)((row*10)+29)},
            {1.0f,1.0f,1.0f,1.0f},
            false,
            0.0f,
            randomPower
        };
    }

    /*
    for(int row = 0; row < 5; row++){
        currentRowSize = 1;
        for(int column = 0; column < BrickPerLine-1; column++){
            randomWidth = floor((real32)(WIDTH-2)/(BrickPerLine-column-1))+(rand()%5 - 2);
            randomPowerUp(randomPower);
            gameBricks.at(row).at(column) = {
                {currentRowSize,(real32)((row*10)+20)},
                {currentRowSize+randomWidth-1,(real32)((row*10)+29)},
                {1.0f,1.0f,1.0f,1.0f},
                false,
                0.0f,
                randomPower
            };
            currentRowSize += randomWidth;
        }
        randomPowerUp(randomPower);
        gameBricks.at(row).at(BrickPerLine-1) = {
            {currentRowSize,(real32)((row*10)+20)},
            {WIDTH-3,(real32)((row*10)+29)},
            {1.0f,1.0f,1.0f,1.0f},
            false,
            0.0f,
            randomPower
        };
    }
    */
}

// reset balls to only 1
inline void setGameBalls(){
    /*
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;

    vec4 color;

    vec2 direction;
    real32 speed;
    */
    activeBalls.clear();
    previousBalls.clear();
    activeBalls.push_back({
        {(WIDTH/2)-3, ((HEIGHT*7)/8)-3},
        {(WIDTH/2)+3, ((HEIGHT*7)/8)+3},
        {WIDTH/2, (HEIGHT*7)/8},
        {1.0f,1.0f,1.0f,1.0f},
        {(real32)sqrt(3)/2,-0.5f},
        65.0f
    });
}

// Set Paddle to the middle of the Screen
inline void setGamePaddle(){
    /*
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;
    
    vec4 color;

    vec2 direction;
    real32 speed;
    inputDev moveDevice;
    */
    gamePaddle = {
        {(WIDTH/2)-20, ((HEIGHT*15)/16)-1},
        {(WIDTH/2)+20, ((HEIGHT*15)/16)+1},
        {WIDTH/2, (HEIGHT*15)/16},
        {1.0f,1.0f,1.0f,1.0f},
        {0.0f,0.0f},
        100.0f,
        keybd
    };
    
}

bool clickInBox(vec2 topXY, vec2 bottomXY){
    gameProperties.currentMouseX = GetMousePositionX();
    gameProperties.currentMouseY = GetMousePositionY();
    if(gameProperties.currentMouseX >= topXY.x && gameProperties.currentMouseX <= bottomXY.x)
    {
        if(gameProperties.currentMouseY >= topXY.y && gameProperties.currentMouseY <= bottomXY.y){
            return true;
        }
    }
    return false;
}

// Manage Main Menu Buttons
inline void mainMenuMechanics(){
    if(InputPressed(Mouse, Input_MouseLeft)){
        if(clickInBox(gamePlayButton.topXY, gamePlayButton.bottomXY)){
            gameProperties.gameStarted = true;
        }
    }
}

//draws hollow Squares
inline void drawHollowSquare(vec2 topXY, vec2 bottomXY,vec3 color){
    for(int top = topXY.x; top < bottomXY.x; top++){
        SetTileColor(top, topXY.y, color.x, color.y, color.z);
    }

    for(int bottom = topXY.x; bottom < bottomXY.x; bottom++){
        SetTileColor(bottom, bottomXY.y, color.x, color.y, color.z);
    }

    for(int left = topXY.y; left < bottomXY.y; left++){
        SetTileColor(topXY.x, left, color.x, color.y, color.z);
    }

    for(int right = topXY.y; right < bottomXY.y; right++){
        SetTileColor(bottomXY.x, right, color.x, color.y, color.z);
    }
}

// Show Main Menu
inline void showMainMenu(){
    drawHollowSquare({0,0}, {WIDTH-1, HEIGHT-1}, {1.0f,1.0f,1.0f});
    drawHollowSquare(gamePlayButton.topXY, gamePlayButton.bottomXY, {1.0f,1.0f,1.0f});
    DrawTextTile({gamePlayButton.center.x,gamePlayButton.center.y+4}, 8.0f, {1.0f,1.0f,1.0f}, true, gamePlayButton.textOfButton.c_str());
    DrawTextTile({(WIDTH/2),HEIGHT/4}, 8.0f, {1.0f,1.0f,1.0f}, true, "Atari Breakout");
}

// check Collisions
Ray2D ray1;
Ray2D ray2;
Ray2D ray3;
real32* closestMin = new real32(999.0f);
real32* tempMin = new real32(999.0f);
bool checkBallCollision(ball& currentBall){
    // RaycastAABB(vec2 aabbMin, vec2 aabbMax, vec2 origin, vec2 direction, real32 *tMin, bool testInside = false, real32 epsilon = FLT_EPSILON)
    // direct ray
    ray1 = {
        {currentBall.center.x + (currentBall.direction.x * 3.5f) , currentBall.center.y + (currentBall.direction.y * 3.5f)},
        currentBall.direction
    };
    // left Ray
    ray2 = {
        {currentBall.center.x - (currentBall.direction.y * 3.5f) , currentBall.center.y + (currentBall.direction.x * 3.5f)},
        currentBall.direction
    };
    // right Ray
    ray3 = {
        {currentBall.center.x + (currentBall.direction.y * 3.5f) , currentBall.center.y - (currentBall.direction.x * 3.5f)},
        currentBall.direction
    };

    *tempMin = 0.0f;

    for(int row = 0; row < gameBricks.size(); row++){
        for(int column = 0; column < gameBricks.at(row).size(); column++){
            if(gameBricks.at(row).at(column).destroyed){
                continue;
            }
            if(RaycastAABB(gameBricks.at(row).at(column).topXY, gameBricks.at(row).at(column).bottomXY, ray1.origin, ray1.direction, tempMin)){
                return true;
            } else{
                if(RaycastAABB(gameBricks.at(row).at(column).topXY, gameBricks.at(row).at(column).bottomXY, ray2.origin, ray2.direction, tempMin)){
                    return true;
                }else{
                    if(RaycastAABB(gameBricks.at(row).at(column).topXY, gameBricks.at(row).at(column).bottomXY, ray3.origin, ray3.direction, tempMin)){
                        return true;
                    }
                }
            }
        }
    }
    if(RaycastAABB(gamePaddle.topXY,gamePaddle.bottomXY, ray1.origin, ray1.direction, tempMin)){
        return true;
    }else{
        if(RaycastAABB(gamePaddle.topXY,gamePaddle.bottomXY, ray2.origin, ray2.direction, tempMin)){
            return true;
        }else{
            if(RaycastAABB(gamePaddle.topXY,gamePaddle.bottomXY, ray3.origin, ray3.direction, tempMin)){
                return true;
            }
        }
    }
    return false;
}

void calculateClosestObjectToBall(ball& currentBall){
    // RaycastAABB(vec2 aabbMin, vec2 aabbMax, vec2 origin, vec2 direction, real32 *tMin, bool testInside = false, real32 epsilon = FLT_EPSILON)
    // direct ray
    ray1 = {
        {currentBall.center.x + (currentBall.direction.x * 3) , currentBall.center.y + (currentBall.direction.y * 3)},
        currentBall.direction
    };
    // left Ray
    ray2 = {
        {currentBall.center.x - (currentBall.direction.y * 3) , currentBall.center.y + (currentBall.direction.x * 3)},
        currentBall.direction
    };
    // right Ray
    ray3 = {
        {currentBall.center.x + (currentBall.direction.y * 3) , currentBall.center.y - (currentBall.direction.x * 3)},
        currentBall.direction
    };



    *tempMin = 999.0f;
    *closestMin = *tempMin;

    for(int row = 0; row < gameBricks.size(); row++){
        for(int column = 0; column < gameBricks.at(row).size(); column++){
            if(gameBricks.at(row).at(column).destroyed){
                continue;
            }
            if(RaycastAABB(gameBricks.at(row).at(column).topXY, gameBricks.at(row).at(column).bottomXY, ray1.origin, ray1.direction, tempMin)){
                *closestMin = (*tempMin < *closestMin) ? *tempMin : *closestMin;
            } else{
                if(RaycastAABB(gameBricks.at(row).at(column).topXY, gameBricks.at(row).at(column).bottomXY, ray2.origin, ray2.direction, tempMin)){
                    *closestMin = (*tempMin < *closestMin) ? *tempMin : *closestMin;
                }else{
                    if(RaycastAABB(gameBricks.at(row).at(column).topXY, gameBricks.at(row).at(column).bottomXY, ray3.origin, ray3.direction, tempMin)){
                        *closestMin = (*tempMin < *closestMin) ? *tempMin : *closestMin;
                    }
                }
            }
        }
    }
    if(RaycastAABB(gamePaddle.topXY,gamePaddle.bottomXY, ray1.origin, ray1.direction, tempMin)){
        *closestMin = (*tempMin < *closestMin) ? *tempMin : *closestMin;
    }else{
        if(RaycastAABB(gamePaddle.topXY,gamePaddle.bottomXY, ray2.origin, ray2.direction, tempMin)){
            *closestMin = (*tempMin < *closestMin) ? *tempMin : *closestMin;
        }else{
            if(RaycastAABB(gamePaddle.topXY,gamePaddle.bottomXY, ray3.origin, ray3.direction, tempMin)){
                *closestMin = (*tempMin < *closestMin) ? *tempMin : *closestMin;
            }
        }
    }
    
}
void changeBallDimension(ball& currentBall){
    currentBall.topXY = {currentBall.center.x-3,currentBall.center.y-3};
    currentBall.bottomXY = {currentBall.center.x+3,currentBall.center.y+3};
}

real32 placeHit;

void calculatePaddleHit(ball& currentBall){
    placeHit = currentBall.center.x + (*closestMin * currentBall.direction.x) / (currentBall.direction.x * currentBall.speed);
    currentBall.direction.x = cos((3.0/2.0)+M_PI+((placeHit-gamePaddle.center.x)/(gamePaddle.bottomXY.x-gamePaddle.center.x))*(1.0/3.0)*M_PI); // (((gamePaddle.center.x-placeHit)/(gamePaddle.bottomXY.x-gamePaddle.center.x))*(1.0/3.0))
    currentBall.direction.y = sin((3.0/2.0)*M_PI+((placeHit-gamePaddle.center.x)/(gamePaddle.bottomXY.x-gamePaddle.center.x))*(1.0/3.0)*M_PI); // 0.5f+M_PI+((placeHit)/(gamePaddle.bottomXY.x-gamePaddle.center.x))*(1.0/3.0)*M_PI)
    currentBall.speed *= (currentBall.speed<90.0f) ? 1.1 : 1.0;
}

void duplicateBalls(){
    std::vector<ball> duplicateBalls1 = activeBalls;
    std::vector<ball> duplicateBalls2 = activeBalls;
    for(int i = 0; i < duplicateBalls1.size(); i++){
        duplicateBalls1.at(i).direction.x = -duplicateBalls1.at(i).direction.y;
        duplicateBalls1.at(i).direction.y = duplicateBalls1.at(i).direction.x;
    }
    for(int i = 0; i < duplicateBalls2.size(); i++){
        duplicateBalls2.at(i).direction.x = duplicateBalls2.at(i).direction.y;
        duplicateBalls2.at(i).direction.y = -duplicateBalls2.at(i).direction.x;
    }
    activeBalls.insert(activeBalls.end(), duplicateBalls1.begin(), duplicateBalls1.end());
    activeBalls.insert(activeBalls.end(), duplicateBalls2.begin(), duplicateBalls2.end());
}

void destroyBrick(brick& currentBrick){
    currentBrick.destroyed = true;
    if(currentBrick.brickPower == NONE){
        gameProperties.currentScore += 10;
    }else if (currentBrick.brickPower == MORE_BALLS){
        gameProperties.currentScore += 10;
        duplicateBalls();
    }else if (currentBrick.brickPower == MORE_POINTS){
        gameProperties.currentScore += 1000;
    }
}

void handleBallColisions(ball& currentBall){
    for(int row = 0; row < gameBricks.size(); row++){
        for(int column = 0; column < gameBricks.at(row).size(); column++){
            if(gameBricks.at(row).at(column).destroyed){
                continue;
            }
            // Brick
            if(currentBall.direction.x>0){
                if(RaycastAABB(gameBricks.at(row).at(column).topXY,{gameBricks.at(row).at(column).topXY.x, gameBricks.at(row).at(column).bottomXY.y}, ray1.origin, ray1.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.x*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
                if(RaycastAABB(gameBricks.at(row).at(column).topXY,{gameBricks.at(row).at(column).topXY.x, gameBricks.at(row).at(column).bottomXY.y}, ray2.origin, ray2.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.x*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
                if(RaycastAABB(gameBricks.at(row).at(column).topXY,{gameBricks.at(row).at(column).topXY.x, gameBricks.at(row).at(column).bottomXY.y}, ray3.origin, ray3.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.x*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
            }
            if(currentBall.direction.y>0){
                if(RaycastAABB(gameBricks.at(row).at(column).topXY,{gameBricks.at(row).at(column).bottomXY.x, gameBricks.at(row).at(column).topXY.y}, ray1.origin, ray1.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.y*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
                if(RaycastAABB(gameBricks.at(row).at(column).topXY,{gameBricks.at(row).at(column).bottomXY.x, gameBricks.at(row).at(column).topXY.y}, ray2.origin, ray2.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.y*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
                if(RaycastAABB(gameBricks.at(row).at(column).topXY,{gameBricks.at(row).at(column).bottomXY.x, gameBricks.at(row).at(column).topXY.y}, ray3.origin, ray3.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.y*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
            }
                
            if(currentBall.direction.x<0){
                if(RaycastAABB({gameBricks.at(row).at(column).bottomXY.x,gameBricks.at(row).at(column).topXY.y},gameBricks.at(row).at(column).bottomXY, ray1.origin, ray1.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.x*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                    
                }
                if(RaycastAABB({gameBricks.at(row).at(column).bottomXY.x,gameBricks.at(row).at(column).topXY.y},gameBricks.at(row).at(column).bottomXY, ray2.origin, ray2.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.x*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
                if(RaycastAABB({gameBricks.at(row).at(column).bottomXY.x,gameBricks.at(row).at(column).topXY.y},gameBricks.at(row).at(column).bottomXY, ray3.origin, ray3.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.x*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
            }
            
            if(currentBall.direction.y<0){
                if(RaycastAABB({gameBricks.at(row).at(column).topXY.x,gameBricks.at(row).at(column).bottomXY.y},gameBricks.at(row).at(column).bottomXY, ray1.origin, ray1.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.y*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
                if(RaycastAABB({gameBricks.at(row).at(column).topXY.x,gameBricks.at(row).at(column).bottomXY.y},gameBricks.at(row).at(column).bottomXY, ray2.origin, ray2.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.y*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
                if(RaycastAABB({gameBricks.at(row).at(column).topXY.x,gameBricks.at(row).at(column).bottomXY.y},gameBricks.at(row).at(column).bottomXY, ray3.origin, ray3.direction, tempMin) && !gameBricks.at(row).at(column).destroyed){
                    if(*tempMin < 3.5){
                        currentBall.direction.y*=-1;
                        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
                        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
                        destroyBrick(gameBricks.at(row).at(column));
                        goto endOfBallColisions;
                    }
                }
            }
            
        }
        
    }
    endOfBallColisions:
    // Paddle
    if(RaycastAABB(gamePaddle.topXY,gamePaddle.bottomXY, ray1.origin, ray1.direction, tempMin) && *tempMin < 3.5 && currentBall.direction.y>0){
        calculatePaddleHit(currentBall);
        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
    }else if(RaycastAABB(gamePaddle.topXY,gamePaddle.bottomXY, ray2.origin, ray2.direction, tempMin) && *tempMin < 3.5 && currentBall.direction.y>0){
        calculatePaddleHit(currentBall);
        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
    }else if(RaycastAABB(gamePaddle.topXY,gamePaddle.bottomXY, ray3.origin, ray3.direction, tempMin) && *tempMin < 3.5 && currentBall.direction.y>0){
        calculatePaddleHit(currentBall);
        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
    }
    
}

real32 tempNextXStep;
real32 tempNextYStep;
void moveBall(ball& currentBall){
    /*
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;

    vec4 color;

    vec2 direction;
    real32 speed;
    */

   /*
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;

    vec4 color;

    real32 timeSinceChange;
   */
    previousBalls.push_back({
        currentBall.topXY,
        currentBall.bottomXY,
        currentBall.center,
        {currentBall.color.r,currentBall.color.g, currentBall.color.b, currentBall.color.a*0.5f},
        0
    });

    tempNextXStep = (DeltaTime * currentBall.speed * currentBall.direction.x);
    tempNextYStep = (DeltaTime * currentBall.speed * currentBall.direction.y);

    if((currentBall.center.x+3)+tempNextXStep > WIDTH-2 && currentBall.direction.x > 0){
        currentBall.direction.x *= -1;
        currentBall.center.x += ((WIDTH-2) - (currentBall.center.x + tempNextXStep));
        currentBall.center.y += tempNextYStep;
        changeBallDimension(currentBall);
    }else if((currentBall.center.x-3)+tempNextXStep < 0 && currentBall.direction.x < 0){
        currentBall.direction.x *= -1;
        currentBall.center.x += (-2 + (currentBall.center.x + tempNextXStep));
        currentBall.center.y += tempNextYStep;
        changeBallDimension(currentBall);
    }else if((currentBall.center.y-3)+tempNextYStep < 0 && currentBall.direction.y < 0){
        currentBall.direction.y *= -1;
        currentBall.center.x += tempNextXStep;
        currentBall.center.y += (-2 + (currentBall.center.y + tempNextYStep));
        changeBallDimension(currentBall);
    }else if(checkBallCollision(currentBall)){

        calculateClosestObjectToBall(currentBall);
        if(*closestMin > 3.5){
            Print("%f", *tempMin);
            Print("%f", *closestMin);
            currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
            currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
        }else{
            handleBallColisions(currentBall);
        }
        changeBallDimension(currentBall);
    }else{
        currentBall.center.x += DeltaTime * currentBall.speed * currentBall.direction.x;
        currentBall.center.y += DeltaTime * currentBall.speed * currentBall.direction.y; 
        changeBallDimension(currentBall);
    }
}

// Move Balls
void moveGameBalls(){
    for(int ballIndex = 0; ballIndex < activeBalls.size(); ballIndex++){
        moveBall(activeBalls.at(ballIndex));
    }
}

void updatePaddle(){
    gamePaddle.topXY = {gamePaddle.center.x-20,gamePaddle.center.y-1};
    gamePaddle.bottomXY = {gamePaddle.center.x+20,gamePaddle.center.y+1};
}

// Move Paddle with keyboard or mouse
void movePaddle(){

    /*
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;
    
    vec4 color;

    vec2 direction;
    real32 speed;
    inputDev moveDevice;
    */

    if (InputPressed(Mouse, Input_MouseLeft)){
        gamePaddle.moveDevice = point;
    }

    if(InputHeld(Keyboard, Input_LeftArrow)){
        gamePaddle.moveDevice = keybd;
        if(gamePaddle.center.x-21-(DeltaTime * gamePaddle.speed) > 0){
            gamePaddle.center.x -= (DeltaTime * gamePaddle.speed);
        }
    }
    if(InputHeld(Keyboard, Input_RightArrow)){
        gamePaddle.moveDevice = keybd;
        if(gamePaddle.center.x+21+(DeltaTime * gamePaddle.speed) < WIDTH - 2){
            gamePaddle.center.x += (DeltaTime * gamePaddle.speed);
        }
        
    }
    if(gamePaddle.moveDevice == point){
        gameProperties.currentMouseX = GetMousePositionX();
        gameProperties.currentMouseY = GetMousePositionY();
        
        if((gamePaddle.center.x + (DeltaTime * gamePaddle.speed) > gameProperties.currentMouseX)
        && (gamePaddle.center.x-21-(DeltaTime * gamePaddle.speed) > 0)
        && gameProperties.currentMouseX > 0){

            gamePaddle.center.x -= (DeltaTime * gamePaddle.speed);

        }else if((gamePaddle.center.x + (DeltaTime * gamePaddle.speed) < gameProperties.currentMouseX)
        && (gamePaddle.center.x+21+(DeltaTime * gamePaddle.speed) < WIDTH)
        && gameProperties.currentMouseX < WIDTH){

            gamePaddle.center.x += (DeltaTime * gamePaddle.speed);

        }
    }
    updatePaddle();
}

void removeBalls(){
    for(int i = activeBalls.size()-1; i >= 0; i--){
        if(activeBalls.at(i).center.y > HEIGHT){
            activeBalls.erase(activeBalls.begin()+i);
        }
    }
    for(int i = previousBalls.size()-1; i >= 0; i--){
        if(previousBalls.at(i).timeSinceChange> 0.5f){
            previousBalls.erase(previousBalls.begin()+i);
        }
    }
}

void removeBricks(){
    /*
    vec2 topXY;
    vec2 bottomXY;

    vec4 color;
    
    bool destroyed;
    real32 timeSinceDestruction;
    */

    for(int i = gameBricks.size()-1; i >= 0; i--){
        for(int i2 = gameBricks.at(i).size()-1; i2 >= 0; i2--){
            if(gameBricks.at(i).at(i2).destroyed && gameBricks.at(i).at(i2).timeSinceDestruction > DeltaTime*3.0){
                gameBricks.erase(gameBricks.begin()+i);
            }
        }
    }
}

inline void showGameWalls(){
    for(int top = 0; top < WIDTH; top++){
        SetTileColor(top, 0, 1.0f, 1.0f, 1.0f);
    }

    for(int left = 0; left < HEIGHT; left++){
        SetTileColor(0, left, 1.0f, 1.0f, 1.0f);
    }

    for(int right = 0; right < HEIGHT; right++){
        SetTileColor(WIDTH-1, right, 1.0f, 1.0f, 1.0f);
    }
}

void drawBall(ball &currentBall){
    /*
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;

    vec4 color;

    vec2 direction;
    real32 speed;
    */
    currentBall.color = {0,Lerp(0,1,currentBall.speed/200),Lerp(0,1,currentBall.speed/100),1.0f};
    for(int x = currentBall.center.x-1; x <= currentBall.center.x+1; x++){
        for(int y = currentBall.topXY.y; y <= currentBall.bottomXY.y; y+=6){
            SetTileColor(x,y, currentBall.color);
        }
    }
// Infinite LOOP?????
    for(int x = currentBall.topXY.x; x <= currentBall.bottomXY.x; x+=6){
        for(int y = currentBall.center.y-1; y <= currentBall.center.y+1; y++){
            SetTileColor(x,y, currentBall.color);
        }
    }
    for(int x = currentBall.center.x-2; x <= currentBall.center.x+2; x++){
        for(int y = currentBall.center.y-2; y <= currentBall.center.y+2; y++){
           SetTileColor(x,y, currentBall.color);
        }
    }
}

void drawPastBalls(falseBall &currentBall){
    /*
    vec2 topXY;
    vec2 bottomXY;
    vec2 center;

    vec4 color;

    real32 timeSinceChange;
    */
    for(int x = currentBall.center.x-1; x <= currentBall.center.x+1; x++){
        for(int y = currentBall.topXY.y; y <= currentBall.bottomXY.y; y+=6){
            SetTileColor(x,y, currentBall.color);
        }
    }

    for(int x = currentBall.topXY.x; x <= currentBall.bottomXY.x; x+=6){
        for(int y = currentBall.center.y-1; y <= currentBall.center.y+1; y++){
            SetTileColor(x,y, currentBall.color);
        }
    }

    for(int x = currentBall.center.x-2; x <= currentBall.center.x+2; x++){
        for(int y = currentBall.center.y-2; y <= currentBall.center.y+2; y++){
            SetTileColor(x,y, currentBall.color);
        }
    }
}

void showBalls(){
    for(int i = 0; i < previousBalls.size(); i++){
        drawPastBalls(previousBalls.at(i));
    }
    for(int i = 0; i < activeBalls.size(); i++){
        drawBall(activeBalls.at(i));
    }
    
}

void drawBrick(brick &currentBrick){
    for(int x = currentBrick.topXY.x; x <= currentBrick.bottomXY.x; x++){
        for(int y = currentBrick.topXY.y; y <= currentBrick.bottomXY.y; y++){
            SetTileColor(x,y, currentBrick.color);
        }
    }
}

void drawDestroyedBrick(brick &currentBrick){
    for(int x = currentBrick.topXY.x; x <= currentBrick.bottomXY.x; x++){
        for(int y = currentBrick.topXY.y; y <= currentBrick.bottomXY.y; y++){
            SetTileColor(x,y, {Lerp(1.0,0.0,(currentBrick.timeSinceDestruction < 1.5) ? 0 : currentBrick.timeSinceDestruction-1.5)
            ,Lerp(1.0,0.0,(currentBrick.timeSinceDestruction < 1) ? currentBrick.timeSinceDestruction : 1)
            ,Lerp(1.0,0.0,(currentBrick.timeSinceDestruction < 1) ? currentBrick.timeSinceDestruction : 1)
            ,Lerp(1.0,0.0,(currentBrick.timeSinceDestruction < 1.5) ? 0 : currentBrick.timeSinceDestruction-1.5)});
        }
    }
}

void showBricks(){
    for(int i = 0; i < gameBricks.size(); i++){
        for(brick a: gameBricks.at(i)){
            if(!a.destroyed){
                drawBrick(a);
            }else if(a.destroyed && a.timeSinceDestruction < 3.0){
                drawDestroyedBrick(a);
            }
        }
    }
}

void showPaddle(){
    for(int x = gamePaddle.topXY.x; x <= gamePaddle.bottomXY.x; x++){
        for(int y = gamePaddle.topXY.y; y <= gamePaddle.bottomXY.y; y++){
            SetTileColor(x,y, gamePaddle.color);
        }
    }
}

void updateTimers(){
    for(int i = 0; i < previousBalls.size(); i++){
        previousBalls.at(i).timeSinceChange += DeltaTime;
    }

    for(int y = 0; y < gameBricks.size(); y++){
        for(int x = 0; x < gameBricks.at(y).size(); x++){
            if(gameBricks.at(y).at(x).destroyed){
                gameBricks.at(y).at(x).timeSinceDestruction += DeltaTime;
            }
        }
    }

    gameProperties.time += DeltaTime;
}

void updateBricks(){
    brick currBrick;
    for(int row = 0; row < gameBricks.size(); row++){
        for(int column = gameBricks.at(row).size()-1; column >= 0; column--){
            if(gameBricks.at(row).at(column).destroyed){
                currBrick = gameBricks.at(row).at(column);
                gameBricks.at(row).erase(gameBricks.at(row).begin()+column);
                gameBricks.at(row).push_back(currBrick);
            }
        }
    }
    
}

real32 tempfRand;
void updateBrickColors(){
    for(int row = 0; row < gameBricks.size(); row++){
        for(int column = gameBricks.at(row).size()-1; column >= 0; column--){
            if(gameBricks.at(row).at(column).brickPower == MORE_BALLS){
                gameBricks.at(row).at(column).color = {0.8f, 0.6f, 1.0f, 1.0f};
            }else if(gameBricks.at(row).at(column).brickPower == MORE_POINTS){
                gameBricks.at(row).at(column).color = {1.0f, 1.0f, 0.6f, 1.0f};
            }else if(gameBricks.at(row).at(column).brickPower == NONE){
                tempfRand = (rand() % 128+127)/256.0;
                gameBricks.at(row).at(column).color = {tempfRand, tempfRand, tempfRand, 1.0f};
            }
        }
    }
}

bool hasWon(){
    for(int row = 0; row < gameBricks.size(); row++){
        for(int column = gameBricks.at(row).size()-1; column >= 0; column--){
            if(!gameBricks.at(row).at(column).destroyed){
                return false;
            }
        }
    }
    return true;
}

bool hasLost(){
    return activeBalls.size()<=0;
}

void updateStats(){
    if(gameProperties.highScore < gameProperties.currentScore){
        gameProperties.highScore = gameProperties.currentScore;
    }
}

// Manage Main Menu Buttons
inline void gameOverMechanics(){
    if(InputPressed(Mouse, Input_MouseLeft)){
        if(clickInBox(gamePlayButton.topXY, gamePlayButton.bottomXY)){
            /*
            real32 time = 0;
            bool gameStarted = false;
            bool gameEnded = false;
            int32 blocksLeft;
            int32 level = 1;
            int32 currentScore = 0;
            int32 highScore = 0;
            int32 currentMouseX;
            int32 currentMouseY;
            */
            gameProperties.gameEnded = false;
            gameProperties.gameStarted = true;
            gameProperties.currentScore = 0;
            gameProperties.level = 1;
            gameProperties.time = 0;
        }
    }
}

// Show Main Menu
inline void showGameOver(){
    drawHollowSquare({0,0}, {WIDTH-1, HEIGHT-1}, {1.0f,1.0f,1.0f});
    drawHollowSquare(gamePlayButton.topXY, gamePlayButton.bottomXY, {1.0f,1.0f,1.0f});
    DrawTextTile({gamePlayButton.center.x,gamePlayButton.center.y+4}, 8.0f, {1.0f,1.0f,1.0f}, true, "Again?");
    DrawTextTile({(WIDTH/2),HEIGHT/4}, 8.0f, {1.0f,1.0f,1.0f}, true, "Game Over");
}


void showStats(){
    DrawTextTile({(WIDTH/2),HEIGHT/16}, 4.0f, {1.0f,1.0f,1.0f}, true, "Breakout");
    DrawTextTile({40.0f,-HEIGHT/32}, 4.0f, {1.0f,1.0f,1.0f}, true, "HighScore: %d", gameProperties.highScore);
    DrawTextTile({(WIDTH-40.0f),-HEIGHT/32}, 4.0f, {1.0f,1.0f,1.0f}, true, "Score: %d", gameProperties.currentScore);
    DrawTextTile({(WIDTH/2)-20.0f,-HEIGHT/32}, 4.0f, {1.0f,1.0f,1.0f}, true, "Lvl: %i", gameProperties.level);
    DrawTextTile({(WIDTH/2)+20.0f,-HEIGHT/32}, 4.0f, {1.0f,1.0f,1.0f}, true, "T: %1.f s", gameProperties.time);
}

void nextLevel(){
    gameProperties.level++;

    setGameBricks(11 + ((gameProperties.level<5) ? gameProperties.level : 5) - 1);
    setGameBalls();
    setGamePaddle();
    updateBrickColors();
}

void MyMosaicInit() {
    SetMosaicGridSize(WIDTH, HEIGHT);

    gamePlayButton = {
        {(WIDTH/2)-31,(HEIGHT/2)-11},
        {(WIDTH/2)+29,(HEIGHT/2)+9},
        {(WIDTH/2)-1,(HEIGHT/2)-1},
        "Play"
    };

    setGameBricks(11);
    setGameBalls();
    setGamePaddle();
    updateBrickColors();
}

void MyMosaicUpdate() {
    ClearTiles(0, 0, 0);

    if(!gameProperties.gameStarted){
        
        mainMenuMechanics();
        showMainMenu();
    }

    if(gameProperties.gameStarted && !gameProperties.gameEnded){
        /*
        real32 time = 0;
        bool gameStarted = false;
        bool gameEnded = false;
        int32 blocksLeft;
        int32 level = 1;
        int32 currentScore = 0;
        int32 highScore = 0;
        int32 currentMouseX;
        int32 currentMouseY;
        */

        // Game Physics
        movePaddle();
        moveGameBalls();

        // Game Visuals
        
        showBricks();
        showBalls();
        showPaddle();
        showGameWalls();

        removeBalls();

        updateBricks();
        updateTimers();
        updateStats();

        showStats();

        if(hasLost()){
            gameProperties.gameEnded = true;
        }
        if(hasWon()){
            nextLevel();
        }
    }

    if(gameProperties.gameEnded){
        gameOverMechanics();
        showGameOver();

        setGameBricks(11);
        setGameBalls();
        setGamePaddle();
        updateBrickColors();
    }


    
    //SetTileColor(0, 0, 0.8f, 0.3f, 0.3f);
}
