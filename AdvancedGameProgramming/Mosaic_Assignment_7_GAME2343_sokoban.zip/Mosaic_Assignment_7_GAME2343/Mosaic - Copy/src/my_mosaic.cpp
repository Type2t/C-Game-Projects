#include <fstream>
#include <vector>
#include <string>

SoundClip songFile;
SoundHandle songHan;

const int WIDTH = 240;
const int HEIGHT = 240;

enum BlockType{
    WALL, SAND, DOOR, OPEN_DOOR, CRATES, BUTTON, BLUE_POTION, START, PLAYER, NOTHING, PURPLE_POTION, FAKE_CRATE
};

struct Pixel
{
    vec2i position;
    vec4 color;
};

struct Block{
    vec2i position;
    BlockType type;
    bool enabled = false;
};

struct Player
{
    vec2i position;
};

struct GameTextures{
    DynamicArray<Pixel> Wall;
    DynamicArray<Pixel> Box;
    DynamicArray<Pixel> Sand;
    DynamicArray<Pixel> Door;
    DynamicArray<Pixel> Button;
    DynamicArray<Pixel> PlayTX;
    DynamicArray<Pixel> BluePotion;
    DynamicArray<Pixel> PurplePotion;
};

struct Layer{
    DynamicArray<Block> BackgroundLayer;
    DynamicArray<Block> UpperLayer;
};

struct GameData
{
    int32 Level;
    int32 CurrentMove;
    int32 MaxMoves;

    DynamicArray<Player> CurrentPlayer;

    GameTextures CurrentTextures;

    DynamicArray<Layer> MoveLayers;

    bool LevelRestart;
    bool LevelPassed;
    bool LevelLost;
    bool GameWon;
};

MemoryArena WorkspaceGame = {};
void* currentGameData;
GameData* currentGame;

inline void LoadGameVariables(){
    AllocateMemoryArena(&WorkspaceGame, Megabytes(16));
    currentGameData = PushSize(&WorkspaceGame, sizeof(GameData));
    currentGame = (GameData *)currentGameData;
}

BlockType TypeAtBackground(int x, int y){
    for(int i = 0; i < currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer.count; i++){
        if(currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer[i].position.x == x && currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer[i].position.y == y){
            return currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer[i].type;
        }
    }
    return NOTHING;
}

BlockType TypeAtUpper(int x, int y){
    for(int i = 0; i < currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer.count; i++){
        if(currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer[i].position.x == x && currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer[i].position.y == y){
            return currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer[i].type;
        }
    }
    return NOTHING;
}

inline void LoadTextures(){
    std::fstream CurrentFile;
    Pixel TempPixel;

    std::vector<std::string> files{
        "data/texture_files/wall.dat", "data/texture_files/box.dat","data/texture_files/sand.dat","data/texture_files/door.dat","data/texture_files/button.dat", "data/texture_files/player.dat","data/texture_files/blue_potion.dat","data/texture_files/purple_potion.dat"
    };

    for(std::string file: files){

        CurrentFile.open(file);

        int TempCount;

        CurrentFile >> TempCount;
        if(file == files.at(0)){
            currentGame -> CurrentTextures.Wall = MakeDynamicArray<Pixel>(&WorkspaceGame, TempCount);
        } else if(file == files.at(1)){
            currentGame -> CurrentTextures.Box = MakeDynamicArray<Pixel>(&WorkspaceGame, TempCount);
        } else if(file == files.at(2)){
            currentGame -> CurrentTextures.Sand = MakeDynamicArray<Pixel>(&WorkspaceGame, TempCount);
        }else if(file == files.at(3)){
            currentGame -> CurrentTextures.Door = MakeDynamicArray<Pixel>(&WorkspaceGame, TempCount);
        }else if(file == files.at(4)){
            currentGame -> CurrentTextures.Button = MakeDynamicArray<Pixel>(&WorkspaceGame, TempCount);
        }else if(file == files.at(5)){
            currentGame -> CurrentTextures.PlayTX = MakeDynamicArray<Pixel>(&WorkspaceGame, TempCount);
        }else if(file == files.at(6)){
            currentGame -> CurrentTextures.BluePotion = MakeDynamicArray<Pixel>(&WorkspaceGame, TempCount);
        }else if(file == files.at(7)){
            currentGame -> CurrentTextures.PurplePotion = MakeDynamicArray<Pixel>(&WorkspaceGame, TempCount);
        }
        /*DynamicArray<Pixel> BluePotion;
    DynamicArray<Pixel> PurplePotion;*/
        
        for(int i = 0; i < TempCount; i++){
            // vec2i position;
            // vec4 color;
            CurrentFile >> TempPixel.position.x;
            CurrentFile >> TempPixel.position.y;
            CurrentFile >> TempPixel.color.r;
            CurrentFile >> TempPixel.color.g;
            CurrentFile >> TempPixel.color.b;

            TempPixel.color.r /= 255.0f;
            TempPixel.color.g /= 255.0f;
            TempPixel.color.b /= 255.0f;
            TempPixel.color.a = 1.0f;

            if(file == files.at(0)){
                PushBack(&currentGame -> CurrentTextures.Wall, TempPixel);
            } else if(file == files.at(1)){
                PushBack(&currentGame -> CurrentTextures.Box, TempPixel);
            } else if(file == files.at(2)){
                PushBack(&currentGame -> CurrentTextures.Sand, TempPixel);
            }else if(file == files.at(3)){
                PushBack(&currentGame -> CurrentTextures.Door, TempPixel);
            }else if(file == files.at(4)){
                PushBack(&currentGame -> CurrentTextures.Button, TempPixel);
            }else if(file == files.at(5)){
                PushBack(&currentGame -> CurrentTextures.PlayTX, TempPixel);
            }else if(file == files.at(6)){
                PushBack(&currentGame -> CurrentTextures.BluePotion, TempPixel);
            }else if(file == files.at(7)){
                PushBack(&currentGame -> CurrentTextures.PurplePotion, TempPixel);
            }
        }

        CurrentFile.close();
    }
    
    
}

inline void LoadFirstLevel(){
    currentGame -> Level = 1;
    
    currentGame -> LevelRestart = false;
    currentGame -> LevelPassed = false;
    currentGame -> LevelLost = false;
    currentGame -> GameWon = false;

    std::fstream CurrentFile;
    int MapWidth;
    int MapHeight;
    int MoveCount;
    int ObjectCount;

    int TempEnum;

    CurrentFile.open("data/map_levels/level_1.dat");
    
    CurrentFile >> MapWidth;
    CurrentFile >> MapHeight;
    CurrentFile >> MoveCount;
    CurrentFile >> ObjectCount;

    currentGame -> CurrentMove = 0;
    currentGame -> MaxMoves = MoveCount;
    currentGame -> MoveLayers = MakeDynamicArray<Layer>(&WorkspaceGame, MoveCount);
    PushBack(&currentGame -> MoveLayers, {});
    currentGame -> MoveLayers[0].BackgroundLayer = MakeDynamicArray<Block>(&WorkspaceGame, MapWidth*MapHeight);
    currentGame -> MoveLayers[0].UpperLayer = MakeDynamicArray<Block>(&WorkspaceGame, ObjectCount);
    currentGame -> CurrentPlayer = MakeDynamicArray<Player>(&WorkspaceGame, MoveCount);

    for(int y = 0; y < MapHeight; y++){
        for(int x = 0; x < MapWidth; x++){
            CurrentFile >> TempEnum;
            if(TempEnum == 7){
                PushBack(&currentGame -> CurrentPlayer, {{x,y}});
            }
            PushBack(&currentGame -> MoveLayers[0].BackgroundLayer, {});
            currentGame -> MoveLayers[0].BackgroundLayer[y*MapWidth + x].type = static_cast<BlockType>(TempEnum);
            currentGame -> MoveLayers[0].BackgroundLayer[y*MapWidth + x].position = {x, y};
        }
    }
    for(int i = 0; i < ObjectCount; i++){
        
        PushBack(&currentGame -> MoveLayers[0].UpperLayer, {});
        CurrentFile >> currentGame -> MoveLayers[0].UpperLayer[i].position.x;
        CurrentFile >> currentGame -> MoveLayers[0].UpperLayer[i].position.y;
        CurrentFile >> TempEnum;
        currentGame -> MoveLayers[0].UpperLayer[i].type = static_cast<BlockType>(TempEnum);
    }

    CurrentFile.close();
    LoadSoundClip("data/sfx/Colorful-Flowers.wav", &songFile);
}

void DrawWorldBlock(int x, int y, BlockType b){
    if(b == 0){
        for(int i = 0; i < currentGame -> CurrentTextures.Wall.count; i++){
            //Print("%i %i %f, %f %f", currentGame -> CurrentTextures.Wall[i].position.x + x*16,currentGame -> CurrentTextures.Wall[i].position.y + y*16, currentGame -> CurrentTextures.Wall[i].color.r, currentGame -> CurrentTextures.Wall[i].color.g, currentGame -> CurrentTextures.Wall[i].color.b);
            SetTileColor(currentGame -> CurrentTextures.Wall[i].position.x + x*16,currentGame -> CurrentTextures.Wall[i].position.y + y*16, currentGame -> CurrentTextures.Wall[i].color.r, currentGame -> CurrentTextures.Wall[i].color.g, currentGame -> CurrentTextures.Wall[i].color.b);
        }
        return;
    }
    if(b == 1 || b == 7){
        for(int i = 0; i < currentGame -> CurrentTextures.Sand.count; i++){
            SetTileColor(currentGame -> CurrentTextures.Sand[i].position.x + x*16,currentGame -> CurrentTextures.Sand[i].position.y + y*16, currentGame -> CurrentTextures.Sand[i].color.r, currentGame -> CurrentTextures.Sand[i].color.g, currentGame -> CurrentTextures.Sand[i].color.b);
        }
        return;
    }
    if(b == 2){
        for(int i = 0; i < currentGame -> CurrentTextures.Door.count; i++){
            //Print("%i %i %f, %f %f", currentGame -> CurrentTextures.Door[i].position.x + x*16,currentGame -> CurrentTextures.Door[i].position.y + y*16, currentGame -> CurrentTextures.Door[i].color.r, currentGame -> CurrentTextures.Door[i].color.g, currentGame -> CurrentTextures.Door[i].color.b);
            SetTileColor(currentGame -> CurrentTextures.Door[i].position.x + x*16,currentGame -> CurrentTextures.Door[i].position.y + y*16, currentGame -> CurrentTextures.Door[i].color.r, currentGame -> CurrentTextures.Door[i].color.g, currentGame -> CurrentTextures.Door[i].color.b);
        }
        return;
    }
    if(b == 4 || b == FAKE_CRATE){
        for(int i = 0; i < currentGame -> CurrentTextures.Box.count; i++){
            //Print("%i %i %f, %f %f", currentGame -> CurrentTextures.Box[i].position.x + x*16,currentGame -> CurrentTextures.Box[i].position.y + y*16, currentGame -> CurrentTextures.Box[i].color.r, currentGame -> CurrentTextures.Box[i].color.g, currentGame -> CurrentTextures.Box[i].color.b);
            if(TypeAtBackground(x,y)==BUTTON){
                SetTileColor(currentGame -> CurrentTextures.Box[i].position.x + x*16,currentGame -> CurrentTextures.Box[i].position.y + y*16, {currentGame -> CurrentTextures.Box[i].color.r, currentGame -> CurrentTextures.Box[i].color.g, currentGame -> CurrentTextures.Box[i].color.b, 0.5f});
            }else{
                SetTileColor(currentGame -> CurrentTextures.Box[i].position.x + x*16,currentGame -> CurrentTextures.Box[i].position.y + y*16, currentGame -> CurrentTextures.Box[i].color.r, currentGame -> CurrentTextures.Box[i].color.g, currentGame -> CurrentTextures.Box[i].color.b);
            }
        }
        return;
    }
    if(b == 5){
        for(int i = 0; i < currentGame -> CurrentTextures.Button.count; i++){
            //Print("%i %i %f, %f %f", currentGame -> CurrentTextures.Box[i].position.x + x*16,currentGame -> CurrentTextures.Box[i].position.y + y*16, currentGame -> CurrentTextures.Box[i].color.r, currentGame -> CurrentTextures.Box[i].color.g, currentGame -> CurrentTextures.Box[i].color.b);
            SetTileColor(currentGame -> CurrentTextures.Button[i].position.x + x*16,currentGame -> CurrentTextures.Button[i].position.y + y*16, currentGame -> CurrentTextures.Button[i].color.r, currentGame -> CurrentTextures.Button[i].color.g, currentGame -> CurrentTextures.Button[i].color.b);
        }
        return;
    }
    if(b == PLAYER){
        for(int i = 0; i < currentGame -> CurrentTextures.PlayTX.count; i++){
            //Print("%i %i %f, %f %f", currentGame -> CurrentTextures.Box[i].position.x + x*16,currentGame -> CurrentTextures.Box[i].position.y + y*16, currentGame -> CurrentTextures.Box[i].color.r, currentGame -> CurrentTextures.Box[i].color.g, currentGame -> CurrentTextures.Box[i].color.b);
            SetTileColor(currentGame -> CurrentTextures.PlayTX[i].position.x + x*16,currentGame -> CurrentTextures.PlayTX[i].position.y + y*16, currentGame -> CurrentTextures.PlayTX[i].color.r, currentGame -> CurrentTextures.PlayTX[i].color.g, currentGame -> CurrentTextures.PlayTX[i].color.b);
        }
        return;
    }
    /*DynamicArray<Pixel> BluePotion;
    DynamicArray<Pixel> PurplePotion;*/
    if(b == BLUE_POTION){
        for(int i = 0; i < currentGame -> CurrentTextures.BluePotion.count; i++){
            //Print("%i %i %f, %f %f", currentGame -> CurrentTextures.Box[i].position.x + x*16,currentGame -> CurrentTextures.Box[i].position.y + y*16, currentGame -> CurrentTextures.Box[i].color.r, currentGame -> CurrentTextures.Box[i].color.g, currentGame -> CurrentTextures.Box[i].color.b);
            SetTileColor(currentGame -> CurrentTextures.BluePotion[i].position.x + x*16,currentGame -> CurrentTextures.BluePotion[i].position.y + y*16, currentGame -> CurrentTextures.BluePotion[i].color.r, currentGame -> CurrentTextures.BluePotion[i].color.g, currentGame -> CurrentTextures.BluePotion[i].color.b);
        }
        return;
    }
    if(b == PURPLE_POTION){
        for(int i = 0; i < currentGame -> CurrentTextures.PurplePotion.count; i++){
            //Print("%i %i %f, %f %f", currentGame -> CurrentTextures.Box[i].position.x + x*16,currentGame -> CurrentTextures.Box[i].position.y + y*16, currentGame -> CurrentTextures.Box[i].color.r, currentGame -> CurrentTextures.Box[i].color.g, currentGame -> CurrentTextures.Box[i].color.b);
            SetTileColor(currentGame -> CurrentTextures.PurplePotion[i].position.x + x*16,currentGame -> CurrentTextures.PurplePotion[i].position.y + y*16, currentGame -> CurrentTextures.PurplePotion[i].color.r, currentGame -> CurrentTextures.PurplePotion[i].color.g, currentGame -> CurrentTextures.PurplePotion[i].color.b);
        }
        return;
    }
}

void DrawGameObjects(){
    DrawTextTile({WIDTH/4, -HEIGHT/32},4.0f, {1.0f,1.0f,1.0f}, true, "Level: %i", currentGame -> Level);
    DrawTextTile({3*WIDTH/4, -HEIGHT/32},4.0f, {1.0f,1.0f,1.0f}, true, "Steps Left: %i", currentGame -> MaxMoves - currentGame -> CurrentMove);
    for(int blockIndex = 0; blockIndex < currentGame -> MoveLayers[currentGame -> CurrentMove].BackgroundLayer.count; blockIndex++){
        DrawWorldBlock(
            currentGame -> MoveLayers[currentGame -> CurrentMove].BackgroundLayer[blockIndex].position.x,
            currentGame -> MoveLayers[currentGame -> CurrentMove].BackgroundLayer[blockIndex].position.y,
            currentGame -> MoveLayers[currentGame -> CurrentMove].BackgroundLayer[blockIndex].type);
    }

    for(int blockIndex = 0; blockIndex < currentGame -> MoveLayers[currentGame -> CurrentMove].UpperLayer.count; blockIndex++){
        DrawWorldBlock(
            currentGame -> MoveLayers[currentGame -> CurrentMove].UpperLayer[blockIndex].position.x,
            currentGame -> MoveLayers[currentGame -> CurrentMove].UpperLayer[blockIndex].position.y,
            currentGame -> MoveLayers[currentGame -> CurrentMove].UpperLayer[blockIndex].type);
    }
    DrawWorldBlock(
            currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x,
            currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y,
            PLAYER);
}

void CopyLayerToNext(){
    PushBack(&currentGame -> MoveLayers, {});
    currentGame -> MoveLayers[currentGame->CurrentMove+1].BackgroundLayer = MakeDynamicArray<Block>(&WorkspaceGame, currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer.count);
    currentGame -> MoveLayers[currentGame->CurrentMove+1].UpperLayer = MakeDynamicArray<Block>(&WorkspaceGame, currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer.count);
    for(int i = 0; i < currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer.count; i++){
        //currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer[i]
        PushBack(&currentGame -> MoveLayers[currentGame->CurrentMove+1].BackgroundLayer,currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer[i]);

    }
    for(int i = 0; i < currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer.count; i++){
        PushBack(&currentGame -> MoveLayers[currentGame->CurrentMove+1].UpperLayer,currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer[i]);
    }
}

void MoveCrate(int x, int y, int dir){
    for(int i = 0; i < currentGame -> MoveLayers[currentGame->CurrentMove+1].UpperLayer.count; i++){
        if(currentGame -> MoveLayers[currentGame->CurrentMove +1].UpperLayer[i].position.x == x && currentGame -> MoveLayers[currentGame->CurrentMove +1].UpperLayer[i].position.y == y){
            if(dir == 1){
                currentGame -> MoveLayers[currentGame->CurrentMove +1].UpperLayer[i].position.y--;
            }else if(dir == 2){
                currentGame -> MoveLayers[currentGame->CurrentMove +1].UpperLayer[i].position.x++;
            }else if(dir == 3){
                currentGame -> MoveLayers[currentGame->CurrentMove +1].UpperLayer[i].position.y++;
            }else if(dir == 4){
                currentGame -> MoveLayers[currentGame->CurrentMove +1].UpperLayer[i].position.x--;
            }
            break;
        }
    }
}

void PlayerMovement(int direction){
    bool tempBool;
    bool wallBool;
    bool crateBool;
    if(direction == 1){
        tempBool = TypeAtBackground(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y-2) != WALL && TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y-2) != CRATES && TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y-1) == CRATES;
        wallBool = TypeAtBackground(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y-1) != WALL;
        crateBool = TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y-1) != CRATES;
        if(wallBool
        || (tempBool)){
            CopyLayerToNext();
            if(tempBool){
                PushBack(&currentGame -> CurrentPlayer, currentGame -> CurrentPlayer[currentGame -> CurrentMove]);
                MoveCrate(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y-1, 1);
                currentGame -> CurrentPlayer[currentGame -> CurrentMove+1].position.y--;
                currentGame->CurrentMove++;
            }else if(!tempBool
            && wallBool
            && crateBool){
                PushBack(&currentGame -> CurrentPlayer, currentGame -> CurrentPlayer[currentGame -> CurrentMove]);
                currentGame -> CurrentPlayer[currentGame -> CurrentMove+1].position.y--;
                currentGame->CurrentMove++;
            }
            return;
        }
        
    }else if(direction == 2){
        tempBool = TypeAtBackground(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x + 2, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y) != WALL && TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x + 2, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y) != CRATES&& TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x + 1, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y) == CRATES;
        wallBool = TypeAtBackground(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x + 1, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y) != WALL;
        crateBool = TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x + 1, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y) != CRATES;
        if(wallBool
        || (tempBool)){
            CopyLayerToNext();
            if(tempBool){
                PushBack(&currentGame -> CurrentPlayer, currentGame -> CurrentPlayer[currentGame -> CurrentMove]);
                MoveCrate(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x+1, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y, 2);
                currentGame -> CurrentPlayer[currentGame -> CurrentMove+1].position.x++;
                currentGame->CurrentMove++;
            }else if(!tempBool
            && wallBool
            && crateBool){
                PushBack(&currentGame -> CurrentPlayer, currentGame -> CurrentPlayer[currentGame -> CurrentMove]);
                currentGame -> CurrentPlayer[currentGame -> CurrentMove+1].position.x++;
                currentGame->CurrentMove++;
            }
            return;
        }
    }else if(direction == 3){
        tempBool = TypeAtBackground(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y+2) != WALL && TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y+2) != CRATES&& TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y+1) == CRATES;
        wallBool = TypeAtBackground(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y+1) != WALL;
        crateBool = TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y+1) != CRATES;
        if(wallBool
        || (tempBool)){
            CopyLayerToNext();
            if(tempBool){
                PushBack(&currentGame -> CurrentPlayer, currentGame -> CurrentPlayer[currentGame -> CurrentMove]);
                MoveCrate(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y+1, 3);
                currentGame -> CurrentPlayer[currentGame -> CurrentMove+1].position.y++;
                currentGame->CurrentMove++;
            }else if(!tempBool
            && wallBool
            && crateBool){
                PushBack(&currentGame -> CurrentPlayer, currentGame -> CurrentPlayer[currentGame -> CurrentMove]);
                currentGame -> CurrentPlayer[currentGame -> CurrentMove+1].position.y++;
                currentGame->CurrentMove++;
            }
            return;
        }
    }else if(direction == 4){
        tempBool = TypeAtBackground(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x - 2, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y) != WALL && TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x - 2, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y) != CRATES&& TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x - 1, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y) == CRATES;
        wallBool = TypeAtBackground(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x - 1, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y) != WALL;
        crateBool = TypeAtUpper(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x - 1, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y) != CRATES;
        if(wallBool
        || (tempBool)){
            CopyLayerToNext();
            if(tempBool){
                PushBack(&currentGame -> CurrentPlayer, currentGame -> CurrentPlayer[currentGame -> CurrentMove]);
                MoveCrate(currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.x-1, currentGame -> CurrentPlayer[currentGame -> CurrentMove].position.y, 4);
                currentGame -> CurrentPlayer[currentGame -> CurrentMove+1].position.x--;
                currentGame->CurrentMove++;
            } else if (!tempBool
            && wallBool
            && crateBool){
                PushBack(&currentGame -> CurrentPlayer, currentGame -> CurrentPlayer[currentGame -> CurrentMove]);
                currentGame -> CurrentPlayer[currentGame -> CurrentMove+1].position.x--;
                currentGame->CurrentMove++;
            }
            return;
        }
    }
    Print("Invalid Move");
}

void CheckWinOrLost(){
    bool win = true;
    for(int firstCheck = 0; firstCheck < currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer.count; firstCheck++){
        if(currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer[firstCheck].type != 5){
            continue;
        }
        bool tempWin = false;
        for(int secondCheck = 0; secondCheck < currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer.count; secondCheck++){
            if(currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer[firstCheck].position.x == currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer[secondCheck].position.x &&
            currentGame -> MoveLayers[currentGame->CurrentMove].BackgroundLayer[firstCheck].position.y == currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer[secondCheck].position.y){
                tempWin = true;
                break;
            }
        }
        if(!tempWin){
            win = false;
            continue;
        }
    }
    if(TypeAtBackground(currentGame->CurrentPlayer[currentGame -> CurrentMove].position.x,currentGame->CurrentPlayer[currentGame -> CurrentMove].position.y) == DOOR && win){
        currentGame->LevelPassed = win;
    }

    if(currentGame -> CurrentMove > currentGame -> MaxMoves){
        currentGame->LevelLost = true;
    }
}

void BackMovement(){
    if(currentGame -> CurrentMove < 1){
        return;
    }
    DeallocateDynamicArray(&currentGame -> MoveLayers[currentGame -> CurrentMove].BackgroundLayer);
    DeallocateDynamicArray(&currentGame -> MoveLayers[currentGame -> CurrentMove].UpperLayer);
    PopBack(&currentGame -> MoveLayers);
    PopBack(&currentGame -> CurrentPlayer);
    currentGame -> CurrentMove = currentGame -> CurrentMove--;
}

void HandleGameMechanics(){
    if(InputPressed(Keyboard, Input_UpArrow)){
        PlayerMovement(1);
        CheckWinOrLost();
    }
    if(InputPressed(Keyboard, Input_RightArrow)){
        PlayerMovement(2);
        CheckWinOrLost();
    }
    if(InputPressed(Keyboard, Input_DownArrow)){
        PlayerMovement(3);
        CheckWinOrLost();
    }
    if(InputPressed(Keyboard, Input_LeftArrow)){
        PlayerMovement(4);
        CheckWinOrLost();
    }
    if(InputPressed(Keyboard, Input_V)){
        currentGame -> LevelRestart = true;
    }
    if(InputPressed(Keyboard, Input_Z)){
        BackMovement();
    }
    if(InputPressed(Keyboard, Input_K)){
        currentGame->LevelPassed = true;
    }
}

void LoadRestart(){
    for(int LayerCount = currentGame -> CurrentMove; LayerCount >= 1; LayerCount--){
        DeallocateDynamicArray(&currentGame -> MoveLayers[LayerCount].BackgroundLayer);
        DeallocateDynamicArray(&currentGame -> MoveLayers[LayerCount].UpperLayer);
        PopBack(&currentGame -> MoveLayers);
    }
    for(int PlayerCount = 0; PlayerCount < currentGame -> CurrentMove; PlayerCount++){
        PopBack(&currentGame -> CurrentPlayer);
    }
    currentGame -> CurrentMove = 0;
    currentGame -> LevelRestart = false;
}

void ClearPastLevel(){
    for(int LayerCount = currentGame -> CurrentMove-1; LayerCount >= 0; LayerCount--){
        DeallocateDynamicArray(&currentGame -> MoveLayers[LayerCount].BackgroundLayer);
        DeallocateDynamicArray(&currentGame -> MoveLayers[LayerCount].UpperLayer);
        PopBack(&currentGame -> MoveLayers);
    }
    DeallocateDynamicArray(&currentGame -> MoveLayers);
    for(int PlayerCount = 0; PlayerCount < currentGame -> CurrentMove; PlayerCount++){
        PopBack(&currentGame -> CurrentPlayer);
    }
    DeallocateDynamicArray(&currentGame -> CurrentPlayer);
}

void DeleteObjectInFront(int x, int y, BlockType b){
    for(int i = 0; i < currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer.count; i++){
        if(currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer[i].position.x == x && currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer[i].position.y == y && currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer[i].type == b){
            RemoveAtIndex(&currentGame -> MoveLayers[currentGame->CurrentMove].UpperLayer, i);
        }
    }
}

void HandleMiscMechanics(){
    if(TypeAtUpper(currentGame -> CurrentPlayer[currentGame->CurrentMove].position.x , currentGame -> CurrentPlayer[currentGame->CurrentMove].position.y) == BLUE_POTION){
        currentGame -> MaxMoves += 10;
        DeleteObjectInFront(currentGame -> CurrentPlayer[currentGame->CurrentMove].position.x , currentGame -> CurrentPlayer[currentGame->CurrentMove].position.y, BLUE_POTION);
    }
    if(TypeAtUpper(currentGame -> CurrentPlayer[currentGame->CurrentMove].position.x , currentGame -> CurrentPlayer[currentGame->CurrentMove].position.y) == PURPLE_POTION){
        int tempPot = RandiRange(1,3);
        if(tempPot == 1){
            currentGame -> LevelPassed = true;
        }else if(tempPot == 2){
            currentGame -> LevelLost = true;
        }else if(tempPot == 3){
            currentGame -> MaxMoves += 10;
        }
        DeleteObjectInFront(currentGame -> CurrentPlayer[currentGame->CurrentMove].position.x , currentGame -> CurrentPlayer[currentGame->CurrentMove].position.y, PURPLE_POTION);
    }
    if(TypeAtUpper(currentGame -> CurrentPlayer[currentGame->CurrentMove].position.x , currentGame -> CurrentPlayer[currentGame->CurrentMove].position.y) == FAKE_CRATE){
        currentGame -> MaxMoves -= 1;
        DeleteObjectInFront(currentGame -> CurrentPlayer[currentGame->CurrentMove].position.x , currentGame -> CurrentPlayer[currentGame->CurrentMove].position.y, FAKE_CRATE);
    }
}

void LoadNextLevel(){
    ClearPastLevel();

    currentGame -> Level++;
    
    currentGame -> LevelPassed = false;

    std::fstream CurrentFile;
    int MapWidth;
    int MapHeight;
    int MoveCount;
    int ObjectCount;

    int TempEnum;

    std::vector<std::string> LevelFiles = {"data/map_levels/level_0.dat","data/map_levels/level_1.dat", "data/map_levels/level_2.dat", "data/map_levels/level_3.dat", "data/map_levels/level_4.dat", "data/map_levels/level_5.dat"};

    CurrentFile.open(LevelFiles.at(currentGame -> Level));
    
    CurrentFile >> MapWidth;
    CurrentFile >> MapHeight;
    CurrentFile >> MoveCount;
    CurrentFile >> ObjectCount;
    
    currentGame -> CurrentMove = 0;
    currentGame -> MaxMoves = MoveCount;
    currentGame -> MoveLayers = MakeDynamicArray<Layer>(&WorkspaceGame, MoveCount);
    PushBack(&currentGame -> MoveLayers, {});
    currentGame -> MoveLayers[0].BackgroundLayer = MakeDynamicArray<Block>(&WorkspaceGame, MapWidth*MapHeight);
    currentGame -> MoveLayers[0].UpperLayer = MakeDynamicArray<Block>(&WorkspaceGame, ObjectCount);
    currentGame -> CurrentPlayer = MakeDynamicArray<Player>(&WorkspaceGame, MoveCount);
    for(int y = 0; y < MapHeight; y++){
        for(int x = 0; x < MapWidth; x++){
            CurrentFile >> TempEnum;
            if(TempEnum == 7){
                PushBack(&currentGame -> CurrentPlayer, {{x,y}});
            }
            PushBack(&currentGame -> MoveLayers[0].BackgroundLayer, {});
            currentGame -> MoveLayers[0].BackgroundLayer[y*MapWidth + x].type = static_cast<BlockType>(TempEnum);
            currentGame -> MoveLayers[0].BackgroundLayer[y*MapWidth + x].position = {x, y};
        }
    }
    for(int i = 0; i < ObjectCount; i++){
        Print("%i", i);
        PushBack(&currentGame -> MoveLayers[0].UpperLayer, {});
        CurrentFile >> currentGame -> MoveLayers[0].UpperLayer[i].position.x;
        CurrentFile >> currentGame -> MoveLayers[0].UpperLayer[i].position.y;
        CurrentFile >> TempEnum;
        currentGame -> MoveLayers[0].UpperLayer[i].type = static_cast<BlockType>(TempEnum);
        Print("%i %i %i", currentGame -> MoveLayers[0].UpperLayer[i].position.x, currentGame -> MoveLayers[0].UpperLayer[i].position.y, TempEnum);
    }

    CurrentFile.close();
}

void FinishTheGame(){
    for(int x = 0; x < WIDTH; x++){
        SetTileColor(x, 0, 1.0f,1.0f,1.0f);
        SetTileColor(x, HEIGHT-1, 1.0f,1.0f,1.0f);
    }
    for(int y = 0; y < HEIGHT; y++){
        SetTileColor(0, y, 1.0f,1.0f,1.0f);
        SetTileColor(WIDTH-1, y, 1.0f,1.0f,1.0f);
    }
    DrawTextTile({WIDTH/2, HEIGHT/2},8.0f, {1.0f,1.0f,1.0f}, true, "You won!!!! Congrats!");
}

void MyMosaicInit() {
    SetMosaicGridSize(WIDTH, HEIGHT);
    LoadGameVariables();
    LoadTextures();
    LoadFirstLevel();
}

void MyMosaicUpdate() {
    ClearTiles(0, 0, 0);

    if(songHan.generation == 0){
        songHan = PlaySound(&Game->audioPlayer, songFile, 0.25f, true);
    }
    Sound *sound = GetSound(&Game->audioPlayer, songHan);

    if(!currentGame -> LevelRestart && !currentGame->LevelPassed && !currentGame->LevelLost && !currentGame -> GameWon)
    DrawGameObjects();
    HandleGameMechanics();
    HandleMiscMechanics();
    if(currentGame -> LevelRestart){
        LoadRestart();
    }
    if(currentGame->LevelPassed){
        if(currentGame -> Level < 5){
            LoadNextLevel();
        }else{
            currentGame -> GameWon = true;
            currentGame -> LevelPassed = false;
        }
        
    }
    if(currentGame->LevelLost){
        LoadRestart();
        currentGame->LevelLost = false;
    }
    if(currentGame -> GameWon){
        FinishTheGame();
    }
}