#define _USE_MATH_DEFINES

#include <math.h>

int modeNum = 1;

struct object{
    double centerX;
    double centerY;

    double red;
    double green;
    double blue;

    double time;
    bool specialBool = false;
};

object mode1Block = {
    100.0f,100.0f,1.0f,1.0f,1.0f,0.0f,false
};

void mode1(){
    //  physics

    mode1Block.time += DeltaTime*2;

    //  graphics

    for(double xPixel = (50*cos(mode1Block.time)+mode1Block.centerX)-2; xPixel <= (50*cos(mode1Block.time)+mode1Block.centerX)+2; xPixel++){
        for(double yPixel = (50*sin(mode1Block.time)+mode1Block.centerY)-2; yPixel <= (50*sin(mode1Block.time)+mode1Block.centerY)+2; yPixel++){
            SetTileColor(xPixel, yPixel, mode1Block.red, mode1Block.green, mode1Block.blue);
        }
    }

}

object mode2Block = {
    100.0f,100.0f,1.0f,0.0f,0.0f,0.0f,true
};

void mode2(){
    //  physics

    mode2Block.time += DeltaTime*2;
    mode2Block.specialBool = (fmod(mode2Block.time,(4*M_PI)) > 2*M_PI) ? false : true;

    //  graphics

    if(mode2Block.specialBool){
        for(double xPixel = (50*cos(mode2Block.time+M_PI)+mode2Block.centerX+50)-2; xPixel <= (50*cos(mode2Block.time+M_PI)+mode2Block.centerX+50)+2; xPixel++){
            for(double yPixel = (50*sin(mode2Block.time+M_PI)+mode2Block.centerY)-2; yPixel <= (50*sin(mode2Block.time+M_PI)+mode2Block.centerY)+2; yPixel++){
                SetTileColor(xPixel, yPixel, mode2Block.red, mode2Block.green, mode2Block.blue);
            }
        }
    }else{
        for(double xPixel = (50*cos(mode2Block.time)+mode2Block.centerX-50)-2; xPixel <= (50*cos(mode2Block.time)+mode2Block.centerX-50)+2; xPixel++){
            for(double yPixel = (50*sin(mode2Block.time)+mode2Block.centerY)-2; yPixel <= (50*sin(mode2Block.time)+mode2Block.centerY)+2; yPixel++){
                SetTileColor(xPixel, yPixel, mode2Block.red, mode2Block.green, mode2Block.blue);
            }
        }
    }
    
}

object mode3Block = {
    100.0f,100.0f,1.0f,1.0f,0.0f,0.0f,true
};
double temp3Y = 0;
void mode3(){
    //  physics

    mode3Block.specialBool = (fmod(mode3Block.time,(100*M_PI)) > 50*M_PI) ? true : false;
    
    mode3Block.time += DeltaTime*(10*M_PI);
    temp3Y = fmod(mode3Block.time,50*M_PI) - (25*M_PI);
    
    //  graphics
    if(mode3Block.specialBool){
        for(double xPixel = (20*cos((temp3Y)/10)+mode3Block.centerX)-2; xPixel <= (20*cos((temp3Y)/10)+mode3Block.centerX)+2; xPixel++){
            for(double yPixel = (temp3Y + mode3Block.centerY)-2; yPixel <= (temp3Y + mode3Block.centerY)+2; yPixel++){
                SetTileColor(xPixel, yPixel, mode3Block.red, mode3Block.green, mode3Block.blue);
            }
        }
    }else{
        for(double xPixel = (-20*cos((temp3Y)/10)+mode3Block.centerX)-2; xPixel <= (-20*cos((temp3Y)/10)+mode3Block.centerX)+2; xPixel++){
            for(double yPixel = (mode3Block.centerY - temp3Y)-2; yPixel <= (mode3Block.centerY - temp3Y)+2; yPixel++){
                SetTileColor(xPixel, yPixel, mode3Block.red, mode3Block.green, mode3Block.blue);
            }
        }
    }

}
object mode4Block = {
    100.0f,100.0f,0.0f,1.0f,0.0f,0.0f,true
};
double temp4X = 0;
void mode4(){
    mode4Block.specialBool = (fmod(mode4Block.time,(80*M_PI)) > 40*M_PI) ? true : false;
    
    mode4Block.time += DeltaTime*(10*M_PI);
    temp4X = fmod(mode4Block.time,40*M_PI) - (20*M_PI);
    
    //  graphics
    if(mode4Block.specialBool){
        for(double xPixel = (temp4X+mode4Block.centerX)-2; xPixel <= (temp4X+mode4Block.centerX)+2; xPixel++){
            for(double yPixel = (-40*sin((temp4X)/10)+mode4Block.centerY)-2; yPixel <= (-40*sin((temp4X)/10)+mode4Block.centerY)+2; yPixel++){
                SetTileColor(xPixel, yPixel, mode4Block.red, mode4Block.green, mode4Block.blue);
            }
        }
    }else{
        for(double xPixel = (mode4Block.centerX-temp4X)-2; xPixel <= (mode4Block.centerX-temp4X)+2; xPixel++){
            for(double yPixel = (10*sin((temp4X)/10)+mode4Block.centerY)-2; yPixel <= (10*sin((temp4X)/10)+mode4Block.centerY)+2; yPixel++){
                SetTileColor(xPixel, yPixel, mode4Block.red, mode4Block.green, mode4Block.blue);
            }
        }
    }
}

void MyMosaicInit() {
    SetMosaicGridSize(200, 200);
}

void MyMosaicUpdate() {
    ClearTiles(0, 0, 0);

    if (InputPressed(Keyboard, Input_Space)) {
        modeNum = (modeNum >= 1 && modeNum <= 3) ? modeNum + 1 : 1;
    }

    switch (modeNum)
    {
    case 1:
        mode1();
        break;
    case 2:
        mode2();
        break;
    case 3:
        mode3();
        break;
    case 4:
        mode4();
        break;
    default:
        Print("error");
        break;
    }
    //SetTileColor(0, 0, 0.8f, 0.2f, 0.4f);
}

