

struct TextGame {
    
};

struct Room {
    
};

struct Object {
    
};

TextAdventure textGame = {};

MyGameUpdate() {
    
}
