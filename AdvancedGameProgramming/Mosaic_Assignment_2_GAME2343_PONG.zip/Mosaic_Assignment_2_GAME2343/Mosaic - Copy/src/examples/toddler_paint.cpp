
const int32 Width = 64;
const int32 Height = 64;

struct Bead {
    //vec2 position;
    vec4 color;
};

Bead beads[Width * Height];

const float32 CursorMoveSpeed = 0.02f;

struct Cursor {
    int32 x;
    int32 y;

    int32 xDirection;
    int32 yDirection;

    real32 radius;
    // maybe we want to do a width/height instead

    vec4 color;
    
    float32 moveTimer;
};

Cursor cursor = {};

void RandomizeColors() {
    for (int y = 0; y < Height; y++) {
        for (int x = 0; x < Width; x++) {
            int32 index = (y * Width) + x;
            Bead b = beads[index];
            b.color.r = RandfRange(0.0f, 1.0f);
            b.color.g = RandfRange(0.0f, 1.0f);
            b.color.b = RandfRange(0.0f, 1.0f);
            b.color.a = 1;

            beads[index] = b;
        }
    }
}

void RandomizeBWColors() {
    for (int y = 0; y < Height; y++) {
        for (int x = 0; x < Width; x++) {
            int32 index = (y * Width) + x;
            Bead b = beads[index];
            b.color.r = RandfRange(0.0f, 1.0f);
            b.color.g = b.color.r;
            b.color.b = b.color.r;
            b.color.a = 1;

            beads[index] = b;
        }
    }
}

// Stripes of color and gradients are cool because as we go from one side to the other we pick up some color and bring it over
// along the gradient.

void GenerateBWWave() {
    for (int y = 0; y < Height; y++) {
        for (int x = 0; x < Width; x++) {
            int32 index = (y * Width) + x;

            real32 s = (1 + sinf((x * 0.5f) + (y * 0.2f))) * 0.5f;
            
            Bead b = beads[index];
            b.color.r = s;
            b.color.g = s;
            b.color.b = s;
            
            beads[index] = b;
        }
    }
}

void GenerateUVGradient() {
    for (int y = 0; y < Height; y++) {
        for (int x = 0; x < Width; x++) {
            int32 index = (y * Width) + x;
            
            Bead b = beads[index];
            b.color.r = Lerp(0, 1, x / (Width * 1.0f));
            b.color.g = Lerp(0, 1, y / (Height * 1.0f));
            b.color.b = 0;
            
            beads[index] = b;
        }
    }
}

void GenerateUVWave() {
    for (int y = 0; y < Height; y++) {
        for (int x = 0; x < Width; x++) {
            int32 index = (y * Width) + x;

            real32 r = (1 + sinf((x * 0.5f))) * 0.5f;
            real32 g = (1 + sinf((y * 0.2f))) * 0.5f;
            
            Bead b = beads[index];
            b.color.r = r;
            b.color.g = g;
            b.color.b = 0;
            
            beads[index] = b;
        }
    }
}

void MyMosaicInit() {
    SetMosaicGridSize(Width, Height);

    GenerateUVGradient();

    cursor.xDirection = 1;
    cursor.color = V4(1, 0, 0, 1);
    cursor.radius = 1.0f;

    // @TODO: try seeding with different values
    //SeedRand(12345);
}

void Render() {
    for (int y = 0; y < Height; y++) {
        for (int x = 0; x < Width; x++) {
            Bead b = beads[(y * Width) + x];
            SetTileColor(x, y, b.color.r, b.color.g, b.color.b);
        }
    }

    SetTileColor(cursor.x, cursor.y, cursor.color.r, cursor.color.g, cursor.color.b);

    // for (int y = -1; y <= 1; y++) {
    //     for (int x = -1; x <= 1; x++) {
    //         if (x == 0 && y == 0) { continue; }
            
    //         SetTileColor(cursor.x + x, cursor.y + y, 0, 0, 0);
    //     }
    // }
    
    // lets try drawing this as more of a cursor
    // SetTileColor(cursor.x + 1, cursor.y + 1, 1, 1, 1);
    // SetTileColor(cursor.x + 2, cursor.y + 1, 1, 1, 1);
    // SetTileColor(cursor.x + 1, cursor.y + 2, 1, 1, 1);
}

void MyMosaicUpdate() {

    cursor.moveTimer += DeltaTime;

    cursor.radius = 1.5f + (((1 + sinf(Time * 0.5f)) * 0.5f) * 4);

    if (cursor.moveTimer >= CursorMoveSpeed) {
        cursor.x += cursor.xDirection;

        if (cursor.x >= Width) {
            cursor.xDirection *= -1;
            
            cursor.x = Width - 1;
            cursor.y++;

            if (cursor.y >= Height) {
                cursor.y = 0;
            }
        }

        if (cursor.x < 0) {
            cursor.xDirection *= -1;
            
            cursor.x = 0;
            cursor.y++;

            if (cursor.y >= Height) {
                cursor.y = 0;
            }
        }

        cursor.moveTimer -= CursorMoveSpeed;

        // check the bead under us and bring some of that color into our cursor

        int32 index = (cursor.y * Width) + cursor.x;
        Bead bead = beads[index];

        cursor.color = Lerp(cursor.color, bead.color, 0.2f);
    }

    if (InputHeld(Keyboard, Input_Space)) {
        // int32 index = (cursor.y * Width) + cursor.x;
        // Bead bead = beads[index];
        // bead.color = cursor.color;

        vec2 cursorCenter = V2(cursor.x + 0.5f, cursor.y + 0.5f);

        int32 halfSize = cursor.radius;
        for (int y = -halfSize; y <= halfSize; y++) {
            for (int x = -halfSize; x <= halfSize; x++) {
                if (cursor.y + y < 0 || cursor.y + y >= Height) {
                    continue;
                }
                if (cursor.x + x < 0 || cursor.x + x >= Width) {
                    continue;
                }
                
                int32 index = ((cursor.y + y) * Width) + (cursor.x + x);

                vec2 beadCenter = V2((cursor.x + x) + 0.5f, (cursor.y + y) + 0.5f);

                if (Distance(beadCenter, cursorCenter) <= cursor.radius) {
                    Bead bead = beads[index];
                    bead.color = cursor.color;

                    // @TODO: try lerping between our current color and a modified version

                    bead.color.r += RandfRange(0, 0.02f);
                    bead.color.g += RandfRange(0, 0.02f);
                    bead.color.b += RandfRange(0, 0.02f);

                    beads[index] = bead;
                }
            }
        }
    }

    Render();
}

