
void MyMosaicInit() {
    SetMosaicGridSize(9, 9);
}

void MyMosaicUpdate() {
    SetTileColor(4, 4, 1, 1, 1);
}
