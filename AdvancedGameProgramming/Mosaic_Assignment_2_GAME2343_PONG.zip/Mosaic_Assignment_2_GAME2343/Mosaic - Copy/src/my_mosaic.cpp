#define _USE_MATH_DEFINES

#include <math.h>

const int WIDTH = 125;
const int HEIGHT = 75;

int enemyPoints = 0;
int playerPoints = 0;

bool endOfgame = false;

struct ball
{
    vec2 position;
    vec2 direction;
    real32 magnatude;
    vec3 colors;
};
struct paddle
{
    vec2 position;
    vec2 size;
};

paddle gamePad1 = {{WIDTH-5,(HEIGHT/2)},{2,15}};
paddle gamePad2 = {{5,(HEIGHT/2)},{2,15}};
ball gameBall = {{(WIDTH/2),(HEIGHT/2)},{sqrt(3)/2,0.5},35.0f,{1.0f,1.0f,1.0f}};

void MyMosaicInit() {
    SetMosaicGridSize(WIDTH, HEIGHT);
}

// start of misc functions

/*
gameBall.direction.x = cos(M_PI+(tempYIntercept-gamePad1.position.y)/(gamePad1.size.y/2)*(1.0/3.0)*M_PI);
gameBall.direction.y = -sin(M_PI+(tempYIntercept-gamePad1.position.y)/(gamePad1.size.y/2)*(1.0/3.0)*M_PI);

gameBall.direction.x = cos((tempYIntercept-gamePad2.position.y)/(gamePad2.size.y/2)*(1.0/3.0)*M_PI);
gameBall.direction.y = -sin((tempYIntercept-gamePad2.position.y)/(gamePad2.size.y/2)*(1.0/3.0)*M_PI);
*/
int32 tempRandomBit;
real32 tempRandomRange;
real32 randomXDirection(){
    SeedRand(4561245915);
    tempRandomBit = rand()%2;
    tempRandomRange = static_cast<float>(rand()) / RAND_MAX;
    
    return cos(tempRandomBit*M_PI+(tempRandomRange*(1.0/3.0)*M_PI));
}

real32 randomYDirection(){
    SeedRand(189196478);
    tempRandomBit = rand()%2;
    tempRandomRange = static_cast<float>(rand()) / RAND_MAX;
    
    return -sin(tempRandomBit*M_PI+(tempRandomRange*(1.0/3.0)*M_PI));
}

void checkScore(){
    if(gameBall.position.x < 0){
        playerPoints++;
        gameBall = {{(WIDTH/2),(HEIGHT/2)},{randomXDirection(),randomYDirection()},35.0f,{1.0f,1.0f,1.0f}};
    }else if(gameBall.position.x > WIDTH-1){
        enemyPoints++;
        gameBall = {{(WIDTH/2),(HEIGHT/2)},{randomXDirection(),randomYDirection()},35.0f,{1.0f,1.0f,1.0f}};
    }
}
int tempColorChosen1;
int tempColorChosen2;
void ChangeRandomBallColor(){
    SeedRand((int)(DeltaTime*512));
    tempColorChosen1 = RandiRange(0,3);
    tempColorChosen2 = RandiRange(0,3);

    switch (tempColorChosen1)
    {
    case 0: gameBall.colors.x -= 0.5f; break;
    case 1: gameBall.colors.y -= 0.5f; break;
    case 2: gameBall.colors.z -= 0.5f; break;
    default: break;
    }
    switch (tempColorChosen2)
    {
    case 0: gameBall.colors.x -= 0.5f; break;
    case 1: gameBall.colors.y -= 0.5f; break;
    case 2: gameBall.colors.z -= 0.5f; break;
    default: break;
    }
}
void ChangeBackColor(){
    gameBall.colors.x = (gameBall.colors.x + DeltaTime/2 < 1.0f) ? gameBall.colors.x + DeltaTime/2 : 1.0f;
    gameBall.colors.y = (gameBall.colors.y + DeltaTime/2 < 1.0f) ? gameBall.colors.y + DeltaTime/2 : 1.0f;
    gameBall.colors.z = (gameBall.colors.z + DeltaTime/2 < 1.0f) ? gameBall.colors.z + DeltaTime/2 : 1.0f;
}
void CheckWin(){
    if(enemyPoints>=7){
        endOfgame = true;

        DrawTextTop({1.0f,0.0f,0.0f}, 5.0f , "You Lost :< : Press R to Restart");
    }else if(playerPoints>=7){
        endOfgame = true;

        DrawTextTop({0.0f,1.0f,0.0f}, 5.0f ,"You Win! : Press R to Restart");
    }
}
void restartGame(){
    gamePad1 = {{WIDTH-5,(HEIGHT/2)},{2,15}};
    gamePad2 = {{5,(HEIGHT/2)},{2,15}};
    gameBall = {{(WIDTH/2),(HEIGHT/2)},{randomXDirection(),randomYDirection()},35.0f,{1.0f,1.0f,1.0f}};
    endOfgame = false;
    enemyPoints = 0;
    playerPoints = 0;
}
// end of misc functions


// graphics functions
void DrawPongBorder(){
    for(int yPos = 0; yPos < 1; yPos++){
        for(int xPos = 0; xPos < WIDTH; xPos++){
            SetTileColor(xPos, yPos, 1.0f, 1.0f, 1.0f);
        }
    }
    for(int yPos = HEIGHT-1; yPos < HEIGHT; yPos++){
        for(int xPos = 0; xPos < WIDTH; xPos++){
            SetTileColor(xPos, yPos, 1.0f, 1.0f, 1.0f);
        }
    }
}
void DrawPongSeparator(){
    for(int yBlockLocation = 0; yBlockLocation < HEIGHT; yBlockLocation += 2){
        for(int yPos = 0; yPos < 1; yPos++){
            for(int xPos = (WIDTH/2)-1; xPos <= (WIDTH/2)-1; xPos++){
                SetTileColor(xPos, yBlockLocation+yPos, 1.0f, 1.0f, 1.0f);
            }
        }
    }
}
void DrawPaddles(){
    for(int yPos = gamePad1.position.y-(gamePad1.size.y-1)/2; yPos <= gamePad1.position.y+(gamePad1.size.y-1)/2; yPos++){
        for(int xPos = gamePad1.position.x-(gamePad1.size.x)/2; xPos < gamePad1.position.x+(gamePad1.size.x)/2; xPos++){
            SetTileColor(xPos, yPos, 1.0f, 1.0f, 1.0f);
        }
    }

    for(int yPos = gamePad2.position.y-(gamePad2.size.y-1)/2; yPos <= gamePad2.position.y+(gamePad2.size.y-1)/2; yPos++){
        for(int xPos = gamePad2.position.x-(gamePad2.size.x)/2; xPos < gamePad2.position.x+(gamePad2.size.x)/2; xPos++){
            SetTileColor(xPos, yPos, 1.0f, 1.0f, 1.0f);
        }
    }
}
void DrawBall(){
    SetTileColor(gameBall.position.x, gameBall.position.y, gameBall.colors.x, gameBall.colors.y, gameBall.colors.z);
}
void DrawTallies(){
    for(int enemyTally = 0; enemyTally < enemyPoints; enemyTally++){
        for(int yTallyLength = 0; yTallyLength < 7; yTallyLength++){
            SetTileColor((WIDTH/2)+1 + enemyTally * 2, 2+yTallyLength , 1.0f, 1.0f, 1.0f);
        }
    }

    for(int playerTally = 0; playerTally < playerPoints; playerTally++){
        for(int yTallyLength = 0; yTallyLength < 7; yTallyLength++){
            SetTileColor((WIDTH/2) - 3 - playerTally * 2, 2+yTallyLength , 1.0f, 1.0f, 1.0f);
        }
    }
}
// end of graphics functions

// physics functions
real32 tempSlope;
real32 tempYIntercept;
real32 tempNextXStep;
real32 tempNextYStep;
real32 tempDistFromRightWall;
real32 tempDistFromLeftWall;
real32 tempRightWall = gamePad1.position.x-(gamePad1.size.x/2);
real32 tempLeftWall = gamePad2.position.x+(gamePad2.size.x/2);

void MoveBall(){

    tempNextXStep = (gameBall.direction.x * gameBall.magnatude * DeltaTime);
    tempNextYStep = (gameBall.direction.y * gameBall.magnatude * DeltaTime);
    tempRightWall = gamePad1.position.x-(gamePad1.size.x/2);
    tempLeftWall = gamePad2.position.x+(gamePad2.size.x/2);
    tempDistFromRightWall = (tempRightWall-gameBall.position.x);
    tempDistFromLeftWall = (tempLeftWall - gameBall.position.x);

    if(gameBall.position.x + tempNextXStep >= tempRightWall && gameBall.position.x < tempRightWall && gameBall.direction.x > 0){

        tempSlope=(tempNextYStep-gameBall.position.y)/(tempNextXStep-gameBall.position.x);
        tempYIntercept = gameBall.position.y + (tempSlope*tempDistFromRightWall);

        if(tempYIntercept <= gamePad1.position.y+(gamePad1.size.y/2) && tempYIntercept > gamePad1.position.y-(gamePad1.size.y/2)){
            gameBall.direction.x = cos(M_PI+(tempYIntercept-gamePad1.position.y)/(gamePad1.size.y/2)*(1.0/3.0)*M_PI);
            gameBall.direction.y = -sin(M_PI+(tempYIntercept-gamePad1.position.y)/(gamePad1.size.y/2)*(1.0/3.0)*M_PI);
            ChangeRandomBallColor();
            gameBall.magnatude *= (gameBall.magnatude<70.0f) ? 1.2 : 1.0;
            gameBall.position.x -= tempRightWall-(gameBall.position.x+tempNextXStep);
            gameBall.position.y += tempNextYStep;
        }else{
            gameBall.position.x += tempNextXStep;
            gameBall.position.y += tempNextYStep;
        }

    }else if(gameBall.position.x + tempNextXStep < tempLeftWall && gameBall.position.x >= tempLeftWall && gameBall.direction.x < 0) {

        tempSlope=(tempNextYStep-gameBall.position.y)/(tempNextXStep-gameBall.position.x);
        tempYIntercept = gameBall.position.y + (tempSlope*tempDistFromLeftWall);

        if(tempYIntercept <= gamePad2.position.y+(gamePad2.size.y/2) && tempYIntercept > gamePad2.position.y-(gamePad2.size.y/2)){
            gameBall.direction.x = cos((tempYIntercept-gamePad2.position.y)/(gamePad2.size.y/2)*(1.0/3.0)*M_PI);
            gameBall.direction.y = -sin((tempYIntercept-gamePad2.position.y)/(gamePad2.size.y/2)*(1.0/3.0)*M_PI);
            ChangeRandomBallColor();
            gameBall.magnatude *= (gameBall.magnatude<70.0f) ? 1.2 : 1.0;
            gameBall.position.x -= tempLeftWall-(gameBall.position.x+tempNextXStep);
            gameBall.position.y += tempNextYStep;
            
        }else{
            gameBall.position.x += tempNextXStep;
            gameBall.position.y += tempNextYStep;
        }

    }else if(gameBall.position.y + tempNextYStep > HEIGHT-1 && gameBall.direction.y > 0){
        gameBall.direction.y *= -1;
        gameBall.position.x += tempNextXStep;
        gameBall.position.y += (HEIGHT-1 - (gameBall.position.y + tempNextYStep));
    }else if(gameBall.position.y + tempNextYStep < 2 && gameBall.direction.y < 0) {
        gameBall.direction.y *= -1;
        gameBall.position.x += tempNextXStep;
        gameBall.position.y -= (-2+(gameBall.position.y + tempNextYStep));
    }else{
        gameBall.position.x += tempNextXStep;
        gameBall.position.y += tempNextYStep;
    }

}
void MovePaddles(){
    if(InputHeld(Keyboard,Input_UpArrow)){
        if(gamePad1.position.y - DeltaTime*40 > 1+(gamePad1.size.y-1)/2){
            gamePad1.position.y -= DeltaTime*40;
        }
    }
    if(InputHeld(Keyboard,Input_DownArrow)){
        if(gamePad1.position.y + DeltaTime*40 < HEIGHT-1-((gamePad1.size.y-1)/2)){
            gamePad1.position.y += DeltaTime*40;
        }
    }
    
    if(gameBall.position.y > gamePad2.position.y && gamePad2.position.y < HEIGHT-1-((gamePad2.size.y-1)/2)){
        gamePad2.position.y += DeltaTime*40;
    }else if(gameBall.position.y < gamePad2.position.y && gamePad2.position.y > 1+(gamePad2.size.y-1)/2){
        gamePad2.position.y -= DeltaTime*40;
    }
    
}
// end of physics functions


void MyMosaicUpdate() {

    // graphics
    DrawPongBorder();
    DrawPongSeparator();
    DrawBall();
    DrawPaddles();
    DrawTallies();

    //physics
    if(!endOfgame){
        DrawTextTop({1.0f,1.0f,1.0f}, 5.0f ,"Pong");
        MovePaddles();
        MoveBall();
    }

    //check
    checkScore();
    ChangeBackColor();
    CheckWin();

    if(InputPressed(Keyboard, Input_R)){
        restartGame();
    }
}
