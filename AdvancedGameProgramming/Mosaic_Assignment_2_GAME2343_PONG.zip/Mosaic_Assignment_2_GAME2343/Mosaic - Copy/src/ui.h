
struct UIManager {
    // Active widgets
    // Stack of styles like font, color, etc
};
